"""PostgreSQL-backed APEX RP worker for queued Discord notifications.

The worker uses the same bot application token as the single Gateway bot and
obeys Discord REST rate-limit responses.  It is safe to scale horizontally:
jobs are claimed with FOR UPDATE SKIP LOCKED.
"""

from __future__ import annotations

import asyncio
import json
import logging
import os
import socket
import time
from dataclasses import dataclass
from typing import Any

import asyncpg
import requests
from dotenv import load_dotenv

load_dotenv()
logging.basicConfig(
    level=os.getenv("LOG_LEVEL", "INFO"),
    format="%(asctime)s %(levelname)s %(name)s %(message)s",
)
logger = logging.getLogger("apex.worker")

BOT_TOKEN = os.getenv("BOT_TOKEN")
DATABASE_URL = os.getenv("DATABASE_URL")
DISCORD_API = "https://discord.com/api/v10"
WORKER_ID = f"{socket.gethostname()}-{os.getpid()}"
POLL_SECONDS = max(0.5, float(os.getenv("BOT_JOB_POLL_SECONDS", "2")))


@dataclass
class RetryJob(Exception):
    reason: str
    delay_seconds: float = 10


def discord_request(method: str, path: str, **kwargs: Any) -> dict[str, Any]:
    if not BOT_TOKEN:
        raise RuntimeError("BOT_TOKEN is required to process Discord notifications")
    response = requests.request(
        method,
        f"{DISCORD_API}{path}",
        headers={
            "Authorization": f"Bot {BOT_TOKEN}",
            "User-Agent": "APEX-RP-Command-Center/1.0",
        },
        timeout=(4, 12),
        **kwargs,
    )
    if response.status_code == 429:
        try:
            delay = float(response.json().get("retry_after", 5))
        except (ValueError, TypeError, requests.RequestException):
            delay = 5
        raise RetryJob("Discord rate limit", max(1, min(delay, 3600)))
    if response.status_code >= 500:
        raise RetryJob(f"Discord server returned {response.status_code}", 15)
    if not response.ok:
        raise RuntimeError(f"Discord API returned {response.status_code}")
    if response.content:
        return response.json()
    return {}


def send_owner_dm(payload: dict[str, Any]) -> None:
    user_id = str(payload.get("user_id", ""))
    content = payload.get("content")
    if not user_id.isdigit() or not isinstance(content, str) or not content.strip():
        raise RuntimeError("Notification job payload is invalid")
    channel = discord_request(
        "POST",
        "/users/@me/channels",
        json={"recipient_id": user_id},
    )
    channel_id = str(channel.get("id", ""))
    if not channel_id.isdigit():
        raise RetryJob("Discord did not return a DM channel", 20)
    discord_request(
        "POST",
        f"/channels/{channel_id}/messages",
        json={
            "content": content[:1900],
            "allowed_mentions": {"parse": []},
        },
    )


async def claim_job(pool: asyncpg.Pool) -> asyncpg.Record | None:
    async with pool.acquire() as connection:
        async with connection.transaction():
            job = await connection.fetchrow(
                """
                SELECT id, job_type, payload, attempts, max_attempts
                FROM apex_bot_jobs
                WHERE status = 'queued' AND available_at <= NOW()
                  AND attempts < max_attempts
                ORDER BY available_at, created_at
                FOR UPDATE SKIP LOCKED
                LIMIT 1
                """
            )
            if job is None:
                return None
            await connection.execute(
                """
                UPDATE apex_bot_jobs
                SET status = 'processing', claimed_by = $1,
                    claimed_at = NOW(), attempts = attempts + 1
                WHERE id = $2
                """,
                WORKER_ID,
                job["id"],
            )
            return job


async def mark_complete(pool: asyncpg.Pool, job_id: str) -> None:
    await pool.execute(
        """
        UPDATE apex_bot_jobs
        SET status = 'completed', completed_at = NOW(),
            claimed_by = NULL, claimed_at = NULL, last_error = NULL
        WHERE id = $1::uuid
        """,
        job_id,
    )


async def mark_failed(
    pool: asyncpg.Pool,
    job_id: str,
    current_attempt: int,
    max_attempts: int,
    error: Exception,
    delay: float,
) -> None:
    terminal = current_attempt >= max_attempts
    await pool.execute(
        """
        UPDATE apex_bot_jobs
        SET status = $1,
            available_at = NOW() + ($2 * INTERVAL '1 second'),
            claimed_by = NULL, claimed_at = NULL, last_error = $3
        WHERE id = $4::uuid
        """,
        "failed" if terminal else "queued",
        max(0, delay),
        str(error)[:800],
        job_id,
    )


async def process_job(pool: asyncpg.Pool, job: asyncpg.Record) -> None:
    job_id = str(job["id"])
    attempts = int(job["attempts"]) + 1
    max_attempts = int(job["max_attempts"])
    payload = job["payload"] if isinstance(job["payload"], dict) else json.loads(job["payload"])
    try:
        if job["job_type"] == "send_owner_dm":
            await asyncio.to_thread(send_owner_dm, payload)
        else:
            raise RuntimeError(f"Unsupported APEX bot job type: {job['job_type']}")
        await mark_complete(pool, job_id)
    except RetryJob as error:
        await mark_failed(pool, job_id, attempts, max_attempts, error, error.delay_seconds)
        logger.warning("Discord job %s will retry after rate limit or transient error", job_id)
    except (requests.Timeout, requests.ConnectionError) as error:
        delay = min(15 * (2 ** min(attempts - 1, 5)), 600)
        await mark_failed(pool, job_id, attempts, max_attempts, error, delay)
        logger.warning("Discord job %s encountered a network error", job_id)
    except Exception as error:
        await mark_failed(pool, job_id, attempts, max_attempts, error, 0)
        logger.exception("Discord job %s failed", job_id)


async def run() -> None:
    if not DATABASE_URL:
        raise RuntimeError("DATABASE_URL is required")
    if not BOT_TOKEN:
        raise RuntimeError("BOT_TOKEN is required")
    pool = await asyncpg.create_pool(
        dsn=DATABASE_URL,
        min_size=1,
        max_size=int(os.getenv("BOT_WORKER_DB_POOL_SIZE", "5")),
        command_timeout=15,
    )
    logger.info("APEX Discord worker started as %s", WORKER_ID)
    try:
        while True:
            job = await claim_job(pool)
            if job is None:
                await asyncio.sleep(POLL_SECONDS)
                continue
            await process_job(pool, job)
    finally:
        await pool.close()


if __name__ == "__main__":
    asyncio.run(run())
