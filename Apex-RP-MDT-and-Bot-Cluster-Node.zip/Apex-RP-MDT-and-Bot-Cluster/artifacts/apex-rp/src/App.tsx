import { type FormEvent, type ReactNode, useEffect, useState } from 'react';
import { QueryClient, QueryClientProvider, useQueryClient } from '@tanstack/react-query';
import {
  useGetAuthSession, useLogout, useGetOverview, useListCitizens, useGetCitizen,
  useListBankAccounts, useCreateBankAccount, useListTransactions, useCreateTransfer,
  useCreateDeposit, useCreateWithdrawal, useListDispatchCalls, useCreateDispatchCall,
  useAssignDispatchUnit, useListDispatchUnits, useUpdateDispatchUnit, useCreateDispatchUnit,
  useSearchPoliceRecords, useCreateCitation, useSearchMedicalRecords,
  useCreateMedicalReport, useListProperties, useListBusinesses,
  useListAccessPolicies, useUpdateAccessPolicy, useListSecurityEvents,
  getGetAuthSessionQueryKey, getGetOverviewQueryKey, getListCitizensQueryKey,
  getGetCitizenQueryKey, getListBankAccountsQueryKey, getListTransactionsQueryKey,
  getListDispatchCallsQueryKey, getListDispatchUnitsQueryKey,
  getSearchPoliceRecordsQueryKey, getSearchMedicalRecordsQueryKey,
  getListPropertiesQueryKey, getListBusinessesQueryKey, getListAccessPoliciesQueryKey,
  getListSecurityEventsQueryKey,
} from '@workspace/api-client-react';
import { ErrorBoundary } from '@/components/error-boundary';
import { Toaster } from '@/components/ui/toaster';
import { TooltipProvider } from '@/components/ui/tooltip';
import NotFound from '@/pages/not-found';
import {
  Activity, ArrowLeftRight, BadgeDollarSign, Building2, ChevronLeft, ClipboardList,
  FileText, HeartPulse, Landmark, LayoutDashboard, LogOut, MapPinned, Radio, UserRound,
  Search, Shield, Siren, Users,
} from 'lucide-react';
import { Link, Redirect, Route, Switch, Router as WouterRouter, useLocation, useParams } from 'wouter';

const queryClient = new QueryClient();
const brand = '/apex-rp-brand.jfif';
const navItems = [
  { href: '/', title: 'نظرة عامة', icon: LayoutDashboard, permission: 'dashboard:read' },
  { href: '/citizens', title: 'سجل المواطنين', icon: Users, permission: 'citizens:read' },
  { href: '/bank', title: 'الخدمات المصرفية', icon: Landmark, permission: 'banking:read' },
  { href: '/dispatch', title: 'غرفة العمليات', icon: Radio, permission: 'dispatch:read' },
  { href: '/police', title: 'السجلات الأمنية', icon: Shield, permission: 'police:read' },
  { href: '/medical', title: 'السجلات الطبية', icon: HeartPulse, permission: 'medical:read' },
  { href: '/community', title: 'المجتمع والأعمال', icon: Building2, permission: 'community:read' },
  { href: '/profile', title: 'الملف الشخصي', icon: UserRound, permission: 'self' },
];
const policyOptions = ['dashboard:read','citizens:read','banking:read','banking:manage','dispatch:read','dispatch:manage','police:read','police:manage','medical:read','medical:manage','community:read'] as const;
const arStatus: Record<string, string> = {
  active:'نشط', wanted:'مطلوب', detained:'موقوف', deceased:'متوفى',
  open:'مفتوح', assigned:'تم الإسناد', on_scene:'في الموقع', closed:'مغلق',
  available:'متاح', responding:'مستجيب', off_duty:'خارج الخدمة', frozen:'مجمّد',
  personal:'شخصي', business:'تجاري', department:'جهة حكومية',
  deposit:'إيداع', withdrawal:'سحب', transfer_in:'تحويل وارد', transfer_out:'تحويل صادر', citation:'مخالفة', payroll:'راتب',
  police:'الشرطة', ems:'الإسعاف', fire:'الدفاع المدني', security:'الأمن',
  low:'منخفضة', normal:'اعتيادية', high:'مرتفعة', critical:'حرجة',
};

function App() {
  return <QueryClientProvider client={queryClient}><TooltipProvider><WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, '')}><AuthGate /></WouterRouter><Toaster /></TooltipProvider></QueryClientProvider>;
}

function AuthGate() {
  const session = useGetAuthSession({ query: { queryKey: getGetAuthSessionQueryKey(), refetchInterval: 30_000 } });
  const [location] = useLocation();
  if (session.isLoading) return <div dir="rtl" className="auth-panel"><div className="auth-inner"><div className="skeleton mb-3" /><div className="skeleton mb-3" style={{ width: '70%' }} /><p className="text-secondary small">جارٍ التحقق من جلسة ديسكورد…</p></div></div>;
  if (session.isError) return <div dir="rtl" className="auth-panel"><div className="state-box text-center"><strong className="d-block mb-2">تعذّر التحقق من الجلسة</strong><p>تحقق من الاتصال بالخدمة ثم أعد المحاولة.</p><button className="btn-apex" onClick={() => session.refetch()}>إعادة المحاولة</button></div></div>;
  if (!session.data?.authenticated || !session.data.user) return <LoginScreen />;
  if (!session.data.user.isOwner && session.data.user.permissions.length === 0 && location !== '/profile') return <Redirect to="/profile" />;
  if (session.data.user.discordUserId.startsWith('google:') && !session.data.user.permissions.length) return <GoogleApprovalScreen username={session.data.user.username} />;
  return <ErrorBoundary resetKey={location}><Shell user={session.data.user}><Switch>
    <Route path="/">{() => <PermissionGate user={session.data!.user!} permission="dashboard:read"><OverviewPage /></PermissionGate>}</Route>
    <Route path="/citizens">{() => <PermissionGate user={session.data!.user!} permission="citizens:read"><CitizensPage /></PermissionGate>}</Route>
    <Route path="/citizens/:discordUserId">{() => <PermissionGate user={session.data!.user!} permission="citizens:read"><CitizenDetailPage /></PermissionGate>}</Route>
    <Route path="/bank">{() => <PermissionGate user={session.data!.user!} permission="banking:read"><BankPage /></PermissionGate>}</Route>
    <Route path="/dispatch">{() => <PermissionGate user={session.data!.user!} permission="dispatch:read"><DispatchPage canManage={session.data!.user!.isOwner || session.data!.user!.permissions.includes('dispatch:manage')} /></PermissionGate>}</Route>
    <Route path="/police">{() => <PermissionGate user={session.data!.user!} permission="police:read"><PolicePage /></PermissionGate>}</Route>
    <Route path="/medical">{() => <PermissionGate user={session.data!.user!} permission="medical:read"><MedicalPage /></PermissionGate>}</Route>
    <Route path="/community">{() => <PermissionGate user={session.data!.user!} permission="community:read"><CommunityPage /></PermissionGate>}</Route>
    <Route path="/profile">{() => <ProfilePage user={session.data!.user!} />}</Route>
    <Route path="/admin">{() => session.data?.user?.isOwner ? <AdminPage /> : <AccessDenied />}</Route>
    <Route component={NotFound} />
  </Switch></Shell></ErrorBoundary>;
}

function LoginScreen() {
  const [mode, setMode] = useState<'login'|'register'|'bootstrap'|'mfa'>('login');
  const [username, setUsername] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [passwordConfirm, setPasswordConfirm] = useState('');
  const [setupToken, setSetupToken] = useState('');
  const [code, setCode] = useState('');
  const [challenge, setChallenge] = useState('');
  const [notice, setNotice] = useState('');
  const [busy, setBusy] = useState(false);
  const [bootstrapAvailable, setBootstrapAvailable] = useState(false);
  useEffect(() => { fetch('/api/auth/bootstrap/status').then(r => r.json()).then(v => {
    setBootstrapAvailable(Boolean(v.available));
  }).catch(() => {}); }, []);
  async function submit(event: FormEvent) {
    event.preventDefault(); setNotice(''); setBusy(true);
    try {
      if (mode === 'register' && password !== passwordConfirm) throw new Error('كلمتا المرور غير متطابقتين.');
      const path = mode === 'register' ? '/api/auth/register' : mode === 'bootstrap' ? '/api/auth/bootstrap' : mode === 'mfa' ? '/api/auth/login/totp' : '/api/auth/login';
      const body = mode === 'register' ? { username, email, password } :
        mode === 'login' ? { identifier: username, password } :
        mode === 'bootstrap' ? { username, email, password, setupToken } : { challenge, code };
      const response = await fetch(path, { method:'POST', headers:{'content-type':'application/json'}, body:JSON.stringify(body) });
      const result = await response.json();
      if (!response.ok) throw new Error(result.error || 'تعذّر إكمال الطلب.');
      if (mode === 'register') { window.location.assign('/'); return; }
      if (mode === 'bootstrap') { window.location.assign('/'); return; }
      if (mode === 'login' && result.requiresMfa) { setChallenge(result.challenge); setMode('mfa'); setNotice('أدخل الرمز الحالي من تطبيق المصادقة.'); return; }
      window.location.assign('/');
    } catch (error) { setNotice(error instanceof Error ? error.message : 'تعذّر إكمال الطلب.'); }
    finally { setBusy(false); }
  }
  const heading = mode === 'register' ? 'إنشاء حساب' : mode === 'bootstrap' ? 'إعداد حساب المالك' : mode === 'mfa' ? 'التحقق بخطوتين' : 'تسجيل الدخول';
  return <main className="auth-screen" dir="rtl">
    <section className="auth-art">
      <img src={brand} alt="شعار APEX RP" />
      <div className="auth-copy"><strong>APEX ROLEPLAY</strong><div className="small mt-1">إدارة المدينة تبدأ من هنا</div></div>
    </section>
    <section className="auth-panel">
      <div className="auth-inner">
        <img src={brand} alt="" />
        <div className="eyebrow">مركز القيادة التشغيلي</div>
        <h1>{heading}</h1>
        <p>{mode === 'register'
          ? 'أنشئ حسابك باستخدام اسم مستخدم وبريد إلكتروني وكلمة مرور. لن نرسل رسائل أو رموز تحقق.'
          : mode === 'bootstrap'
            ? 'أنشئ حساب المالك الأول باستخدام رمز إعداد سري لمرة واحدة. لا نرسل بريداً ولا نطلب مصادقة ثنائية.'
              : 'سجّل باستخدام اسم المستخدم وكلمة المرور.'}</p>
        <form onSubmit={submit} className="d-grid gap-3">
          {mode !== 'mfa' && <label>{mode === 'login' ? 'اسم المستخدم أو البريد أو رقم الهوية' : 'اسم المستخدم'}<input className="form-control mt-1" required minLength={mode === 'login' ? undefined : 3} maxLength={mode === 'login' ? undefined : 32} autoComplete="username" value={username} onChange={e=>setUsername(e.target.value)} /></label>}
          {(mode === 'register' || mode === 'bootstrap') && <label>البريد الإلكتروني<input className="form-control mt-1" required type="email" autoComplete="email" value={email} onChange={e=>setEmail(e.target.value)} /></label>}
          {mode !== 'mfa' && <label>{mode === 'bootstrap' ? 'كلمة مرور جديدة للمالك' : 'كلمة المرور'}<input className="form-control mt-1" required minLength={12} type="password" autoComplete={mode==='register'||mode==='bootstrap'?'new-password':'current-password'} value={password} onChange={e=>setPassword(e.target.value)} /></label>}
          {mode === 'register' && <label>تأكيد كلمة المرور<input className="form-control mt-1" required minLength={12} type="password" autoComplete="new-password" value={passwordConfirm} onChange={e=>setPasswordConfirm(e.target.value)} /></label>}
          {mode === 'bootstrap' && <label>رمز الإعداد لمرة واحدة<input className="form-control mt-1" required type="password" autoComplete="off" value={setupToken} onChange={e=>setSetupToken(e.target.value)} /></label>}
          {mode === 'mfa' && <label>رمز المصادقة<input className="form-control mt-1" required inputMode="numeric" autoComplete="one-time-code" value={code} onChange={e=>setCode(e.target.value)} /></label>}
          {notice && <div className="auth-notice" role="status">{notice}</div>}
          <button className="btn-apex" disabled={busy}>{busy ? mode === 'register' || mode === 'bootstrap' ? 'جارٍ إنشاء الحساب…' : 'جارٍ التحقق…' : mode === 'register' ? 'إنشاء الحساب' : mode === 'bootstrap' ? 'إنشاء حساب المالك' : mode === 'mfa' ? 'تحقق' : 'دخول'}</button>
        </form>
        <div className="d-flex gap-3 mt-3 flex-wrap">
          {mode === 'login' && <button className="btn-quiet" onClick={()=>{setNotice('');setMode('register')}}>إنشاء حساب</button>}
          {mode === 'register' && <button className="btn-quiet" onClick={()=>{setNotice('');setMode('login')}}>العودة للدخول</button>}
          {mode === 'login' && bootstrapAvailable && <button className="btn-quiet" onClick={()=>{setNotice('');setMode('bootstrap')}}>إعداد حساب المالك الأول</button>}
          {(mode === 'mfa' || mode === 'bootstrap') && <button className="btn-quiet" onClick={()=>{setCode('');setNotice('');setMode('login')}}>رجوع</button>}
        </div>
        <div className="d-flex align-items-center gap-2 mt-4 text-secondary" style={{ fontSize: 11 }}>
          <span className="status-pill">اتصال آمن</span><span>تُحمى البيانات بحسب صلاحيات حسابك</span>
        </div>
      </div>
    </section>
  </main>;
}

function GoogleApprovalScreen({ username }: { username: string }) {
  const logout = useLogout();
  return <main className="auth-panel" dir="rtl"><section className="auth-inner">
    <img src={brand} alt="شعار APEX RP" />
    <div className="eyebrow">حساب Google</div>
    <h1>بانتظار موافقة المالك</h1>
    <p>أهلاً {username}، تم تسجيل دخولك. لن تظهر بيانات APEX حتى يوافق المالك ويحدد صلاحيات حسابك.</p>
    <button className="btn-quiet mt-3" onClick={() => logout.mutate(undefined, { onSuccess: () => window.location.assign('/') })}>تسجيل الخروج</button>
  </section></main>;
}

function ProfilePage({ user }: { user: { username: string; isOwner: boolean } }) {
  const cache = useQueryClient();
  const [profile, setProfile] = useState<{ username: string; identityNumber: string; status: string; isOwner: boolean; permissions: string[]; createdAt: string } | null>(null);
  const [notice, setNotice] = useState('');
  const [error, setError] = useState('');
  const [currentPassword, setCurrentPassword] = useState('');
  const [newUsername, setNewUsername] = useState(user.username);
  const [passwordForm, setPasswordForm] = useState({ currentPassword: '', newPassword: '' });
  const [saving, setSaving] = useState(false);
  useEffect(() => {
    fetch('/api/auth/profile').then(async response => {
      if (!response.ok) throw new Error();
      const value = await response.json();
      setProfile(value);
      setNewUsername(value.username);
    }).catch(() => setError('تعذّر تحميل بيانات الحساب.'));
  }, []);
  async function saveUsername(event: FormEvent<HTMLFormElement>) {
    event.preventDefault(); setNotice(''); setError(''); setSaving(true);
    try {
      const response = await fetch('/api/auth/profile', {
        method: 'PATCH', headers: { 'content-type': 'application/json' },
        body: JSON.stringify({ username: newUsername, currentPassword }),
      });
      const result = await response.json();
      if (!response.ok) throw new Error(result.error || 'تعذّر حفظ الملف الشخصي.');
      setProfile(previous => previous ? { ...previous, username: result.username } : previous);
      setCurrentPassword('');
      cache.setQueryData(getGetAuthSessionQueryKey(), (old: any) =>
        old?.authenticated ? { ...old, user: { ...old.user, username: result.username } } : old);
      setNotice('تم تحديث اسم المستخدم. أُنهِيت الجلسات الأخرى للحساب.');
    } catch (reason) { setError(reason instanceof Error ? reason.message : 'تعذّر حفظ الملف الشخصي.'); }
    finally { setSaving(false); }
  }
  async function changePassword(event: FormEvent<HTMLFormElement>) {
    event.preventDefault(); setNotice(''); setError(''); setSaving(true);
    try {
      const response = await fetch('/api/auth/password', {
        method: 'POST', headers: { 'content-type': 'application/json' },
        body: JSON.stringify(passwordForm),
      });
      const result = await response.json();
      if (!response.ok) throw new Error(result.error || 'تعذّر تغيير كلمة المرور.');
      setPasswordForm({ currentPassword: '', newPassword: '' });
      setNotice('تم تغيير كلمة المرور وإنهاء الجلسات الأخرى.');
    } catch (reason) { setError(reason instanceof Error ? reason.message : 'تعذّر تغيير كلمة المرور.'); }
    finally { setSaving(false); }
  }
  return <>
    <PageTitle eyebrow="الحساب والأمان" title="الملف الشخصي" description="عدّل اسم المستخدم وغيّر كلمة المرور بأمان." />
    {notice && <div className="toast-note mb-3" role="status">{notice}</div>}
    {error && <div className="auth-notice mb-3" role="alert">{error}</div>}
    {!profile ? <LoadingState /> : <div className="content-grid">
      <section className="panel">
        <div className="panel-head"><h2><UserRound size={17} className="ms-2" />بيانات الحساب</h2></div>
        <div className="panel-body">
          <div className="d-flex flex-wrap gap-2 mb-3">
            <span className="status-pill">{profile.isOwner ? 'المالك' : profile.status === 'disabled' ? 'موقوف' : profile.status === 'pending' ? 'دخول محدود — بلا صلاحيات تشغيلية' : 'حساب مفعّل'}</span>
          </div>
          <div className="detail-item mb-3"><small>رقم الهوية المدنية</small><strong className="mono">{profile.identityNumber}</strong></div>
          {!profile.isOwner && <div className="d-flex flex-wrap gap-2 mb-3">{profile.permissions.length ? profile.permissions.map(permission => <span className="status-pill mono" key={permission}>{permission}</span>) : <span className="text-secondary small">لا توجد صلاحيات مخصصة حتى الآن.</span>}</div>}
          <p className="text-secondary small">تاريخ إنشاء الحساب: {new Date(profile.createdAt).toLocaleDateString('ar')}</p>
          <form className="d-grid gap-3" onSubmit={saveUsername}>
            <label>اسم المستخدم<input className="form-control mt-1" required minLength={3} maxLength={32} value={newUsername} onChange={event => setNewUsername(event.target.value)} autoComplete="username" /></label>
            <label>كلمة المرور الحالية<input className="form-control mt-1" type="password" required autoComplete="current-password" value={currentPassword} onChange={event => setCurrentPassword(event.target.value)} /></label>
            <button className="btn-apex" disabled={saving}>{saving ? 'جارٍ الحفظ…' : 'حفظ اسم المستخدم'}</button>
          </form>
        </div>
      </section>
      <section className="panel">
        <div className="panel-head"><h2><Shield size={17} className="ms-2" />تغيير كلمة المرور</h2></div>
        <div className="panel-body">
          <p className="text-secondary small">استخدم كلمة مرور جديدة لا تقل عن 12 حرفاً. عند تغييرها، تُنهى الجلسات الأخرى.</p>
          <form className="d-grid gap-3" onSubmit={changePassword}>
            <label>كلمة المرور الحالية<input className="form-control mt-1" type="password" required autoComplete="current-password" value={passwordForm.currentPassword} onChange={event => setPasswordForm(value => ({ ...value, currentPassword: event.target.value }))} /></label>
            <label>كلمة المرور الجديدة<input className="form-control mt-1" type="password" required minLength={12} maxLength={128} autoComplete="new-password" value={passwordForm.newPassword} onChange={event => setPasswordForm(value => ({ ...value, newPassword: event.target.value }))} /></label>
            <button className="btn-apex" disabled={saving}>{saving ? 'جارٍ التحديث…' : 'تغيير كلمة المرور'}</button>
          </form>
        </div>
      </section>
    </div>}
  </>;
}

function Shell({ user, children }: { user: { discordUserId: string; username: string; avatarUrl: string | null; isOwner: boolean; permissions: string[]; googleLinked: boolean }; children: ReactNode }) {
  const [path] = useLocation();
  const logout = useLogout();
  const cache = useQueryClient();
  const nav = [...navItems.filter(item => item.permission === 'self' || user.isOwner || user.permissions.includes(item.permission)), ...(user.isOwner ? [{ href:'/admin', title:'إدارة الصلاحيات', icon:ClipboardList, permission:'admin:read' }] : [])];
  const authStatus = new URLSearchParams(window.location.search).get("auth");
  return <div className="apex-shell" dir="rtl">
    <aside className="apex-sidebar">
      <div className="apex-brand"><img src={brand} alt="APEX RP" /><div><strong>APEX RP</strong><small>COMMAND CENTER</small></div></div>
      <div className="nav-caption">مساحة العمل</div>
      <nav className="apex-nav">{nav.map(({href,title,icon:Icon}) => <Link key={href} href={href} className={path === href || (href !== '/' && path.startsWith(href)) ? 'active' : ''} data-testid={`link-nav-${href.slice(1) || 'home'}`}><Icon /><span>{title}</span></Link>)}</nav>
      <div className="side-foot">مركز القيادة<br /><span className="mono">APEX / RP / 01</span></div>
    </aside>
    <main className="apex-main">
      <header className="topbar">
        <div className="topbar-title"><span>نظام إدارة المدينة</span><strong>{nav.find(n => path === n.href || (n.href !== '/' && path.startsWith(n.href)))?.title || 'APEX RP'}</strong></div>
        <div className="user-chip">
          {user.avatarUrl ? <img className="user-avatar" src={user.avatarUrl} alt="" /> : <span className="user-avatar user-fallback">{user.username.slice(0,1).toUpperCase()}</span>}
          <span>{user.username}</span>
          <button className="btn-quiet" disabled={logout.isPending} onClick={() => logout.mutate(undefined, { onSuccess: () => { cache.setQueryData(getGetAuthSessionQueryKey(), { authenticated:false, user:null }); } })} data-testid="button-logout"><LogOut size={14} className="ms-1" />{logout.isPending ? 'جارٍ الخروج' : 'خروج'}</button>
        </div>
      </header>
      <div className="main-content">
        {authStatus === "google-linked" ? <div className="toast-note mb-3" role="status">تم ربط حساب Google بنجاح. يمكنك استخدامه في تسجيل الدخول.</div> : authStatus === "google-unavailable" ? <div className="auth-notice" role="alert">تسجيل الدخول غير مهيأ بعد؛ يحتاج المسؤول إلى إعداد بيانات OAuth في الخادم.</div> : null}
        {children}
      </div>
    </main>
  </div>;
}

function PageTitle({ eyebrow, title, description, action }: { eyebrow: string; title: string; description?: string; action?: ReactNode }) {
  return <div className="page-heading"><div><div className="eyebrow">{eyebrow}</div><h1>{title}</h1>{description && <p>{description}</p>}</div>{action}</div>;
}
function LoadingState({ label = 'جارٍ تحميل البيانات' }: { label?: string }) { return <div className="panel panel-body"><div className="skeleton mb-3" /><div className="skeleton mb-3" style={{ width: '72%' }} /><div className="skeleton" style={{ width: '88%' }} /><small className="d-block mt-3 text-secondary">{label}…</small></div>; }
function QueryState({ error, retry }: { error: boolean; retry: () => void }) { return <div className="state-box d-flex align-items-center justify-content-between gap-3"><span>{error ? 'تعذّر تحميل البيانات. يمكنك المحاولة مجدداً.' : 'لا توجد بيانات لعرضها حالياً.'}</span>{error && <button className="btn-quiet" onClick={retry}>إعادة المحاولة</button>}</div>; }
function Empty({ title = 'لا توجد سجلات', detail = 'ستظهر السجلات هنا عند توفر بيانات.' }: { title?: string; detail?: string }) { return <div className="empty-state"><div className="empty-mark"><FileText size={19} /></div><strong>{title}</strong><span style={{fontSize:11}}>{detail}</span></div>; }
function Stat({ label, value, hint, icon: Icon }: { label: string; value: string | number; hint?: string; icon: typeof Activity }) { return <div className="panel metric"><div className="metric-top"><span>{label}</span><span className="metric-icon"><Icon size={17} /></span></div><div className="metric-value">{value}</div>{hint && <div className="metric-note">{hint}</div>}</div>; }
function TableEmpty({ colspan, title }: { colspan: number; title?: string }) { return <tr><td colSpan={colspan}><Empty title={title} /></td></tr>; }
const dateText = (value?: string | null) => value ? new Intl.DateTimeFormat('ar-SA', { dateStyle:'medium', timeStyle:'short' }).format(new Date(value)) : '—';
const cash = (value: number, currency = 'USD') => new Intl.NumberFormat('ar-SA', { style:'currency', currency }).format(value);
function Status({ value }: { value: string }) { const kind = ['wanted','critical','frozen','deceased'].includes(value) ? 'danger' : ['high','normal','assigned','responding','on_scene'].includes(value) ? 'warn' : ['closed','off_duty'].includes(value) ? 'neutral' : ''; return <span className={`status-pill ${kind}`}>{arStatus[value] || value}</span>; }

function OverviewPage() {
  const q = useGetOverview({ query: { queryKey: getGetOverviewQueryKey(), refetchInterval: 15_000 } });
  if (q.isLoading) return <><PageTitle eyebrow="لوحة القيادة" title="نظرة عامة" description="صورة تشغيلية مباشرة عن خدمات المدينة." /><LoadingState /></>;
  if (q.isError || !q.data) return <><PageTitle eyebrow="لوحة القيادة" title="نظرة عامة" /><QueryState error retry={() => q.refetch()} /></>;
  const d = q.data;
  return <><PageTitle eyebrow="لوحة القيادة / مباشر" title="صباح الخير، فريق APEX" description="إليك ملخص النشاط التشغيلي المتاح الآن." /><div className="metric-grid"><Stat label="إجمالي أرصدة البنك" value={cash(d.totalBankBalance)} hint="الرصيد المسجل عبر النظام" icon={BadgeDollarSign} /><Stat label="بلاغات نشطة" value={d.activeCalls} hint="تحتاج إلى متابعة ميدانية" icon={Siren} /><Stat label="وحدات متاحة" value={d.availableUnits} hint="جاهزة للاستجابة" icon={Radio} /><Stat label="الطاقم النشط" value={d.activeStaff} hint="حسابات عاملة الآن" icon={Users} /></div><div className="content-grid"><section className="panel"><div className="panel-head"><h2>آخر الحركات المصرفية</h2><Link href="/bank" className="btn-quiet text-decoration-none">فتح البنك <ChevronLeft size={13} /></Link></div><div className="table-wrap"><table className="table"><thead><tr><th>الحركة</th><th>الطرف الآخر</th><th>المبلغ</th><th>رقم الإيصال</th><th>الوقت</th></tr></thead><tbody>{d.recentTransactions.length ? d.recentTransactions.map(t => <tr key={t.id} data-testid={`row-transaction-${t.id}`}><td><Status value={t.entryKind} /></td><td>{t.counterparty}</td><td className="mono">{cash(t.amount)}</td><td className="mono">{t.receiptNumber}</td><td>{dateText(t.createdAt)}</td></tr>) : <TableEmpty colspan={5} title="لا توجد حركات حديثة" />}</tbody></table></div></section><section className="panel"><div className="panel-head"><h2>بلاغات الأولوية</h2><Link href="/dispatch" className="btn-quiet text-decoration-none">غرفة العمليات</Link></div><div className="panel-body">{d.priorityCalls.length ? d.priorityCalls.map(c => <div className="priority-card" key={c.id}><div className="d-flex justify-content-between gap-2"><strong>{c.title}</strong><Status value={c.priority} /></div><small>{c.location} · {arStatus[c.callType] || c.callType} · {dateText(c.createdAt)}</small></div>) : <Empty title="لا توجد بلاغات أولوية" detail="تظهر البلاغات ذات الأولوية هنا." />}</div></section></div></>;
}

function CitizensPage() {
  const [search, setSearch] = useState('');
  const q = useListCitizens(search ? { search } : undefined);
  return <><PageTitle eyebrow="السجل المدني" title="المواطنون" description="لكل مواطن رقم هوية ثابت يمكن استخدامه في البحث والسجلات." /><div className="searchbox mb-3"><Search /><input className="form-control" value={search} onChange={e => setSearch(e.target.value)} placeholder="رقم الهوية أو الاسم أو معرّف ديسكورد…" aria-label="بحث المواطنين" data-testid="input-citizen-search" /></div>{q.isLoading ? <LoadingState /> : q.isError ? <QueryState error retry={() => q.refetch()} /> : <div className="panel"><div className="table-wrap"><table className="table"><thead><tr><th>رقم الهوية</th><th>المواطن</th><th>معرّف ديسكورد</th><th>الهاتف</th><th>المهنة</th><th>الحالة</th><th>الرصيد</th><th /></tr></thead><tbody>{q.data?.length ? q.data.map(c => <tr key={c.discordUserId}><td className="mono fw-bold">{c.identityNumber}</td><td className="fw-bold">{c.displayName}</td><td className="mono">{c.discordUserId}</td><td>{c.phone || '—'}</td><td>{c.occupation || '—'}</td><td><Status value={c.citizenStatus} /></td><td>{cash(c.accountBalance)}</td><td><Link href={`/citizens/${c.discordUserId}`} className="btn-quiet text-decoration-none">عرض السجل</Link></td></tr>) : <TableEmpty colspan={8} title={search ? 'لم نعثر على نتائج' : 'السجل فارغ حالياً'} />}</tbody></table></div></div>}</>;
}

function CitizenDetailPage() {
  const { discordUserId = '' } = useParams();
  const q = useGetCitizen(discordUserId);
  if (q.isLoading) return <LoadingState />;
  if (q.isError || !q.data) return <><PageTitle eyebrow="السجل المدني" title="بيانات المواطن" /><QueryState error retry={() => q.refetch()} /></>;
  const c = q.data;
  return <><PageTitle eyebrow="السجل المدني / ملف فردي" title="ملف المواطن" action={<Link href="/citizens" className="btn-quiet text-decoration-none">العودة إلى البحث</Link>} /><div className="record-hero"><div><div className="eyebrow" style={{color:'#e9c36c'}}>ملف مدني موثق</div><h2>{c.displayName}</h2><p className="mono">{c.identityNumber}</p></div><Status value={c.citizenStatus} /></div><section className="panel"><div className="panel-head"><h2>معلومات السجل</h2></div><div className="panel-body detail-grid"><Detail label="رقم الهوية" value={c.identityNumber} mono /><Detail label="رقم الهاتف" value={c.phone || 'غير مسجل'} /><Detail label="المهنة" value={c.occupation || 'غير مسجلة'} /><Detail label="الرصيد البنكي" value={cash(c.accountBalance)} /><Detail label="آخر ظهور" value={dateText(c.lastSeen)} /><Detail label="معرّف ديسكورد" value={c.discordUserId} mono /></div></section></>;
}
function Detail({label,value,mono: isMono}: {label:string;value:string;mono?:boolean}) { return <div className="detail-item"><small>{label}</small><strong className={isMono?'mono':''}>{value}</strong></div>; }

function BankPage() {
  const cache = useQueryClient();
  const accounts = useListBankAccounts();
  const tx = useListTransactions();
  const createAccount = useCreateBankAccount();
  const transfer = useCreateTransfer();
  const deposit = useCreateDeposit();
  const withdrawal = useCreateWithdrawal();
  const [message,setMessage] = useState('');
  const [mode,setMode] = useState('deposit');
  function update() { cache.invalidateQueries({queryKey:getListBankAccountsQueryKey()}); cache.invalidateQueries({queryKey:getListTransactionsQueryKey()}); cache.invalidateQueries({queryKey:getGetOverviewQueryKey()}); }
  const busy = createAccount.isPending || transfer.isPending || deposit.isPending || withdrawal.isPending;
  function submitBank(e:FormEvent<HTMLFormElement>) { e.preventDefault(); setMessage(''); const form=e.currentTarget; const f=new FormData(form); const action=String(f.get('action')); if(action==='account') createAccount.mutate({data:{displayName:String(f.get('displayName')),accountType:String(f.get('accountType')) as 'personal'|'business'|'department'}},{onSuccess:()=>{setMessage('تم إنشاء الحساب بنجاح.');form.reset();update();}}); if(action==='transfer') transfer.mutate({data:{sourceAccountId:String(f.get('accountId')),recipientIban:String(f.get('recipientIban')),amount:Number(f.get('amount')),description:String(f.get('description'))}},{onSuccess:()=>{setMessage('تم إرسال التحويل.');form.reset();update();}}); if(action==='deposit'||action==='withdrawal'){const payload={accountId:String(f.get('accountId')),amount:Number(f.get('amount')),description:String(f.get('description'))}; const mutate=action==='deposit'?deposit:withdrawal; if(window.confirm(action==='deposit'?'تأكيد إيداع المبلغ في الحساب المحدد؟':'تأكيد سحب المبلغ من الحساب المحدد؟')) mutate.mutate({data:payload},{onSuccess:()=>{setMessage('تم تسجيل الحركة بنجاح.');form.reset();update();}}); } }
  return <><PageTitle eyebrow="الخدمات المالية" title="المصرف المركزي" description="إدارة الحسابات والحركات المسجلة وفق صلاحياتك." /><div className="metric-grid"><Stat label="الحسابات المتاحة" value={accounts.data?.length ?? '—'} icon={Landmark} /><Stat label="الحركات المعروضة" value={tx.data?.length ?? '—'} icon={ArrowLeftRight} /></div>{message && <div className="toast-note mb-3">{message}</div>}{(accounts.isError||tx.isError)&&<QueryState error retry={()=>{accounts.refetch();tx.refetch();}} />}{accounts.isLoading||tx.isLoading?<LoadingState />:<><section className="panel mb-3"><div className="panel-head"><h2>تنفيذ حركة مصرفية</h2><select className="form-select" style={{width:160}} value={mode} onChange={e=>setMode(e.target.value)}><option value="deposit">إيداع</option><option value="withdrawal">سحب نقدي</option><option value="transfer">تحويل</option><option value="account">حساب جديد</option></select></div><div className="panel-body"><form onSubmit={submitBank}><input type="hidden" name="action" value={mode} />{mode==='account'?<div className="row g-3 align-items-end"><div className="col-md-5"><label className="form-label">اسم الحساب</label><input name="displayName" className="form-control" required minLength={2} placeholder="اسم الحساب" /></div><div className="col-md-4"><label className="form-label">نوع الحساب</label><select name="accountType" className="form-select"><option value="personal">شخصي</option><option value="business">تجاري</option><option value="department">جهة حكومية</option></select></div><div className="col-md-3"><button className="btn-apex w-100" disabled={busy}>إنشاء حساب</button></div></div>:<div className="row g-3 align-items-end"><div className="col-md-4"><label className="form-label">الحساب</label><select name="accountId" className="form-select" required><option value="">اختر الحساب</option>{accounts.data?.map(a=><option value={a.id} key={a.id}>{a.displayName} · {a.iban}</option>)}</select></div>{mode==='transfer'&&<div className="col-md-3"><label className="form-label">آيبان المستفيد</label><input name="recipientIban" className="form-control" required /></div>}<div className="col-md-2"><label className="form-label">المبلغ</label><input name="amount" type="number" min=".01" step=".01" className="form-control" required /></div><div className="col-md-3"><label className="form-label">الوصف</label><input name="description" className="form-control" maxLength={240} placeholder="تفاصيل الحركة" required /></div><div className="col-md-3"><button className="btn-apex w-100" disabled={busy}>{busy?'جارٍ التنفيذ…':mode==='transfer'?'تنفيذ التحويل':mode==='withdrawal'?'تسجيل السحب':'تسجيل الإيداع'}</button></div></div>}{(createAccount.isError||transfer.isError||deposit.isError||withdrawal.isError)&&<div className="text-danger small mt-3">تعذّر تنفيذ العملية. راجع البيانات والصلاحيات ثم أعد المحاولة.</div>}</form></div></section><div className="content-grid"><section className="panel"><div className="panel-head"><h2>الحسابات المصرفية</h2></div><div className="table-wrap"><table className="table"><thead><tr><th>اسم الحساب</th><th>الآيبان</th><th>النوع</th><th>الرصيد</th><th>الحالة</th></tr></thead><tbody>{accounts.data?.length?accounts.data.map(a=><tr key={a.id}><td className="fw-bold">{a.displayName}</td><td className="mono">{a.iban}</td><td><Status value={a.accountType} /></td><td>{cash(a.balance,a.currency)}</td><td><Status value={a.status} /></td></tr>):<TableEmpty colspan={5} title="لا توجد حسابات ظاهرة" />}</tbody></table></div></section><section className="panel"><div className="panel-head"><h2>سجل الحركات</h2></div><div className="table-wrap"><table className="table"><thead><tr><th>النوع</th><th>المبلغ</th><th>الإيصال</th><th>التاريخ</th></tr></thead><tbody>{tx.data?.length?tx.data.map(t=><tr key={t.id}><td><Status value={t.entryKind} /></td><td>{cash(t.amount)}</td><td className="mono">{t.receiptNumber}</td><td>{dateText(t.createdAt)}</td></tr>):<TableEmpty colspan={4} title="لا توجد حركات" />}</tbody></table></div></section></div></>}</>;
}

function DispatchPage({canManage}:{canManage:boolean}) {
 const cache=useQueryClient();const calls=useListDispatchCalls({query:{queryKey:getListDispatchCallsQueryKey(),refetchInterval:10_000}});const units=useListDispatchUnits({query:{queryKey:getListDispatchUnitsQueryKey(),refetchInterval:10_000}});const create=useCreateDispatchCall();const createUnit=useCreateDispatchUnit();const assign=useAssignDispatchUnit();const update=useUpdateDispatchUnit();const [notice,setNotice]=useState('');
 function refresh(){cache.invalidateQueries({queryKey:getListDispatchCallsQueryKey()});cache.invalidateQueries({queryKey:getListDispatchUnitsQueryKey()});cache.invalidateQueries({queryKey:getGetOverviewQueryKey()});}
 function createCall(e:FormEvent<HTMLFormElement>){e.preventDefault();const form=e.currentTarget;const f=new FormData(form);create.mutate({data:{callType:String(f.get('callType')) as 'police'|'ems'|'fire'|'security',title:String(f.get('title')),location:String(f.get('location')),notes:String(f.get('notes')),callerName:String(f.get('callerName')),priority:String(f.get('priority')) as 'low'|'normal'|'high'|'critical'}},{onSuccess:()=>{setNotice('تم تسجيل البلاغ.');form.reset();refresh();}});}
 function createUnitEntry(e:FormEvent<HTMLFormElement>){e.preventDefault();const form=e.currentTarget;const f=new FormData(form);createUnit.mutate({data:{callsign:String(f.get('callsign')).trim(),department:String(f.get('department')) as 'police'|'ems'|'fire'|'security',displayName:String(f.get('displayName')).trim()}},{onSuccess:()=>{setNotice('تم تسجيل الوحدة.');form.reset();refresh();}});}
 return <><PageTitle eyebrow="الاستجابة الميدانية" title="غرفة العمليات" description="إدارة البلاغات والوحدات حسب الحالة التشغيلية." />{notice&&<div className="toast-note mb-3">{notice}</div>}{calls.isError||units.isError?<QueryState error retry={()=>{calls.refetch();units.refetch();}} />:null}{calls.isLoading||units.isLoading?<LoadingState />:<>{canManage&&<section className="panel mb-3"><div className="panel-head"><h2>تسجيل وحدة ميدانية</h2></div><div className="panel-body"><form onSubmit={createUnitEntry} className="row g-3 align-items-end"><div className="col-md-3"><label className="form-label">النداء</label><input name="callsign" className="form-control" minLength={2} maxLength={12} required /></div><div className="col-md-3"><label className="form-label">الجهة</label><select name="department" className="form-select"><option value="police">الشرطة</option><option value="ems">الإسعاف</option><option value="fire">الدفاع المدني</option><option value="security">الأمن الخاص</option></select></div><div className="col-md-4"><label className="form-label">اسم الوحدة</label><input name="displayName" className="form-control" minLength={2} maxLength={80} required /></div><div className="col-md-2"><button className="btn-apex w-100" disabled={createUnit.isPending}>تسجيل الوحدة</button></div></form>{createUnit.isError&&<div className="text-danger small mt-2">تعذّر تسجيل الوحدة؛ تحقق من النداء والصلاحية.</div>}</div></section>}<div className="metric-grid"><Stat label="البلاغات" value={calls.data?.length??0} icon={Siren} /><Stat label="الوحدات" value={units.data?.length??0} icon={Radio} /><Stat label="متاحة" value={units.data?.filter(u=>u.status==='available').length??0} icon={Activity} /></div><section className="panel mb-3"><div className="panel-head"><h2>تسجيل بلاغ جديد</h2></div><div className="panel-body"><form onSubmit={createCall} className="row g-3 align-items-end"><div className="col-md-2"><label className="form-label">الجهة</label><select name="callType" className="form-select"><option value="police">الشرطة</option><option value="ems">الإسعاف</option><option value="fire">الدفاع المدني</option><option value="security">الأمن</option></select></div><div className="col-md-3"><label className="form-label">عنوان البلاغ</label><input name="title" className="form-control" minLength={2} maxLength={120} required /></div><div className="col-md-3"><label className="form-label">الموقع</label><input name="location" className="form-control" minLength={2} maxLength={160} required /></div><div className="col-md-2"><label className="form-label">الأولوية</label><select name="priority" className="form-select"><option value="normal">اعتيادية</option><option value="low">منخفضة</option><option value="high">مرتفعة</option><option value="critical">حرجة</option></select></div><div className="col-md-2"><label className="form-label">اسم المبلّغ</label><input name="callerName" className="form-control" maxLength={100} /></div><div className="col-md-9"><label className="form-label">ملاحظات</label><input name="notes" className="form-control" maxLength={1000} /></div><div className="col-md-3"><button className="btn-apex w-100" disabled={create.isPending}>إرسال البلاغ</button></div></form>{create.isError&&<div className="text-danger small mt-2">تعذّر تسجيل البلاغ.</div>}</div></section><div className="content-grid"><section className="panel"><div className="panel-head"><h2>قائمة البلاغات</h2></div><div className="table-wrap"><table className="table"><thead><tr><th>بلاغ</th><th>الجهة</th><th>الموقع</th><th>الأولوية</th><th>الحالة</th><th>إسناد وحدة</th></tr></thead><tbody>{calls.data?.length?calls.data.map(c=><tr key={c.id}><td><strong>{c.title}</strong><small className="d-block text-secondary">{c.callerName}</small></td><td><Status value={c.callType}/></td><td>{c.location}</td><td><Status value={c.priority}/></td><td><Status value={c.status}/></td><td><select className="form-select" aria-label="إسناد وحدة" defaultValue="" onChange={e=>{if(e.target.value&&window.confirm('تأكيد إسناد الوحدة إلى البلاغ؟'))assign.mutate({callId:c.id,data:{unitId:e.target.value}},{onSuccess:()=>refresh()});}}><option value="">اختيار وحدة</option>{units.data?.map(u=><option key={u.id} value={u.id}>{u.callsign} · {u.displayName}</option>)}</select></td></tr>):<TableEmpty colspan={6} title="لا توجد بلاغات مسجلة" />}</tbody></table></div></section><section className="panel"><div className="panel-head"><h2>الوحدات الميدانية</h2></div><div className="table-wrap"><table className="table"><thead><tr><th>النداء</th><th>الفريق</th><th>الحالة</th><th>الموقع / تحديث</th></tr></thead><tbody>{units.data?.length?units.data.map(u=><tr key={u.id}><td className="mono">{u.callsign}</td><td>{u.displayName}<small className="d-block text-secondary">{arStatus[u.department]}</small></td><td><select className="form-select" value={u.status} onChange={e=>update.mutate({unitId:u.id,data:{status:e.target.value as 'available'|'responding'|'on_scene'|'off_duty',location:u.location}},{onSuccess:()=>refresh()})}><option value="available">متاح</option><option value="responding">مستجيب</option><option value="on_scene">في الموقع</option><option value="off_duty">خارج الخدمة</option></select></td><td><input className="form-control" defaultValue={u.location} aria-label="تحديث موقع الوحدة" onBlur={e=>{if(e.target.value!==u.location)update.mutate({unitId:u.id,data:{status:u.status,location:e.target.value}},{onSuccess:()=>refresh()});}} /></td></tr>):<TableEmpty colspan={4} title="لا توجد وحدات" />}</tbody></table></div></section></div></>}</>;
}

function PolicePage() {
 const[search,setSearch]=useState('');const q=useSearchPoliceRecords(search?{search}:undefined);const cache=useQueryClient();const issue=useCreateCitation();const[notice,setNotice]=useState('');
  function submit(e:FormEvent<HTMLFormElement>){e.preventDefault();const form=e.currentTarget;const f=new FormData(form);if(!window.confirm('تأكيد إصدار المخالفة وتسجيلها على ملف المواطن؟'))return;issue.mutate({data:{citizenIdentityNumber:String(f.get('citizenIdentityNumber')),amount:Number(f.get('amount')),reason:String(f.get('reason'))}},{onSuccess:()=>{setNotice('تم إصدار المخالفة بنجاح.');form.reset();cache.invalidateQueries({queryKey:getSearchPoliceRecordsQueryKey()});cache.invalidateQueries({queryKey:getListBankAccountsQueryKey()});cache.invalidateQueries({queryKey:getListTransactionsQueryKey()});}});}
  return <><PageTitle eyebrow="إنفاذ القانون" title="السجلات الأمنية" description="استعرض السجلات وأصدر المخالفات باستخدام رقم الهوية." />{notice&&<div className="toast-note mb-3">{notice}</div>}<section className="panel mb-3"><div className="panel-head"><h2>إصدار مخالفة</h2></div><div className="panel-body"><form className="row g-3 align-items-end" onSubmit={submit}><div className="col-md-3"><label className="form-label">رقم هوية المواطن</label><input name="citizenIdentityNumber" className="form-control" placeholder="APX-…" required /></div><div className="col-md-2"><label className="form-label">قيمة المخالفة</label><input name="amount" type="number" min=".01" step=".01" className="form-control" required /></div><div className="col-md-5"><label className="form-label">سبب المخالفة</label><input name="reason" minLength={4} maxLength={500} className="form-control" required /></div><div className="col-md-2"><button className="btn-apex w-100" disabled={issue.isPending}>إصدار</button></div></form>{issue.isError&&<p className="text-danger small mt-2">تعذّر إصدار المخالفة؛ تحقق من رقم الهوية والصلاحية.</p>}</div></section><div className="searchbox mb-3"><Search /><input className="form-control" value={search} onChange={e=>setSearch(e.target.value)} placeholder="بحث بالاسم أو رقم الهوية أو السجل…" data-testid="input-police-search" /></div>{q.isLoading?<LoadingState />:q.isError?<QueryState error retry={()=>q.refetch()} />:<RecordsTable records={q.data||[]} type="police" />}</>;
}
function RecordsTable({records,type}:{records:any[];type:'police'|'medical'}) { return <div className="panel"><div className="table-wrap"><table className="table"><thead><tr><th>المواطن / رقم الهوية</th><th>نوع السجل</th><th>الملخص</th>{type==='police'&&<th>المبلغ</th>}{type==='medical'&&<th>فصيلة الدم</th>}<th>التاريخ</th></tr></thead><tbody>{records.length?records.map((r:any)=><tr key={r.id}><td><strong>{r.citizenName}</strong><small className="d-block mono">{type==='police'?r.citizenIdentityNumber:r.citizenDiscordUserId}</small></td><td><Status value={r.recordType||r.reportType}/></td><td style={{whiteSpace:'normal',minWidth:220}}>{r.summary}</td>{type==='police'?<td>{r.amount===null?'—':cash(r.amount)}</td>:<td>{r.bloodType||'—'}</td>}<td>{dateText(r.createdAt)}</td></tr>):<TableEmpty colspan={type==='police'?5:5} title="لا توجد سجلات مطابقة" />}</tbody></table></div></div>; }

function MedicalPage() {
 const[search,setSearch]=useState('');const q=useSearchMedicalRecords(search?{search}:undefined);const cache=useQueryClient();const create=useCreateMedicalReport();const[notice,setNotice]=useState('');
 function submit(e:FormEvent<HTMLFormElement>){e.preventDefault();const form=e.currentTarget;const f=new FormData(form);create.mutate({data:{citizenDiscordUserId:String(f.get('citizenId')),reportType:String(f.get('reportType')) as 'pcr'|'medical_update'|'forensic',summary:String(f.get('summary')),bloodType:String(f.get('bloodType'))||null}},{onSuccess:()=>{setNotice('تم حفظ التقرير الطبي.');form.reset();cache.invalidateQueries({queryKey:getSearchMedicalRecordsQueryKey()});}});}
 return <><PageTitle eyebrow="الخدمات الطبية" title="سجل الرعاية الصحية" description="استعراض السجلات الطبية وإضافة تقارير الرعاية." />{notice&&<div className="toast-note mb-3">{notice}</div>}<section className="panel mb-3"><div className="panel-head"><h2>إضافة تقرير رعاية</h2></div><div className="panel-body"><form className="row g-3 align-items-end" onSubmit={submit}><div className="col-md-3"><label className="form-label">معرّف المواطن</label><input name="citizenId" className="form-control" required /></div><div className="col-md-2"><label className="form-label">نوع التقرير</label><select name="reportType" className="form-select"><option value="medical_update">تحديث طبي</option><option value="pcr">فحص طبي</option><option value="forensic">طب شرعي</option></select></div><div className="col-md-2"><label className="form-label">فصيلة الدم</label><input name="bloodType" className="form-control" placeholder="اختياري" /></div><div className="col-md-3"><label className="form-label">ملخص الرعاية</label><input name="summary" className="form-control" minLength={5} maxLength={2000} required /></div><div className="col-md-2"><button className="btn-apex w-100" disabled={create.isPending}>حفظ التقرير</button></div></form>{create.isError&&<p className="text-danger small mt-2">تعذّر حفظ التقرير الطبي.</p>}</div></section><div className="searchbox mb-3"><Search /><input className="form-control" value={search} onChange={e=>setSearch(e.target.value)} placeholder="ابحث في سجلات المرضى…" data-testid="input-medical-search" /></div>{q.isLoading?<LoadingState />:q.isError?<QueryState error retry={()=>q.refetch()} />:<RecordsTable records={q.data||[]} type="medical" />}</>;
}

function CommunityPage() {
 const properties=useListProperties();const businesses=useListBusinesses();
 return <><PageTitle eyebrow="الحياة المدنية" title="المجتمع والأعمال" description="الأملاك والمنشآت المسجلة ضمن بيانات المدينة." />{properties.isError||businesses.isError?<QueryState error retry={()=>{properties.refetch();businesses.refetch();}} />:properties.isLoading||businesses.isLoading?<LoadingState />:<div className="content-grid"><section className="panel"><div className="panel-head"><h2><MapPinned size={17} className="ms-2" />العقارات</h2><span className="status-pill">{properties.data?.length??0} سجل</span></div><div className="table-wrap"><table className="table"><thead><tr><th>العنوان</th><th>النوع</th><th>المالك</th><th>حاملو المفاتيح</th></tr></thead><tbody>{properties.data?.length?properties.data.map(p=><tr key={p.id}><td className="fw-bold">{p.address}</td><td>{p.propertyType}</td><td className="mono">{p.ownerDiscordUserId}</td><td>{p.keyholderCount}</td></tr>):<TableEmpty colspan={4} title="لا توجد عقارات مسجلة" />}</tbody></table></div></section><section className="panel"><div className="panel-head"><h2><Building2 size={17} className="ms-2" />المنشآت</h2><span className="status-pill">{businesses.data?.length??0} سجل</span></div><div className="table-wrap"><table className="table"><thead><tr><th>المنشأة</th><th>الترخيص</th><th>الموظفون</th><th>الآيبان</th></tr></thead><tbody>{businesses.data?.length?businesses.data.map(b=><tr key={b.id}><td><strong>{b.name}</strong><small className="d-block mono">{b.ownerDiscordUserId}</small></td><td><Status value={b.licenseStatus}/></td><td>{b.employeeCount}</td><td className="mono">{b.iban}</td></tr>):<TableEmpty colspan={4} title="لا توجد منشآت مسجلة" />}</tbody></table></div></section></div>}</>;
}

function LocalAccountsPanel() {
  const [rows, setRows] = useState<Array<{id:string;username:string;status:string;permissions:string[]}>>([]);
  const [error, setError] = useState(false);
  const [saving, setSaving] = useState('');
  const options = ['dashboard:read','citizens:read','banking:read','banking:manage','dispatch:read','dispatch:manage','police:read','police:manage','medical:read','medical:manage','community:read'];
  useEffect(() => { fetch('/api/apex/admin/local-accounts').then(async r => { if (!r.ok) throw new Error(); setRows(await r.json()); }).catch(() => setError(true)); }, []);
  async function save(event: FormEvent<HTMLFormElement>, account: typeof rows[number]) {
    event.preventDefault();
    const form = new FormData(event.currentTarget);
    const status = String(form.get('status'));
    const permissions = options.filter(p => form.getAll('permission').includes(p));
    setSaving(account.id);
    try {
      const response = await fetch(`/api/apex/admin/local-accounts/${encodeURIComponent(account.id)}`, {
        method:'PUT', headers:{'content-type':'application/json'}, body:JSON.stringify({status, permissions}),
      });
      if (!response.ok) throw new Error();
      setRows(all => all.map(row => row.id === account.id ? {...row,status,permissions} : row));
    } catch { setError(true); }
    finally { setSaving(''); }
  }
  return <section className="panel mb-3">
    <div className="panel-head"><h2><Users size={17} className="ms-2" />حسابات الموقع المحلية</h2></div>
    <div className="panel-body"><p className="text-secondary small">الحسابات الجديدة مفعلة فوراً، لكنها لا تحصل على صلاحيات تشغيلية حتى يحددها المالك.</p>
      {error && <div className="text-danger small mb-2">تعذّر تحميل الحسابات أو حفظها.</div>}
      {rows.length ? rows.map(account => <form key={account.id} onSubmit={e=>save(e,account)} className="border-top py-3">
        <div className="d-flex flex-wrap align-items-center gap-3">
          <div className="me-auto"><strong>{account.username}</strong><div className="mono small text-secondary">{account.id}</div></div>
          <select name="status" className="form-select" style={{width:180}} defaultValue={account.status}>
            <option value="pending">دخول محدود بلا صلاحيات</option><option value="approved">مفعّل بالصلاحيات المحددة</option><option value="disabled">موقوف</option>
          </select>
          <button className="btn-apex" disabled={saving===account.id}>{saving===account.id?'جارٍ الحفظ…':'حفظ الصلاحيات'}</button>
        </div>
        <div className="d-flex flex-wrap gap-2 mt-3">{options.map(permission=><label key={permission} className="btn-quiet d-flex gap-2 align-items-center">
          <input type="checkbox" name="permission" value={permission} defaultChecked={account.permissions.includes(permission)} /><span className="mono">{permission}</span>
        </label>)}</div>
      </form>) : !error ? <Empty title="لا توجد حسابات" detail="ستظهر طلبات الحسابات الجديدة هنا." /> : null}
    </div>
  </section>;
}

function AdminPage() {
  const cache = useQueryClient();
  const policies = useListAccessPolicies();
  const events = useListSecurityEvents();
  const update = useUpdateAccessPolicy();
  const [notice, setNotice] = useState('');
  function afterSave(form: HTMLFormElement) {
    setNotice('تم حفظ سياسة الوصول.');
    form.reset();
    cache.invalidateQueries({ queryKey: getListAccessPoliciesQueryKey() });
    cache.invalidateQueries({ queryKey: getListSecurityEventsQueryKey() });
    cache.invalidateQueries({ queryKey: getGetAuthSessionQueryKey() });
  }

  function savePolicy(e: FormEvent<HTMLFormElement>, roleId: string, roleName: string) {
    e.preventDefault();
    const form = e.currentTarget;
    const values = new FormData(form);
    const selected = policyOptions.filter((permission) => values.getAll('permission').includes(permission));
    if (!window.confirm(`تأكيد تحديث صلاحيات دور ${roleName}؟`)) return;
    update.mutate(
      { roleId, data: { roleName: String(values.get('roleName')), permissions: selected } },
      { onSuccess: () => afterSave(form) },
    );
  }

  function createPolicy(e: FormEvent<HTMLFormElement>) {
    e.preventDefault();
    const form = e.currentTarget;
    const values = new FormData(form);
    const roleId = String(values.get('roleId')).trim();
    const roleName = String(values.get('roleName')).trim();
    const selected = policyOptions.filter((permission) => values.getAll('permission').includes(permission));
    if (!window.confirm(`إضافة سياسة الصلاحيات للدور ${roleName}؟`)) return;
    update.mutate(
      { roleId, data: { roleName, permissions: selected } },
      { onSuccess: () => afterSave(form) },
    );
  }

  return <>
    <PageTitle eyebrow="التحكم والأمان / المالك" title="إدارة السياسات" description="إدارة صلاحيات أدوار ديسكورد ومراجعة سجل أحداث الأمان." />
    {notice && <div className="toast-note mb-3">{notice}</div>}
    {policies.isError || events.isError
      ? <QueryState error retry={() => { policies.refetch(); events.refetch(); }} />
      : policies.isLoading || events.isLoading
        ? <LoadingState />
        : <>
          <LocalAccountsPanel />
          <section className="panel mb-3">
            <div className="panel-head"><h2><Shield size={17} className="ms-2" />سياسات الوصول حسب الدور</h2></div>
            {policies.data?.map((policy) =>
              <form key={policy.roleId} onSubmit={(e) => savePolicy(e, policy.roleId, policy.roleName)} className="panel-body border-bottom">
                <div className="d-flex flex-wrap align-items-end gap-3">
                  <div style={{ minWidth: 220, flex: '1 1 220px' }}>
                    <label className="form-label">اسم الدور</label>
                    <input name="roleName" className="form-control" defaultValue={policy.roleName} maxLength={80} required />
                  </div>
                  <div className="mono text-secondary">{policy.roleId}</div>
                  <button className="btn-apex" disabled={update.isPending}>حفظ السياسة</button>
                </div>
                <div className="d-flex flex-wrap gap-2 mt-3">
                  {policyOptions.map((permission) =>
                    <label key={permission} className="btn-quiet d-flex gap-2 align-items-center">
                      <input type="checkbox" name="permission" value={permission} defaultChecked={policy.permissions.includes(permission)} />
                      <span className="mono">{permission}</span>
                    </label>,
                  )}
                </div>
              </form>,
            )}
            <form onSubmit={createPolicy} className="panel-body border-bottom">
              <h3 className="h6 mb-3">إضافة دور جديد</h3>
              <div className="row g-3 align-items-end">
                <div className="col-md-4">
                  <label className="form-label">معرّف دور ديسكورد</label>
                  <input name="roleId" className="form-control mono" inputMode="numeric" minLength={17} maxLength={22} pattern="[0-9]{17,22}" required />
                </div>
                <div className="col-md-4">
                  <label className="form-label">اسم الدور</label>
                  <input name="roleName" className="form-control" minLength={2} maxLength={80} required />
                </div>
                <div className="col-md-4">
                  <button className="btn-apex w-100" disabled={update.isPending}>إضافة السياسة</button>
                </div>
              </div>
              <div className="d-flex flex-wrap gap-2 mt-3">
                {policyOptions.map((permission) =>
                  <label key={`new-${permission}`} className="btn-quiet d-flex gap-2 align-items-center">
                    <input type="checkbox" name="permission" value={permission} />
                    <span className="mono">{permission}</span>
                  </label>,
                )}
              </div>
              {update.isError && <p className="text-danger small mt-3 mb-0">تعذّر حفظ سياسة الدور. تحقق من المعرّف والصلاحيات.</p>}
            </form>
            {!policies.data?.length && <div className="panel-body"><Empty title="لا توجد أدوار مضبوطة" detail="أضف معرّف دور ديسكورد وحدد صلاحياته." /></div>}
          </section>
          <section className="panel">
            <div className="panel-head"><h2><Activity size={17} className="ms-2" />سجل أحداث الأمان</h2></div>
            <div className="table-wrap">
              <table className="table">
                <thead><tr><th>الحدث</th><th>المنفّذ</th><th>الهدف</th><th>التفاصيل</th><th>الإجراء</th><th>التاريخ</th></tr></thead>
                <tbody>
                  {events.data?.length
                    ? events.data.map((event) =>
                      <tr key={event.id}>
                        <td><Status value={event.eventType} /></td>
                        <td className="mono">{event.actorDiscordUserId}</td>
                        <td className="mono">{event.targetDiscordUserId || '—'}</td>
                        <td>{event.details}</td><td>{event.actionTaken}</td><td>{dateText(event.createdAt)}</td>
                      </tr>,
                    )
                    : <TableEmpty colspan={6} title="لا توجد أحداث أمنية مسجلة" />}
                </tbody>
              </table>
            </div>
          </section>
        </>}
  </>;
}
function PermissionGate({user,permission,children}:{user:{permissions:string[];isOwner:boolean};permission:string;children:ReactNode}) { return user.isOwner || user.permissions.includes(permission) ? children : <AccessDenied ownerOnly={false} />; }
function AccessDenied({ownerOnly=true}:{ownerOnly?:boolean}){return <div className="panel panel-body text-center"><div className="empty-mark"><Shield size={18}/></div><h2 className="h5">{ownerOnly?'هذه الصفحة للمالك فقط':'لا تملك صلاحية هذه الصفحة'}</h2><p className="text-secondary small">{ownerOnly?'إدارة السياسات محصورة بمالك الخادم.':'اطلب من مالك الخادم منح حسابك الصلاحية المناسبة.'}</p></div>}

export default App;
