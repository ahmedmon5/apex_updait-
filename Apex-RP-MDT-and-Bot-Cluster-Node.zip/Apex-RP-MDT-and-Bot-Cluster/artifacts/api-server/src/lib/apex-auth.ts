import {
  createCipheriv,
  createDecipheriv,
  createHash,
  createHmac,
  randomBytes,
  scrypt as scryptCallback,
  timingSafeEqual,
  createDecipheriv as createDecipher,
  createCipheriv as createCipher,
  createHmac as makeHmac,
} from "node:crypto";
import { and, eq, or, sql } from "drizzle-orm";
import { OAuth2Client } from "google-auth-library";
import {
  Router,
  type IRouter,
  type NextFunction,
  type Request,
  type Response,
} from "express";
import {
  db,
  accessPoliciesTable,
  citizensTable,
  googleOAuthLinksTable,
  googleStandaloneAccountsTable,
  robloxOAuthLinksTable,
  localAuthAccountsTable,
  localAuthBootstrapTable,
} from "@workspace/db";
import { GetAuthSessionResponse } from "@workspace/api-zod";

const API_BASE = "https://discord.com/api/v10";
const SESSION_COOKIE = "apex_session";
const STATE_COOKIE = "apex_oauth_state";
const GOOGLE_STATE_COOKIE = "apex_google_oauth_state";
const ROBLOX_STATE_COOKIE = "apex_roblox_oauth_state";
const GOOGLE_SIGN_IN_ENABLED = false;
const ROBLOX_SIGN_IN_ENABLED = false;
const SESSION_TTL_MS = 12 * 60 * 60 * 1000;
const MEMBER_CACHE_TTL_MS = 45 * 1000;
const GOOGLE_STATE_TTL_MS = 10 * 60 * 1000;
const ROBLOX_STATE_TTL_MS = 10 * 60 * 1000;

export type ApexSession = {
  discordUserId: string;
  username: string;
  avatarUrl: string | null;
  accessToken: string;
  refreshToken: string;
  tokenExpiresAt: number;
  roleIds: string[];
  roleFetchedAt: number;
  authProvider?: "discord" | "google" | "local";
  googleSubject?: string;
  sessionVersion?: number;
};

declare global {
  namespace Express {
    interface Request {
      apexSession?: ApexSession;
      apexPermissions?: Set<string>;
      apexIsOwner?: boolean;
    }
  }
}

const memberCache = new Map<
  string,
  { roleIds: string[]; fetchedAt: number }
>();

function requiredEnv(name: string): string {
  const value = process.env[name];
  if (!value) throw new Error(`${name} is required for authentication`);
  return value;
}

function keyMaterial(): Buffer {
  return createHash("sha256")
    .update(`apex-auth-v2:${requiredEnv("SESSION_SECRET")}`, "utf8")
    .digest();
}

const totpAlphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ234567";
function deriveScrypt(password: string, salt: Buffer, length: number): Promise<Buffer> {
  return new Promise((resolve, reject) => {
    scryptCallback(password, salt, length, { N: 32768, r: 8, p: 1, maxmem: 64 * 1024 * 1024 }, (error, key) => {
      if (error) reject(error);
      else resolve(key as Buffer);
    });
  });
}

function base32Encode(bytes: Buffer): string {
  let bits = 0, value = 0, output = "";
  for (const byte of bytes) {
    value = (value << 8) | byte; bits += 8;
    while (bits >= 5) { output += totpAlphabet[(value >>> (bits - 5)) & 31]; bits -= 5; }
  }
  if (bits) output += totpAlphabet[(value << (5 - bits)) & 31];
  return output;
}

function base32Decode(text: string): Buffer {
  let bits = 0, value = 0;
  const out: number[] = [];
  for (const char of text.replace(/=+$/g, "").toUpperCase()) {
    const n = totpAlphabet.indexOf(char);
    if (n < 0) throw new Error("Invalid authenticator secret");
    value = (value << 5) | n; bits += 5;
    if (bits >= 8) { out.push((value >>> (bits - 8)) & 255); bits -= 8; }
  }
  return Buffer.from(out);
}

function totpSecretKey(): Buffer {
  return createHash("sha256").update(`apex-totp-v1:${requiredEnv("SESSION_SECRET")}`).digest();
}

function encryptTotpSecret(secret: string): string {
  const iv = randomBytes(12);
  const cipher = createCipher("aes-256-gcm", totpSecretKey(), iv);
  const ciphertext = Buffer.concat([cipher.update(secret, "utf8"), cipher.final()]);
  return Buffer.concat([iv, cipher.getAuthTag(), ciphertext]).toString("base64url");
}

function decryptTotpSecret(encoded: string): string {
  const bytes = Buffer.from(encoded, "base64url");
  const decipher = createDecipher("aes-256-gcm", totpSecretKey(), bytes.subarray(0, 12));
  decipher.setAuthTag(bytes.subarray(12, 28));
  return Buffer.concat([decipher.update(bytes.subarray(28)), decipher.final()]).toString("utf8");
}

async function makePasswordHash(password: string): Promise<string> {
  const salt = randomBytes(16);
  const hash = await deriveScrypt(password, salt, 64);
  return `${salt.toString("base64url")}.${hash.toString("base64url")}`;
}

async function checkPassword(password: string, encoded: string): Promise<boolean> {
  try {
    const [saltText, hashText] = encoded.split(".");
    const expected = Buffer.from(hashText, "base64url");
    const actual = await deriveScrypt(password, Buffer.from(saltText, "base64url"), expected.length);
    return actual.length === expected.length && timingSafeEqual(actual, expected);
  } catch { return false; }
}

function verifyTotp(secret: string, code: string): number | null {
  if (!/^\d{6}$/.test(code)) return null;
  const key = base32Decode(secret);
  const current = Math.floor(Date.now() / 30_000);
  for (let step = current - 1; step <= current + 1; step++) {
    const counter = Buffer.alloc(8); counter.writeBigUInt64BE(BigInt(step));
    const digest = createHmac("sha1", key).update(counter).digest();
    const offset = digest[digest.length - 1] & 15;
    const binary = ((digest[offset] & 127) << 24) | ((digest[offset + 1] & 255) << 16) | ((digest[offset + 2] & 255) << 8) | (digest[offset + 3] & 255);
    if (safeEqual(String(binary % 1_000_000).padStart(6, "0"), code)) return step;
  }
  return null;
}

function localSession(account: typeof localAuthAccountsTable.$inferSelect): ApexSession {
  return {
    discordUserId: `local:${account.id}`, username: account.username, avatarUrl: null,
    accessToken: "local", refreshToken: "local", tokenExpiresAt: Date.now() + SESSION_TTL_MS,
    roleIds: [], roleFetchedAt: Date.now(), authProvider: "local", sessionVersion: account.sessionVersion,
  };
}

function encrypt(payload: ApexSession): string {
  const iv = randomBytes(12);
  const cipher = createCipheriv("aes-256-gcm", keyMaterial(), iv);
  const encrypted = Buffer.concat([
    cipher.update(JSON.stringify(payload), "utf8"),
    cipher.final(),
  ]);
  const tag = cipher.getAuthTag();
  return Buffer.concat([iv, tag, encrypted]).toString("base64url");
}

function decrypt(value: string | undefined): ApexSession | null {
  if (!value) return null;
  try {
    const bytes = Buffer.from(value, "base64url");
    if (bytes.length < 29) return null;
    const decipher = createDecipheriv(
      "aes-256-gcm",
      keyMaterial(),
      bytes.subarray(0, 12),
    );
    decipher.setAuthTag(bytes.subarray(12, 28));
    const clear = Buffer.concat([
      decipher.update(bytes.subarray(28)),
      decipher.final(),
    ]).toString("utf8");
    const parsed = JSON.parse(clear) as ApexSession;
    if (
      typeof parsed.discordUserId !== "string" ||
      typeof parsed.accessToken !== "string" ||
      typeof parsed.refreshToken !== "string" ||
      !Array.isArray(parsed.roleIds)
    ) {
      return null;
    }
    if (parsed.authProvider === "google" && !parsed.googleSubject) return null;
    if (parsed.tokenExpiresAt + SESSION_TTL_MS < Date.now()) return null;
    return parsed;
  } catch {
    return null;
  }
}

function setSessionCookie(res: Response, session: ApexSession): void {
  res.cookie(SESSION_COOKIE, encrypt(session), {
    httpOnly: true,
    secure: process.env.NODE_ENV === "production",
    sameSite: "strict",
    maxAge: SESSION_TTL_MS,
    path: "/",
  });
}

function callbackUrl(req: Request): string {
  if (process.env.DISCORD_REDIRECT_URI) {
    return process.env.DISCORD_REDIRECT_URI;
  }
  const origin = `${req.protocol}://${req.get("host")}`;
  return new URL("/api/auth/discord/callback", origin).toString();
}

function googleCallbackUrl(req: Request): string {
  if (process.env.GOOGLE_REDIRECT_URI) {
    return process.env.GOOGLE_REDIRECT_URI;
  }
  const origin = `${req.protocol}://${req.get("host")}`;
  return new URL("/api/auth/google/callback", origin).toString();
}

function safeEqual(left: string | undefined, right: string | undefined): boolean {
  if (!left || !right) return false;
  const a = Buffer.from(left);
  const b = Buffer.from(right);
  return a.length === b.length && timingSafeEqual(a, b);
}

type GoogleOAuthState = {
  state: string;
  nonce: string;
  codeVerifier: string;
  flow: "login" | "link";
  discordUserId: string | null;
  createdAt: number;
};

type GoogleIdentity = {
  subject: string;
  email: string;
  name: string;
  avatarUrl: string | null;
};

type RobloxOAuthState = {
  state: string;
  codeVerifier: string;
  flow: "login" | "link";
  discordUserId: string | null;
  createdAt: number;
};

type RobloxIdentity = {
  subject: string;
  username: string;
};

function robloxCallbackUrl(req: Request): string {
  if (process.env.ROBLOX_REDIRECT_URI) {
    return process.env.ROBLOX_REDIRECT_URI;
  }
  const origin = `${req.protocol}://${req.get("host")}`;
  return new URL("/api/auth/roblox/callback", origin).toString();
}

function signRobloxOAuthState(state: RobloxOAuthState): string {
  const payload = Buffer.from(JSON.stringify(state)).toString("base64url");
  const signature = createHmac("sha256", keyMaterial())
    .update(payload)
    .digest("base64url");
  return `${payload}.${signature}`;
}

function parseRobloxOAuthState(value: string | undefined): RobloxOAuthState | null {
  if (!value) return null;
  const parts = value.split(".");
  if (parts.length !== 2 || !parts[0] || !parts[1]) return null;
  const [payload, signature] = parts;
  const expectedSignature = createHmac("sha256", keyMaterial())
    .update(payload)
    .digest("base64url");
  if (!safeEqual(signature, expectedSignature)) return null;
  try {
    const parsed = JSON.parse(
      Buffer.from(payload, "base64url").toString("utf8"),
    ) as RobloxOAuthState;
    if (
      typeof parsed.state !== "string" ||
      typeof parsed.codeVerifier !== "string" ||
      !["login", "link"].includes(parsed.flow) ||
      (parsed.discordUserId !== null &&
        typeof parsed.discordUserId !== "string") ||
      typeof parsed.createdAt !== "number" ||
      parsed.createdAt > Date.now() + 30_000 ||
      Date.now() - parsed.createdAt > ROBLOX_STATE_TTL_MS ||
      (parsed.flow === "link" && !parsed.discordUserId) ||
      (parsed.flow === "login" && parsed.discordUserId !== null)
    ) {
      return null;
    }
    return parsed;
  } catch {
    return null;
  }
}

function beginRobloxOAuth(
  req: Request,
  res: Response,
  flow: RobloxOAuthState["flow"],
  discordUserId: string | null,
): void {
  if (
    !ROBLOX_SIGN_IN_ENABLED ||
    !process.env.ROBLOX_CLIENT_ID ||
    !process.env.ROBLOX_CLIENT_SECRET
  ) {
    res.redirect("/?auth=roblox-unavailable");
    return;
  }
  const state: RobloxOAuthState = {
    state: randomBytes(32).toString("base64url"),
    codeVerifier: randomBytes(32).toString("base64url"),
    flow,
    discordUserId,
    createdAt: Date.now(),
  };
  res.cookie(ROBLOX_STATE_COOKIE, signRobloxOAuthState(state), {
    httpOnly: true,
    secure: process.env.NODE_ENV === "production",
    sameSite: "lax",
    maxAge: ROBLOX_STATE_TTL_MS,
    path: "/api/auth/roblox/callback",
  });
  const url = new URL("https://apis.roblox.com/oauth/v1/authorize");
  url.searchParams.set("client_id", requiredEnv("ROBLOX_CLIENT_ID"));
  url.searchParams.set("redirect_uri", robloxCallbackUrl(req));
  url.searchParams.set("response_type", "code");
  url.searchParams.set("scope", "openid profile");
  url.searchParams.set("state", state.state);
  url.searchParams.set(
    "code_challenge",
    createHash("sha256").update(state.codeVerifier).digest("base64url"),
  );
  url.searchParams.set("code_challenge_method", "S256");
  url.searchParams.set("prompt", "select_account");
  res.redirect(url.toString());
}

async function exchangeRobloxCode(
  req: Request,
  code: string,
  codeVerifier: string,
): Promise<string> {
  const body = new URLSearchParams({
    client_id: requiredEnv("ROBLOX_CLIENT_ID"),
    client_secret: requiredEnv("ROBLOX_CLIENT_SECRET"),
    code,
    code_verifier: codeVerifier,
    grant_type: "authorization_code",
    redirect_uri: robloxCallbackUrl(req),
  });
  const response = await fetch("https://apis.roblox.com/oauth/v1/token", {
    method: "POST",
    headers: { "content-type": "application/x-www-form-urlencoded" },
    body,
    signal: AbortSignal.timeout(10_000),
  });
  if (!response.ok) {
    throw new Error(`Roblox token exchange failed (${response.status})`);
  }
  const token = (await response.json()) as { access_token?: string };
  if (!token.access_token) throw new Error("Roblox did not return an access token");
  return token.access_token;
}

async function fetchRobloxIdentity(accessToken: string): Promise<RobloxIdentity> {
  const response = await fetch("https://apis.roblox.com/oauth/v1/userinfo", {
    headers: { authorization: `Bearer ${accessToken}`, accept: "application/json" },
    signal: AbortSignal.timeout(10_000),
  });
  if (!response.ok) {
    throw new Error(`Roblox user info failed (${response.status})`);
  }
  const identity = (await response.json()) as {
    sub?: string;
    preferred_username?: string;
    name?: string;
    nickname?: string;
  };
  if (typeof identity.sub !== "string" || !identity.sub) {
    throw new Error("Roblox returned an invalid identity");
  }
  return {
    subject: identity.sub,
    username:
      identity.preferred_username ||
      identity.nickname ||
      identity.name ||
      identity.sub,
  };
}

function signGoogleOAuthState(state: GoogleOAuthState): string {
  const payload = Buffer.from(JSON.stringify(state)).toString("base64url");
  const signature = createHmac("sha256", keyMaterial())
    .update(payload)
    .digest("base64url");
  return `${payload}.${signature}`;
}

function parseGoogleOAuthState(value: string | undefined): GoogleOAuthState | null {
  if (!value) return null;
  const parts = value.split(".");
  if (parts.length !== 2 || !parts[0] || !parts[1]) return null;
  const [payload, signature] = parts;
  const expectedSignature = createHmac("sha256", keyMaterial())
    .update(payload)
    .digest("base64url");
  if (!safeEqual(signature, expectedSignature)) return null;

  try {
    const parsed = JSON.parse(
      Buffer.from(payload, "base64url").toString("utf8"),
    ) as GoogleOAuthState;
    if (
      typeof parsed.state !== "string" ||
      typeof parsed.nonce !== "string" ||
      typeof parsed.codeVerifier !== "string" ||
      !["login", "link"].includes(parsed.flow) ||
      (parsed.discordUserId !== null &&
        typeof parsed.discordUserId !== "string") ||
      typeof parsed.createdAt !== "number" ||
      parsed.createdAt > Date.now() + 30_000 ||
      Date.now() - parsed.createdAt > GOOGLE_STATE_TTL_MS
    ) {
      return null;
    }
    if (
      (parsed.flow === "link" && !parsed.discordUserId) ||
      (parsed.flow === "login" && parsed.discordUserId !== null)
    ) {
      return null;
    }
    return parsed;
  } catch {
    return null;
  }
}

function encryptOpaque(value: string): string {
  const iv = randomBytes(12);
  const cipher = createCipheriv("aes-256-gcm", keyMaterial(), iv);
  const ciphertext = Buffer.concat([
    cipher.update(value, "utf8"),
    cipher.final(),
  ]);
  return Buffer.concat([iv, cipher.getAuthTag(), ciphertext]).toString(
    "base64url",
  );
}

function decryptOpaque(value: string): string | null {
  try {
    const bytes = Buffer.from(value, "base64url");
    if (bytes.length < 29) return null;
    const decipher = createDecipheriv(
      "aes-256-gcm",
      keyMaterial(),
      bytes.subarray(0, 12),
    );
    decipher.setAuthTag(bytes.subarray(12, 28));
    return Buffer.concat([
      decipher.update(bytes.subarray(28)),
      decipher.final(),
    ]).toString("utf8");
  } catch {
    return null;
  }
}

async function persistLinkedDiscordRefreshToken(
  discordUserId: string,
  refreshToken: string,
): Promise<void> {
  const [googleLink] = await db
    .select({ googleSubject: googleOAuthLinksTable.googleSubject })
    .from(googleOAuthLinksTable)
    .where(eq(googleOAuthLinksTable.discordUserId, discordUserId))
    .limit(1);
  if (googleLink) {
    await db
      .update(googleOAuthLinksTable)
      .set({
        encryptedDiscordRefreshToken: encryptOpaque(refreshToken),
        updatedAt: new Date(),
      })
      .where(eq(googleOAuthLinksTable.googleSubject, googleLink.googleSubject));
  }
  const [robloxLink] = await db
    .select({ robloxSubject: robloxOAuthLinksTable.robloxSubject })
    .from(robloxOAuthLinksTable)
    .where(eq(robloxOAuthLinksTable.discordUserId, discordUserId))
    .limit(1);
  if (robloxLink) {
    await db
      .update(robloxOAuthLinksTable)
      .set({
        encryptedDiscordRefreshToken: encryptOpaque(refreshToken),
        updatedAt: new Date(),
      })
      .where(eq(robloxOAuthLinksTable.robloxSubject, robloxLink.robloxSubject));
  }
}

function beginGoogleOAuth(
  req: Request,
  res: Response,
  flow: GoogleOAuthState["flow"],
  discordUserId: string | null,
): void {
  if (
    !GOOGLE_SIGN_IN_ENABLED ||
    !process.env.GOOGLE_CLIENT_ID ||
    !process.env.GOOGLE_CLIENT_SECRET
  ) {
    res.redirect("/?auth=google-unavailable");
    return;
  }
  const state: GoogleOAuthState = {
    state: randomBytes(32).toString("base64url"),
    nonce: randomBytes(32).toString("base64url"),
    codeVerifier: randomBytes(32).toString("base64url"),
    flow,
    discordUserId,
    createdAt: Date.now(),
  };
  res.cookie(GOOGLE_STATE_COOKIE, signGoogleOAuthState(state), {
    httpOnly: true,
    secure: process.env.NODE_ENV === "production",
    sameSite: "lax",
    maxAge: GOOGLE_STATE_TTL_MS,
    path: "/api/auth/google/callback",
  });

  const url = new URL("https://accounts.google.com/o/oauth2/v2/auth");
  url.searchParams.set("client_id", requiredEnv("GOOGLE_CLIENT_ID"));
  url.searchParams.set("redirect_uri", googleCallbackUrl(req));
  url.searchParams.set("response_type", "code");
  url.searchParams.set("scope", "openid email profile");
  url.searchParams.set("state", state.state);
  url.searchParams.set("nonce", state.nonce);
  url.searchParams.set(
    "code_challenge",
    createHash("sha256").update(state.codeVerifier).digest("base64url"),
  );
  url.searchParams.set("code_challenge_method", "S256");
  url.searchParams.set("prompt", "select_account");
  res.redirect(url.toString());
}

async function exchangeGoogleCode(
  req: Request,
  code: string,
  codeVerifier: string,
): Promise<string> {
  const body = new URLSearchParams({
    client_id: requiredEnv("GOOGLE_CLIENT_ID"),
    client_secret: requiredEnv("GOOGLE_CLIENT_SECRET"),
    code,
    code_verifier: codeVerifier,
    grant_type: "authorization_code",
    redirect_uri: googleCallbackUrl(req),
  });
  const response = await fetch("https://oauth2.googleapis.com/token", {
    method: "POST",
    headers: { "content-type": "application/x-www-form-urlencoded" },
    body,
    signal: AbortSignal.timeout(10_000),
  });
  if (!response.ok) {
    throw new Error(`Google token exchange failed (${response.status})`);
  }
  const token = (await response.json()) as { id_token?: string };
  if (!token.id_token) throw new Error("Google did not return an ID token");
  return token.id_token;
}

async function verifyGoogleIdentity(
  idToken: string,
  expectedNonce: string,
): Promise<GoogleIdentity> {
  const clientId = requiredEnv("GOOGLE_CLIENT_ID");
  const client = new OAuth2Client(clientId);
  const ticket = await client.verifyIdToken({
    idToken,
    audience: clientId,
  });
  const payload = ticket.getPayload();
  if (
    !payload?.sub ||
    !payload.email ||
    payload.email_verified !== true ||
    !safeEqual(payload.nonce, expectedNonce)
  ) {
    throw new Error("Google identity token was invalid");
  }
  return {
    subject: payload.sub,
    email: payload.email,
    name: payload.name || payload.email,
    avatarUrl: payload.picture || null,
  };
}

function googleLinkConflict(): Error {
  return Object.assign(new Error("Google account link conflict"), {
    status: 409,
    code: "GOOGLE_LINK_CONFLICT",
  });
}

async function saveGoogleLink(
  identity: GoogleIdentity,
  session: ApexSession,
): Promise<void> {
  const [googleLink] = await db
    .select()
    .from(googleOAuthLinksTable)
    .where(eq(googleOAuthLinksTable.googleSubject, identity.subject))
    .limit(1);
  if (googleLink && googleLink.discordUserId !== session.discordUserId) {
    throw googleLinkConflict();
  }

  const [discordLink] = await db
    .select()
    .from(googleOAuthLinksTable)
    .where(eq(googleOAuthLinksTable.discordUserId, session.discordUserId))
    .limit(1);
  if (discordLink && discordLink.googleSubject !== identity.subject) {
    throw googleLinkConflict();
  }

  const values = {
    discordUserId: session.discordUserId,
    googleEmail: identity.email,
    encryptedDiscordRefreshToken: encryptOpaque(session.refreshToken),
    updatedAt: new Date(),
  };
  if (googleLink) {
    await db
      .update(googleOAuthLinksTable)
      .set(values)
      .where(eq(googleOAuthLinksTable.googleSubject, identity.subject));
    return;
  }

  try {
    await db.insert(googleOAuthLinksTable).values({
      googleSubject: identity.subject,
      ...values,
    });
  } catch (error) {
    if (
      typeof error === "object" &&
      error !== null &&
      "code" in error &&
      (error as { code?: string }).code === "23505"
    ) {
      throw googleLinkConflict();
    }
    throw error;
  }
}

async function saveRobloxLink(identity: RobloxIdentity, session: ApexSession): Promise<void> {
  const [robloxLink] = await db
    .select()
    .from(robloxOAuthLinksTable)
    .where(eq(robloxOAuthLinksTable.robloxSubject, identity.subject))
    .limit(1);
  if (robloxLink && robloxLink.discordUserId !== session.discordUserId) {
    throw Object.assign(new Error("Roblox account link conflict"), {
      status: 409,
      code: "ROBLOX_LINK_CONFLICT",
    });
  }
  const [discordLink] = await db
    .select()
    .from(robloxOAuthLinksTable)
    .where(eq(robloxOAuthLinksTable.discordUserId, session.discordUserId))
    .limit(1);
  if (discordLink && discordLink.robloxSubject !== identity.subject) {
    throw Object.assign(new Error("Roblox account link conflict"), {
      status: 409,
      code: "ROBLOX_LINK_CONFLICT",
    });
  }
  const values = {
    discordUserId: session.discordUserId,
    robloxUsername: identity.username,
    encryptedDiscordRefreshToken: encryptOpaque(session.refreshToken),
    updatedAt: new Date(),
  };
  if (robloxLink) {
    await db.update(robloxOAuthLinksTable).set(values)
      .where(eq(robloxOAuthLinksTable.robloxSubject, identity.subject));
    return;
  }
  try {
    await db.insert(robloxOAuthLinksTable).values({
      robloxSubject: identity.subject,
      ...values,
    });
  } catch (error) {
    if (typeof error === "object" && error !== null && "code" in error &&
      (error as { code?: string }).code === "23505") {
      throw Object.assign(new Error("Roblox account link conflict"), {
        status: 409,
        code: "ROBLOX_LINK_CONFLICT",
      });
    }
    throw error;
  }
}

async function discordJson<T>(
  path: string,
  accessToken: string,
  init: RequestInit = {},
): Promise<T> {
  const response = await fetch(`${API_BASE}${path}`, {
    ...init,
    signal: AbortSignal.timeout(10_000),
    headers: {
      authorization: `Bearer ${accessToken}`,
      accept: "application/json",
      ...init.headers,
    },
  });
  if (!response.ok) {
    const error = new Error(`Discord API returned ${response.status}`);
    Object.assign(error, { status: response.status });
    throw error;
  }
  return (await response.json()) as T;
}

async function exchangeCode(req: Request, code: string): Promise<{
  access_token: string;
  refresh_token: string;
  expires_in: number;
}> {
  const body = new URLSearchParams({
    client_id: requiredEnv("DISCORD_CLIENT_ID"),
    client_secret: requiredEnv("DISCORD_CLIENT_SECRET"),
    grant_type: "authorization_code",
    code,
    redirect_uri: callbackUrl(req),
  });
  const response = await fetch(`${API_BASE}/oauth2/token`, {
    method: "POST",
    headers: { "content-type": "application/x-www-form-urlencoded" },
    body,
    signal: AbortSignal.timeout(10_000),
  });
  if (!response.ok) {
    throw new Error(`Discord token exchange failed (${response.status})`);
  }
  return (await response.json()) as {
    access_token: string;
    refresh_token: string;
    expires_in: number;
  };
}

async function refreshToken(session: ApexSession): Promise<ApexSession> {
  const body = new URLSearchParams({
    client_id: requiredEnv("DISCORD_CLIENT_ID"),
    client_secret: requiredEnv("DISCORD_CLIENT_SECRET"),
    grant_type: "refresh_token",
    refresh_token: session.refreshToken,
  });
  const response = await fetch(`${API_BASE}/oauth2/token`, {
    method: "POST",
    headers: { "content-type": "application/x-www-form-urlencoded" },
    body,
    signal: AbortSignal.timeout(10_000),
  });
  if (!response.ok) {
    const error = new Error("Discord session expired");
    Object.assign(error, { status: 401 });
    throw error;
  }
  const token = (await response.json()) as {
    access_token: string;
    refresh_token: string;
    expires_in: number;
  };
  await persistLinkedDiscordRefreshToken(
    session.discordUserId,
    token.refresh_token,
  );
  return {
    ...session,
    accessToken: token.access_token,
    refreshToken: token.refresh_token,
    tokenExpiresAt: Date.now() + token.expires_in * 1000,
    roleFetchedAt: 0,
  };
}

async function currentSession(req: Request, res: Response): Promise<ApexSession | null> {
  const cookieValue = req.cookies?.[SESSION_COOKIE] as string | undefined;
  let session = decrypt(cookieValue);
  if (!session) return null;

  if (session.authProvider === "local") {
    const rawId = session.discordUserId.replace(/^local:/, "");
    const [account] = await db.select().from(localAuthAccountsTable).where(eq(localAuthAccountsTable.id, rawId)).limit(1);
    if (!account || account.status === "disabled" || account.sessionVersion !== session.sessionVersion) return null;
    session.username = account.username;
    session.roleIds = [];
    req.apexSession = session;
    return session;
  }

  if (session.authProvider === "google") {
    const [account] = await db.select().from(googleStandaloneAccountsTable)
      .where(eq(googleStandaloneAccountsTable.googleSubject, session.googleSubject!)).limit(1);
    if (!account || account.status === "revoked") return null;
    session.username = account.username;
    session.avatarUrl = account.avatarUrl;
    session.roleIds = [];
    req.apexSession = session;
    return session;
  }

  if (session.tokenExpiresAt < Date.now() + 60_000) {
    session = await refreshToken(session);
    setSessionCookie(res, session);
  }

  const cached = memberCache.get(session.discordUserId);
  if (cached && Date.now() - cached.fetchedAt < MEMBER_CACHE_TTL_MS) {
    session.roleIds = cached.roleIds;
    session.roleFetchedAt = cached.fetchedAt;
    req.apexSession = session;
    return session;
  }

  const guildId = requiredEnv("DISCORD_GUILD_ID");
  const member = await discordJson<{ roles: string[] }>(
    `/users/@me/guilds/${encodeURIComponent(guildId)}/member`,
    session.accessToken,
  );
  if (!Array.isArray(member.roles)) throw new Error("Discord returned invalid member roles");

  session.roleIds = member.roles;
  session.roleFetchedAt = Date.now();
  memberCache.set(session.discordUserId, {
    roleIds: member.roles,
    fetchedAt: session.roleFetchedAt,
  });
  setSessionCookie(res, session);
  req.apexSession = session;
  return session;
}

async function googleAccountPermissions(session: ApexSession): Promise<string[]> {
  if (!session.googleSubject) return [];
  const [account] = await db.select().from(googleStandaloneAccountsTable)
    .where(eq(googleStandaloneAccountsTable.googleSubject, session.googleSubject)).limit(1);
  return account?.status === "approved" ? account.permissions : [];
}

export async function authSessionResponse(
  req: Request,
  res: Response,
): Promise<{ authenticated: false; user: null } | {
  authenticated: true;
  user: {
    discordUserId: string;
    username: string;
    avatarUrl: string | null;
    googleLinked: boolean;
    roleIds: string[];
    permissions: string[];
    isOwner: boolean;
  };
}> {
  try {
    const session = await currentSession(req, res);
    if (!session) return { authenticated: false, user: null };
    if (session.authProvider === "local") {
      const rawId = session.discordUserId.replace(/^local:/, "");
      const [account] = await db.select().from(localAuthAccountsTable).where(eq(localAuthAccountsTable.id, rawId)).limit(1);
      if (!account) return { authenticated: false, user: null };
      return {
        authenticated: true,
        user: {
          discordUserId: session.discordUserId, username: account.username, avatarUrl: null,
          googleLinked: false, roleIds: [], permissions: account.isOwner ? ["dashboard:read", "citizens:read", "banking:read", "banking:manage", "dispatch:read", "dispatch:manage", "police:read", "police:manage", "medical:read", "medical:manage", "community:read", "admin:read", "admin:manage"] : account.status === "approved" ? account.permissions : [],
          isOwner: account.isOwner,
        },
      };
    }
    if (session.authProvider === "google") {
      const [account] = await db.select().from(googleStandaloneAccountsTable)
        .where(eq(googleStandaloneAccountsTable.googleSubject, session.googleSubject!)).limit(1);
      if (!account) return { authenticated: false, user: null };
      return {
        authenticated: true,
        user: {
          discordUserId: `google:${session.googleSubject}`,
          username: account.username,
          avatarUrl: account.avatarUrl,
          googleLinked: false,
          roleIds: [],
          permissions: account.status === "approved" ? account.permissions : [],
          isOwner: false,
        },
      };
    }
    const isOwner = false;
    const policies = await db.select().from(accessPoliciesTable);
    const [googleLink] = await db
      .select({ googleSubject: googleOAuthLinksTable.googleSubject })
      .from(googleOAuthLinksTable)
      .where(eq(googleOAuthLinksTable.discordUserId, session.discordUserId))
      .limit(1);
    const permissions = isOwner
      ? ["dashboard:read", "citizens:read", "banking:read", "banking:manage", "dispatch:read", "dispatch:manage", "police:read", "police:manage", "medical:read", "medical:manage", "community:read", "admin:read", "admin:manage"]
      : policies
          .filter((policy) => session.roleIds.includes(policy.roleId))
          .flatMap((policy) => policy.permissions);
    return {
      authenticated: true,
      user: {
        discordUserId: session.discordUserId,
        username: session.username,
        avatarUrl: session.avatarUrl,
        googleLinked: Boolean(googleLink),
        roleIds: session.roleIds,
        permissions: [...new Set(permissions)],
        isOwner,
      },
    };
  } catch (error) {
    const status = (error as { status?: number }).status;
    if (status === 401 || status === 403 || status === 404) {
      res.clearCookie(SESSION_COOKIE, { path: "/" });
      return { authenticated: false, user: null };
    }
    req.log.error({ err: error }, "Could not verify Discord session");
    throw error;
  }
}

export async function requireSession(
  req: Request,
  res: Response,
  next: NextFunction,
): Promise<void> {
  try {
    const session = await currentSession(req, res);
    if (!session) {
      res.status(401).json({ error: "Sign-in required" });
      return;
    }
    req.apexSession = session;
    if (session.authProvider === "local") {
      const rawId = session.discordUserId.replace(/^local:/, "");
      const [account] = await db.select().from(localAuthAccountsTable).where(eq(localAuthAccountsTable.id, rawId)).limit(1);
      if (!account) { res.status(401).json({ error: "Sign-in required" }); return; }
       req.apexPermissions = new Set(account.status === "approved" ? account.permissions : []);
      req.apexIsOwner = account.isOwner;
      next();
      return;
    }
    const policies = await db.select().from(accessPoliciesTable);
    const permissions = session.authProvider === "google"
      ? await googleAccountPermissions(session)
      : policies
      .filter((policy) => session.roleIds.includes(policy.roleId))
      .flatMap((policy) => policy.permissions);
    req.apexPermissions = new Set(permissions);
    req.apexIsOwner = false;
    next();
  } catch (error) {
    const status = (error as { status?: number }).status;
    if (status === 404 || status === 401 || status === 403) {
      res.clearCookie(SESSION_COOKIE, { path: "/" });
      res.status(401).json({ error: "Discord server membership could not be verified" });
      return;
    }
    req.log.error({ err: error }, "Failed to validate Discord session");
    res.status(503).json({ error: "Discord membership verification is temporarily unavailable" });
  }
}

export function requirePermission(permission: string) {
  return (req: Request, res: Response, next: NextFunction): void => {
    if (req.apexIsOwner || req.apexPermissions?.has(permission)) {
      next();
      return;
    }
    res.status(403).json({ error: "Missing required role permission" });
  };
}

export function requireOwner(
  req: Request,
  res: Response,
  next: NextFunction,
): void {
  if (req.apexSession?.authProvider === "local" && req.apexIsOwner) {
    next();
    return;
  }
  res.status(403).json({ error: "Owner access required" });
}

export function createAuthRouter() {
  const router: IRouter = Router();

  const validUsername = (value: unknown): value is string =>
    typeof value === "string" && /^[\p{L}\p{N}_. -]{3,32}$/u.test(value);
  const validPassword = (value: unknown): value is string =>
    typeof value === "string" && value.length >= 12 && value.length <= 128;

  async function getLocalAccount(req: Request, res: Response) {
    const session = await currentSession(req, res);
    if (!session || session.authProvider !== "local") return null;
    const id = session.discordUserId.slice("local:".length);
    const [account] = await db.select().from(localAuthAccountsTable).where(eq(localAuthAccountsTable.id, id)).limit(1);
    return account ?? null;
  }

  router.get("/auth/profile", async (req, res): Promise<void> => {
    const account = await getLocalAccount(req, res);
    if (!account) { res.status(401).json({ error: "Sign-in required" }); return; }
    res.setHeader("cache-control", "no-store");
    const [citizen] = await db.insert(citizensTable).values({
      discordUserId: `local:${account.id}`,
      displayName: account.username,
    }).onConflictDoUpdate({
      target: citizensTable.discordUserId,
      set: { displayName: account.username },
    }).returning({ identityNumber: citizensTable.identityNumber });
    res.json({
      username: account.username,
      identityNumber: citizen.identityNumber,
      status: account.status,
      isOwner: account.isOwner,
      permissions: account.permissions,
      createdAt: account.createdAt,
    });
  });

  router.patch("/auth/profile", async (req, res): Promise<void> => {
    const account = await getLocalAccount(req, res);
    if (!account) { res.status(401).json({ error: "Sign-in required" }); return; }
    const username = typeof req.body?.username === "string" ? req.body.username.trim().toLowerCase() : "";
    const currentPassword = req.body?.currentPassword;
    if (!validUsername(username)) { res.status(400).json({ error: "اسم المستخدم يجب أن يكون بين 3 و32 حرفاً." }); return; }
    if (typeof currentPassword !== "string" || !await checkPassword(currentPassword, account.passwordHash)) {
      res.status(403).json({ error: "كلمة المرور الحالية غير صحيحة." }); return;
    }
    try {
      const [updated] = await db.update(localAuthAccountsTable)
        .set({ username, sessionVersion: account.sessionVersion + 1 })
        .where(eq(localAuthAccountsTable.id, account.id)).returning();
      await db.update(citizensTable).set({ displayName: username })
        .where(eq(citizensTable.discordUserId, `local:${account.id}`));
      setSessionCookie(res, localSession(updated));
      res.json({ username: updated.username });
    } catch {
      res.status(409).json({ error: "اسم المستخدم مستخدم بالفعل أو تعذّر حفظ التغييرات." });
    }
  });

  router.post("/auth/password", async (req, res): Promise<void> => {
    const account = await getLocalAccount(req, res);
    if (!account) { res.status(401).json({ error: "Sign-in required" }); return; }
    const currentPassword = req.body?.currentPassword;
    const newPassword = req.body?.newPassword;
    if (typeof currentPassword !== "string" || !await checkPassword(currentPassword, account.passwordHash)) {
      res.status(403).json({ error: "كلمة المرور الحالية غير صحيحة." }); return;
    }
    if (!validPassword(newPassword)) { res.status(400).json({ error: "كلمة المرور الجديدة يجب أن تكون بين 12 و128 حرفاً." }); return; }
    if (newPassword === currentPassword) { res.status(400).json({ error: "اختر كلمة مرور مختلفة عن الحالية." }); return; }
    const values = {
      passwordHash: await makePasswordHash(newPassword),
      sessionVersion: account.sessionVersion + 1,
    };
    const updated = await db.update(localAuthAccountsTable).set(values)
      .where(eq(localAuthAccountsTable.id, account.id)).returning();
    if (!updated.length) { res.status(409).json({ error: "تعذر حفظ كلمة المرور الجديدة." }); return; }
    setSessionCookie(res, localSession(updated[0]));
    res.json({ changed: true });
  });

  router.get("/auth/bootstrap/status", async (_req, res): Promise<void> => {
    res.setHeader("cache-control", "no-store");
    const setupToken = process.env.INITIAL_ADMIN_SETUP_TOKEN;
    if (!setupToken || setupToken.length < 32) {
      res.json({ available: false });
      return;
    }
    const [owner] = await db.select({ id: localAuthAccountsTable.id })
      .from(localAuthAccountsTable).where(eq(localAuthAccountsTable.isOwner, true)).limit(1);
    const [claim] = await db.select({ id: localAuthBootstrapTable.id })
      .from(localAuthBootstrapTable).limit(1);
    res.json({ available: !owner && !claim });
  });

  router.post("/auth/register", async (req, res): Promise<void> => {
    const username = typeof req.body?.username === "string" ? req.body.username.trim().toLowerCase() : "";
    const email = typeof req.body?.email === "string" ? req.body.email.trim().toLowerCase() : "";
    const password = req.body?.password;
    if (!validUsername(username) || !validPassword(password) || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
      res.status(400).json({ error: "أدخل اسم مستخدم وبريداً صالحاً وكلمة مرور من 12 حرفاً على الأقل." }); return;
    }
    try {
      const duplicate = await db.select({ id: localAuthAccountsTable.id }).from(localAuthAccountsTable)
        .where(or(eq(sql`lower(${localAuthAccountsTable.username})`, username), eq(sql`lower(${localAuthAccountsTable.email})`, email))).limit(1);
      if (duplicate.length) { res.status(409).json({ error: "اسم المستخدم أو البريد مستخدم بالفعل." }); return; }
      const account = await db.transaction(async (tx) => {
        const [created] = await tx.insert(localAuthAccountsTable).values({
          username,
          email,
          passwordHash: await makePasswordHash(password),
          status: "approved",
        }).returning();
        await tx.insert(citizensTable).values({
          discordUserId: `local:${created.id}`,
          displayName: username,
        });
        return created;
      });
      setSessionCookie(res, localSession(account));
      res.status(201).json({ registered: true, authenticated: true });
    } catch (error) {
      const code = error && typeof error === "object" && "code" in error
        ? (error as { code?: unknown }).code
        : undefined;
      if (code === "23505") {
        res.status(409).json({ error: "اسم المستخدم أو البريد مستخدم بالفعل." });
        return;
      }
      res.status(500).json({ error: "تعذر إنشاء الحساب." });
    }
  });
  router.post("/auth/bootstrap", async (req, res): Promise<void> => {
    res.setHeader("cache-control", "no-store");
    const setupToken = typeof req.body?.setupToken === "string" ? req.body.setupToken : undefined;
    const username = typeof req.body?.username === "string" ? req.body.username.trim().toLowerCase() : "";
    const email = typeof req.body?.email === "string" ? req.body.email.trim().toLowerCase() : "";
    const password = req.body?.password;
    const configuredToken = process.env.INITIAL_ADMIN_SETUP_TOKEN;
    if (!configuredToken || configuredToken.length < 32 || !safeEqual(setupToken, configuredToken)) {
      res.status(403).json({ error: "رمز الإعداد غير صحيح." }); return;
    }
    if (!validUsername(username) || !validPassword(password) || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
      res.status(400).json({ error: "أدخل اسم مستخدم وبريداً صالحاً وكلمة مرور من 12 حرفاً على الأقل." }); return;
    }
    try {
      const account = await db.transaction(async (tx) => {
        const [existingOwner] = await tx.select({ id: localAuthAccountsTable.id })
          .from(localAuthAccountsTable).where(eq(localAuthAccountsTable.isOwner, true)).limit(1);
        if (existingOwner) throw new Error("OWNER_EXISTS");
        const [claim] = await tx.insert(localAuthBootstrapTable)
          .values({ id: "singleton", consumedAt: new Date() })
          .onConflictDoNothing().returning();
        if (!claim) throw new Error("BOOTSTRAP_ALREADY_USED");
        const [created] = await tx.insert(localAuthAccountsTable).values({
          username,
          email,
          passwordHash: await makePasswordHash(password),
          status: "approved",
          isOwner: true,
        }).returning();
        await tx.insert(citizensTable).values({
          discordUserId: `local:${created.id}`,
          displayName: username,
        });
        return created;
      });
      setSessionCookie(res, localSession(account));
      res.status(201).json({ authenticated: true, ownerCreated: true });
    } catch (error) {
      if ((error as Error).message === "BOOTSTRAP_ALREADY_USED") { res.status(409).json({ error: "تم استخدام رمز إعداد المالك مسبقاً." }); return; }
      if ((error as Error).message === "OWNER_EXISTS") { res.status(409).json({ error: "يوجد حساب مالك بالفعل." }); return; }
      const code = error && typeof error === "object" && "code" in error ? (error as { code?: unknown }).code : undefined;
      if (code === "23505") { res.status(409).json({ error: "اسم المستخدم أو البريد مستخدم بالفعل." }); return; }
      res.status(500).json({ error: "تعذر إنشاء حساب المالك." });
    }
  });

  router.post("/auth/login", async (req, res): Promise<void> => {
    const identifier = typeof req.body?.identifier === "string" ? req.body.identifier.trim() : "";
    const password = req.body?.password;
    let [account] = await db.select().from(localAuthAccountsTable).where(or(
      eq(sql`lower(${localAuthAccountsTable.username})`, identifier.toLowerCase()),
      eq(sql`lower(${localAuthAccountsTable.email})`, identifier.toLowerCase()),
    )).limit(1);
    if (!account && /^APX-[A-F0-9]{12}$/i.test(identifier)) {
      const [citizen] = await db.select({ discordUserId: citizensTable.discordUserId }).from(citizensTable)
        .where(eq(sql`upper(${citizensTable.identityNumber})`, identifier.toUpperCase())).limit(1);
      if (citizen?.discordUserId.startsWith("local:")) {
        [account] = await db.select().from(localAuthAccountsTable)
          .where(eq(localAuthAccountsTable.id, citizen.discordUserId.slice(6))).limit(1);
      }
    }
    const genericFailure = () => res.status(401).json({ error: "بيانات الدخول غير صحيحة." });
    if (!account || typeof password !== "string" || (account.lockedUntil && account.lockedUntil > new Date())) { genericFailure(); return; }
    if (!await checkPassword(password, account.passwordHash)) {
      const failures = account.failedLoginCount + 1;
      await db.update(localAuthAccountsTable).set({ failedLoginCount: failures, lockedUntil: failures >= 8 ? new Date(Date.now() + 15 * 60_000) : null })
        .where(eq(localAuthAccountsTable.id, account.id));
      genericFailure(); return;
    }
    await db.update(localAuthAccountsTable).set({ failedLoginCount: 0, lockedUntil: null }).where(eq(localAuthAccountsTable.id, account.id));
    if (account.status === "disabled") { res.status(403).json({ error: "الحساب موقوف. تواصل مع مالك الموقع." }); return; }
    setSessionCookie(res, localSession(account));
    res.json({ authenticated: true });
  });

  router.post("/auth/login/totp", async (req, res): Promise<void> => {
    res.status(410).json({ error: "المصادقة الثنائية معطلة." }); return;
  });

  router.get("/auth/discord", (_req, res): void => { res.redirect("/?auth=local-only"); });
  router.get("/auth/discord/callback", (_req, res): void => { res.redirect("/?auth=local-only"); });

  router.get("/auth/session", async (req, res): Promise<void> => {
    const session = await authSessionResponse(req, res);
    res.setHeader("cache-control", "no-store");
    res.json(GetAuthSessionResponse.parse(session));
  });
  router.get("/auth/discord", (req, res, next) => {
    try {
      const state = randomBytes(24).toString("base64url");
      res.cookie(STATE_COOKIE, state, {
        httpOnly: true,
        secure: process.env.NODE_ENV === "production",
        sameSite: "lax",
        maxAge: 10 * 60 * 1000,
        path: "/api/auth/discord/callback",
      });
      const url = new URL(`${API_BASE}/oauth2/authorize`);
      url.searchParams.set("client_id", requiredEnv("DISCORD_CLIENT_ID"));
      url.searchParams.set("redirect_uri", callbackUrl(req));
      url.searchParams.set("response_type", "code");
      url.searchParams.set("scope", "identify guilds guilds.members.read");
      url.searchParams.set("state", state);
      res.redirect(url.toString());
    } catch (error) {
      next(error);
    }
  });

  router.get("/auth/discord/callback", async (req, res): Promise<void> => {
    const state = typeof req.query.state === "string" ? req.query.state : undefined;
    const code = typeof req.query.code === "string" ? req.query.code : undefined;
    const storedState = req.cookies?.[STATE_COOKIE] as string | undefined;
    res.clearCookie(STATE_COOKIE, { path: "/api/auth/discord/callback" });
    if (!safeEqual(state, storedState) || !code) {
      res.status(400).send("Invalid Discord OAuth state");
      return;
    }

    try {
      const token = await exchangeCode(req, code);
      const user = await discordJson<{
        id: string;
        username: string;
        avatar: string | null;
      }>("/users/@me", token.access_token);
      const member = await discordJson<{ roles: string[] }>(
        `/users/@me/guilds/${encodeURIComponent(requiredEnv("DISCORD_GUILD_ID"))}/member`,
        token.access_token,
      );
      await persistLinkedDiscordRefreshToken(user.id, token.refresh_token);

      const avatarUrl = user.avatar
        ? `https://cdn.discordapp.com/avatars/${user.id}/${user.avatar}.png?size=128`
        : null;
      const session: ApexSession = {
        discordUserId: user.id,
        username: user.username,
        avatarUrl,
        accessToken: token.access_token,
        refreshToken: token.refresh_token,
        tokenExpiresAt: Date.now() + token.expires_in * 1000,
        roleIds: member.roles,
        roleFetchedAt: Date.now(),
      };
      memberCache.set(user.id, { roleIds: member.roles, fetchedAt: Date.now() });
      setSessionCookie(res, session);

      await db
        .insert(citizensTable)
        .values({
          discordUserId: user.id,
          displayName: user.username,
          lastSeen: new Date(),
        })
        .onConflictDoUpdate({
          target: citizensTable.discordUserId,
          set: { displayName: user.username, lastSeen: new Date() },
        });

      res.redirect("/");
    } catch (error) {
      const status = (error as { status?: number }).status;
      if (status === 404 || status === 403) {
        res.redirect("/?auth=not-a-member");
        return;
      }
      req.log.error({ err: error }, "Discord OAuth callback failed");
      res.status(502).send("Discord sign-in could not be completed");
    }
  });

  router.get("/auth/google", (req, res): void => {
    if (!GOOGLE_SIGN_IN_ENABLED) { res.redirect("/?auth=local-only"); return; }
    beginGoogleOAuth(req, res, "login", null);
  });

  router.get("/auth/google/link", async (req, res, next): Promise<void> => {
    if (!GOOGLE_SIGN_IN_ENABLED) {
      res.redirect("/?auth=google-unavailable");
      return;
    }
    try {
      const session = await currentSession(req, res);
      if (!session) {
        res.redirect("/?auth=discord-required");
        return;
      }
      beginGoogleOAuth(req, res, "link", session.discordUserId);
    } catch (error) {
      next(error);
    }
  });

  router.get("/auth/google/callback", async (req, res): Promise<void> => {
    if (!GOOGLE_SIGN_IN_ENABLED) {
      res.redirect("/?auth=google-unavailable");
      return;
    }
    const stateQuery =
      typeof req.query.state === "string" ? req.query.state : undefined;
    const code = typeof req.query.code === "string" ? req.query.code : undefined;
    const stateCookie = req.cookies?.[GOOGLE_STATE_COOKIE] as
      | string
      | undefined;
    const oauthState = parseGoogleOAuthState(stateCookie);
    res.clearCookie(GOOGLE_STATE_COOKIE, {
      path: "/api/auth/google/callback",
    });

    if (!oauthState || !safeEqual(stateQuery, oauthState.state)) {
      res.status(400).send("Invalid Google OAuth state");
      return;
    }
    if (typeof req.query.error === "string") {
      res.redirect("/?auth=google-error");
      return;
    }
    if (!code) {
      res.status(400).send("Google authorization code is missing");
      return;
    }

    try {
      const idToken = await exchangeGoogleCode(
        req,
        code,
        oauthState.codeVerifier,
      );
      const identity = await verifyGoogleIdentity(idToken, oauthState.nonce);

      if (oauthState.flow === "link") {
        const session = await currentSession(req, res);
        if (
          !session ||
          session.discordUserId !== oauthState.discordUserId
        ) {
          res.redirect("/?auth=discord-link-required");
          return;
        }
        await saveGoogleLink(identity, session);
        res.redirect("/?auth=google-linked");
        return;
      }

      const [account] = await db.insert(googleStandaloneAccountsTable).values({
        googleSubject: identity.subject,
        email: identity.email,
        username: identity.name,
        avatarUrl: identity.avatarUrl,
      }).onConflictDoUpdate({
        target: googleStandaloneAccountsTable.googleSubject,
        set: {
          email: identity.email,
          username: identity.name,
          avatarUrl: identity.avatarUrl,
          updatedAt: new Date(),
        },
      }).returning();
      const googleSession: ApexSession = {
        discordUserId: `google:${identity.subject}`,
        username: account.username,
        avatarUrl: account.avatarUrl,
        accessToken: "",
        refreshToken: "",
        tokenExpiresAt: Date.now() + SESSION_TTL_MS,
        roleIds: [],
        roleFetchedAt: Date.now(),
        authProvider: "google",
        googleSubject: identity.subject,
      };
      setSessionCookie(res, googleSession);
      res.redirect(account.status === "approved" ? "/" : "/?auth=google-pending");
      return;

      const [link] = await db
        .select()
        .from(googleOAuthLinksTable)
        .where(eq(googleOAuthLinksTable.googleSubject, identity.subject))
        .limit(1);
      if (!link) {
        res.redirect("/?auth=google-not-linked");
        return;
      }

      const discordRefreshToken = decryptOpaque(
        link.encryptedDiscordRefreshToken,
      );
      if (!discordRefreshToken) {
        res.redirect("/?auth=discord-relink-required");
        return;
      }

      const session = await refreshToken({
        discordUserId: link.discordUserId,
        username: "",
        avatarUrl: null,
        accessToken: "",
        refreshToken: discordRefreshToken ?? "",
        tokenExpiresAt: 0,
        roleIds: [],
        roleFetchedAt: 0,
      });
      const discordUser = await discordJson<{
        id: string;
        username: string;
        avatar: string | null;
      }>("/users/@me", session.accessToken);
      const member = await discordJson<{ roles: string[] }>(
        `/users/@me/guilds/${encodeURIComponent(requiredEnv("DISCORD_GUILD_ID"))}/member`,
        session.accessToken,
      );
      if (
        discordUser.id !== link.discordUserId ||
        !Array.isArray(member.roles)
      ) {
        res.redirect("/?auth=discord-relink-required");
        return;
      }
      session.username = discordUser.username;
      session.avatarUrl = discordUser.avatar
        ? `https://cdn.discordapp.com/avatars/${discordUser.id}/${discordUser.avatar}.png?size=128`
        : null;
      session.roleIds = member.roles;
      session.roleFetchedAt = Date.now();
      memberCache.set(session.discordUserId, {
        roleIds: member.roles,
        fetchedAt: session.roleFetchedAt,
      });
      setSessionCookie(res, session);

      await db
        .insert(citizensTable)
        .values({
          discordUserId: discordUser.id,
          displayName: discordUser.username,
          lastSeen: new Date(),
        })
        .onConflictDoUpdate({
          target: citizensTable.discordUserId,
          set: { displayName: discordUser.username, lastSeen: new Date() },
        });

      res.redirect("/");
    } catch (error) {
      const status = (error as { status?: number }).status;
      const errorCode = (error as { code?: string }).code;
      if (errorCode === "GOOGLE_LINK_CONFLICT" || status === 409) {
        res.redirect("/?auth=google-link-conflict");
        return;
      }
      if (status === 403 || status === 404) {
        res.redirect("/?auth=not-a-member");
        return;
      }
      if (status === 401) {
        res.redirect(
          oauthState.flow === "link"
            ? "/?auth=discord-link-required"
            : "/?auth=discord-relink-required",
        );
        return;
      }
      req.log.error(
        {
          failure:
            error instanceof Error ? error.name : "UnknownGoogleOAuthError",
        },
        "Google OAuth callback failed",
      );
      res.redirect("/?auth=google-error");
    }
  });

  router.get("/auth/roblox", (req, res): void => {
    beginRobloxOAuth(req, res, "login", null);
  });

  router.get("/auth/roblox/link", async (req, res, next): Promise<void> => {
    try {
      const session = await currentSession(req, res);
      if (!session) {
        res.redirect("/?auth=discord-required");
        return;
      }
      beginRobloxOAuth(req, res, "link", session.discordUserId);
    } catch (error) {
      next(error);
    }
  });

  router.get("/auth/roblox/callback", async (req, res): Promise<void> => {
    const stateQuery = typeof req.query.state === "string" ? req.query.state : undefined;
    const code = typeof req.query.code === "string" ? req.query.code : undefined;
    const stateCookie = req.cookies?.[ROBLOX_STATE_COOKIE] as string | undefined;
    const oauthState = parseRobloxOAuthState(stateCookie);
    res.clearCookie(ROBLOX_STATE_COOKIE, { path: "/api/auth/roblox/callback" });
    if (!oauthState || !safeEqual(stateQuery, oauthState.state)) {
      res.status(400).send("Invalid Roblox OAuth state");
      return;
    }
    if (typeof req.query.error === "string" || !code) {
      res.redirect("/?auth=roblox-error");
      return;
    }
    try {
      const accessToken = await exchangeRobloxCode(req, code, oauthState.codeVerifier);
      const identity = await fetchRobloxIdentity(accessToken);
      if (oauthState.flow === "link") {
        const session = await currentSession(req, res);
        if (!session || session.discordUserId !== oauthState.discordUserId) {
          res.redirect("/?auth=discord-link-required");
          return;
        }
        await saveRobloxLink(identity, session);
        res.redirect("/?auth=roblox-linked");
        return;
      }
      const [link] = await db.select().from(robloxOAuthLinksTable)
        .where(eq(robloxOAuthLinksTable.robloxSubject, identity.subject)).limit(1);
      if (!link) {
        res.redirect("/?auth=roblox-not-linked");
        return;
      }
      const discordRefreshToken = decryptOpaque(link.encryptedDiscordRefreshToken);
      if (!discordRefreshToken) {
        res.redirect("/?auth=discord-relink-required");
        return;
      }
      const session = await refreshToken({
        discordUserId: link.discordUserId,
        username: "",
        avatarUrl: null,
        accessToken: "",
        refreshToken: discordRefreshToken,
        tokenExpiresAt: 0,
        roleIds: [],
        roleFetchedAt: 0,
      });
      const discordUser = await discordJson<{id:string;username:string;avatar:string|null}>("/users/@me", session.accessToken);
      const member = await discordJson<{roles:string[]}>(`/users/@me/guilds/${encodeURIComponent(requiredEnv("DISCORD_GUILD_ID"))}/member`, session.accessToken);
      if (discordUser.id !== link.discordUserId || !Array.isArray(member.roles)) {
        res.redirect("/?auth=discord-relink-required");
        return;
      }
      session.username = discordUser.username;
      session.avatarUrl = discordUser.avatar
        ? `https://cdn.discordapp.com/avatars/${discordUser.id}/${discordUser.avatar}.png?size=128`
        : null;
      session.roleIds = member.roles;
      session.roleFetchedAt = Date.now();
      memberCache.set(session.discordUserId, { roleIds: member.roles, fetchedAt: session.roleFetchedAt });
      setSessionCookie(res, session);
      await db.insert(citizensTable).values({
        discordUserId: discordUser.id,
        displayName: discordUser.username,
        lastSeen: new Date(),
      }).onConflictDoUpdate({
        target: citizensTable.discordUserId,
        set: { displayName: discordUser.username, lastSeen: new Date() },
      });
      res.redirect("/");
    } catch (error) {
      const status = (error as {status?:number}).status;
      const code = (error as {code?:string}).code;
      if (code === "ROBLOX_LINK_CONFLICT" || status === 409) {
        res.redirect("/?auth=roblox-link-conflict");
      } else if (status === 403 || status === 404) {
        res.redirect("/?auth=not-a-member");
      } else if (status === 401) {
        res.redirect(oauthState.flow === "link" ? "/?auth=discord-link-required" : "/?auth=discord-relink-required");
      } else {
        req.log.error({failure:error instanceof Error ? error.name : "UnknownRobloxOAuthError"}, "Roblox OAuth callback failed");
        res.redirect("/?auth=roblox-error");
      }
    }
  });

  router.post("/auth/logout", (_req, res): void => {
    res.clearCookie(SESSION_COOKIE, { path: "/" });
    res.status(204).end();
  });

  return router;
}
