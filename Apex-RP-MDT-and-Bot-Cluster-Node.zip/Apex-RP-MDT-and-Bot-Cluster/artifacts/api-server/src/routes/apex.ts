import { randomBytes } from "node:crypto";
import { Router, type IRouter, type Request, type Response } from "express";
import {
  and,
  desc,
  eq,
  gte,
  ilike,
  inArray,
  or,
  sql,
} from "drizzle-orm";
import {
  accessPoliciesTable,
  auditEventsTable,
  bankAccountsTable,
  bankTransactionsTable,
  businessesTable,
  citizensTable,
  googleStandaloneAccountsTable,
  localAuthAccountsTable,
  db,
  dispatchCallsTable,
  dispatchUnitsTable,
  medicalRecordsTable,
  policeRecordsTable,
  propertiesTable,
  securityEventsTable,
} from "@workspace/db";
import {
  AssignDispatchUnitBody,
  AssignDispatchUnitParams,
  AssignDispatchUnitResponse,
  CreateBankAccountBody,
  CreateBankAccountResponse,
  CreateCitationBody,
  CreateCitationResponse,
  CreateDepositBody,
  CreateDepositResponse,
  CreateDispatchCallBody,
  CreateDispatchCallResponse,
  CreateDispatchUnitBody,
  CreateDispatchUnitResponse,
  CreateMedicalReportBody,
  CreateMedicalReportResponse,
  CreateTransferBody,
  CreateTransferResponse,
  CreateWithdrawalBody,
  CreateWithdrawalResponse,
  GetCitizenParams,
  GetCitizenResponse,
  GetOverviewResponse,
  ListAccessPoliciesResponse,
  ListBankAccountsResponse,
  ListBusinessesResponse,
  ListCitizensQueryParams,
  ListCitizensResponse,
  ListDispatchCallsResponse,
  ListDispatchUnitsResponse,
  ListPropertiesResponse,
  ListSecurityEventsResponse,
  ListTransactionsQueryParams,
  ListTransactionsResponse,
  SearchMedicalRecordsQueryParams,
  SearchMedicalRecordsResponse,
  SearchPoliceRecordsQueryParams,
  SearchPoliceRecordsResponse,
  UpdateAccessPolicyBody,
  UpdateAccessPolicyParams,
  UpdateAccessPolicyResponse,
  UpdateDispatchUnitBody,
  UpdateDispatchUnitParams,
  UpdateDispatchUnitResponse,
} from "@workspace/api-zod";
import {
  requireOwner,
  requirePermission,
  requireSession,
} from "../lib/apex-auth";

const router: IRouter = Router();
router.use(requireSession);

const PERMISSIONS = {
  dashboard: "dashboard:read",
  citizens: "citizens:read",
  banking: "banking:read",
  bankingManage: "banking:manage",
  dispatch: "dispatch:read",
  dispatchManage: "dispatch:manage",
  police: "police:read",
  policeManage: "police:manage",
  medical: "medical:read",
  medicalManage: "medical:manage",
  community: "community:read",
};
const GOOGLE_READ_PERMISSIONS = new Set([
  "dashboard:read", "citizens:read", "banking:read", "dispatch:read",
  "police:read", "medical:read", "community:read",
]);

function actorId(req: Request): string {
  const id = req.apexSession?.discordUserId;
  if (!id) throw new Error("Authenticated session is missing its Discord user ID");
  return id;
}

function toCents(amount: number): number | null {
  if (!Number.isFinite(amount) || amount <= 0 || amount > 10_000_000) {
    return null;
  }
  const cents = Math.round(amount * 100);
  return Number.isSafeInteger(cents) && cents > 0 ? cents : null;
}

function cashAmount(cents: number | null): number | null {
  return cents === null ? null : cents / 100;
}

function receiptNumber(): string {
  return `APX-${Date.now().toString(36).toUpperCase()}-${randomBytes(3).toString("hex").toUpperCase()}`;
}

function mapAccount(account: typeof bankAccountsTable.$inferSelect) {
  return {
    id: account.id,
    ownerDiscordUserId: account.ownerDiscordUserId,
    displayName: account.displayName,
    iban: account.iban,
    accountType: account.accountType,
    balance: account.balanceCents / 100,
    currency: account.currency,
    status: account.status,
  };
}

function mapTransaction(
  transaction: typeof bankTransactionsTable.$inferSelect,
) {
  return {
    id: transaction.id,
    accountId: transaction.accountId,
    entryKind: transaction.entryKind,
    counterparty: transaction.counterparty,
    amount: transaction.amountCents / 100,
    description: transaction.description,
    receiptNumber: transaction.receiptNumber,
    createdAt: transaction.createdAt.toISOString(),
  };
}

function mapCall(call: typeof dispatchCallsTable.$inferSelect) {
  return {
    id: call.id,
    callType: call.callType,
    title: call.title,
    location: call.location,
    notes: call.notes,
    status: call.status,
    callerName: call.callerName,
    priority: call.priority,
    assignedUnitIds: call.assignedUnitIds,
    createdAt: call.createdAt.toISOString(),
  };
}

function mapUnit(unit: typeof dispatchUnitsTable.$inferSelect) {
  return {
    id: unit.id,
    callsign: unit.callsign,
    department: unit.department,
    displayName: unit.displayName,
    status: unit.status,
    location: unit.location,
  };
}

async function audit(
  actorDiscordUserId: string,
  action: string,
  entityType: string,
  entityId: string | null,
  metadata: Record<string, unknown> = {},
): Promise<void> {
  await db.insert(auditEventsTable).values({
    actorDiscordUserId,
    action,
    entityType,
    entityId,
    metadata,
  });
}

router.get(
  "/admin/local-accounts",
  requireOwner,
  async (_req, res, next): Promise<void> => {
    try {
      const accounts = await db.select({
        id: localAuthAccountsTable.id, username: localAuthAccountsTable.username,
        status: localAuthAccountsTable.status, permissions: localAuthAccountsTable.permissions,
        createdAt: localAuthAccountsTable.createdAt,
      }).from(localAuthAccountsTable).where(eq(localAuthAccountsTable.isOwner, false))
        .orderBy(desc(localAuthAccountsTable.createdAt));
      res.json(accounts);
    } catch (error) { next(error); }
  },
);

router.put(
  "/admin/local-accounts/:id",
  requireOwner,
  async (req, res, next): Promise<void> => {
    try {
      const { status, permissions } = req.body ?? {};
      const allowed = new Set(["dashboard:read","citizens:read","banking:read","banking:manage","dispatch:read","dispatch:manage","police:read","police:manage","medical:read","medical:manage","community:read"]);
      if (!["pending", "approved", "disabled"].includes(status) || !Array.isArray(permissions) ||
          permissions.some((permission: unknown) => typeof permission !== "string" || !allowed.has(permission))) {
        res.status(400).json({ error: "Invalid local account access policy" }); return;
      }
      const [account] = await db.update(localAuthAccountsTable)
        .set({ status, permissions, sessionVersion: sql`${localAuthAccountsTable.sessionVersion} + 1` })
        .where(and(eq(localAuthAccountsTable.id, String(req.params.id)), eq(localAuthAccountsTable.isOwner, false)))
        .returning();
      if (!account) { res.status(404).json({ error: "Account not found" }); return; }
      if (status === "approved") {
        await db.insert(citizensTable).values({
          discordUserId: `local:${account.id}`, displayName: account.username, lastSeen: new Date(),
        }).onConflictDoUpdate({ target: citizensTable.discordUserId, set: { displayName: account.username } });
      }
      await audit(actorId(req), "admin.local_account.update", "local_account", account.id, { status, permissions });
      res.json({ id: account.id, username: account.username, status: account.status, permissions: account.permissions });
    } catch (error) { next(error); }
  },
);

router.get(
  "/overview",
  requirePermission(PERMISSIONS.dashboard),
  async (req, res, next): Promise<void> => {
    try {
      const canSeeAllTransactions =
        req.apexIsOwner || req.apexPermissions?.has(PERMISSIONS.bankingManage);
      const ownedAccountIds = canSeeAllTransactions
        ? undefined
        : (
            await db.select({ id: bankAccountsTable.id }).from(bankAccountsTable)
              .where(eq(bankAccountsTable.ownerDiscordUserId, actorId(req)))
          ).map((account) => account.id);
      const [accounts, calls, units, recentTransactions, priorityCalls] =
        await Promise.all([
          db.select({ balanceCents: bankAccountsTable.balanceCents }).from(bankAccountsTable),
          db.select().from(dispatchCallsTable).where(
            or(
              eq(dispatchCallsTable.status, "open"),
              eq(dispatchCallsTable.status, "assigned"),
              eq(dispatchCallsTable.status, "on_scene"),
            ),
          ),
          db.select().from(dispatchUnitsTable).where(
            or(
              eq(dispatchUnitsTable.status, "available"),
              eq(dispatchUnitsTable.status, "responding"),
              eq(dispatchUnitsTable.status, "on_scene"),
            ),
          ),
          ownedAccountIds === undefined
            ? db.select().from(bankTransactionsTable)
                .orderBy(desc(bankTransactionsTable.createdAt))
                .limit(6)
            : ownedAccountIds.length
              ? db.select().from(bankTransactionsTable)
                  .where(inArray(bankTransactionsTable.accountId, ownedAccountIds))
                  .orderBy(desc(bankTransactionsTable.createdAt))
                  .limit(6)
              : Promise.resolve([]),
          db.select().from(dispatchCallsTable)
            .where(
              and(
                or(
                  eq(dispatchCallsTable.status, "open"),
                  eq(dispatchCallsTable.status, "assigned"),
                  eq(dispatchCallsTable.status, "on_scene"),
                ),
                or(
                  eq(dispatchCallsTable.priority, "high"),
                  eq(dispatchCallsTable.priority, "critical"),
                ),
              ),
            )
            .orderBy(desc(dispatchCallsTable.createdAt))
            .limit(5),
        ]);
      const payload = GetOverviewResponse.parse({
        totalBankBalance: accounts.reduce((sum, row) => sum + row.balanceCents, 0) / 100,
        activeCalls: calls.length,
        availableUnits: units.filter((unit) => unit.status === "available").length,
        activeStaff: units.length,
        recentTransactions: recentTransactions.map(mapTransaction),
        priorityCalls: priorityCalls.map(mapCall),
      });
      res.json(payload);
    } catch (error) {
      next(error);
    }
  },
);

router.get(
  "/citizens",
  requirePermission(PERMISSIONS.citizens),
  async (req, res, next): Promise<void> => {
    try {
      const query = ListCitizensQueryParams.safeParse(req.query);
      if (!query.success) {
        res.status(400).json({ error: query.error.message });
        return;
      }
      const search = query.data.search?.trim();
      const rows = await db.select().from(citizensTable)
        .where(
          search
            ? or(
                ilike(citizensTable.displayName, `%${search}%`),
                ilike(citizensTable.identityNumber, `%${search}%`),
                ilike(citizensTable.discordUserId, `%${search}%`),
                ilike(citizensTable.phone, `%${search}%`),
              )
            : undefined,
        )
        .orderBy(citizensTable.displayName)
        .limit(100);
      const accountRows = rows.length
        ? await db.select({
            ownerDiscordUserId: bankAccountsTable.ownerDiscordUserId,
            balanceCents: bankAccountsTable.balanceCents,
          }).from(bankAccountsTable)
          .where(inArray(bankAccountsTable.ownerDiscordUserId, rows.map((row) => row.discordUserId)))
        : [];
      const balances = new Map<string, number>();
      for (const row of accountRows) {
        balances.set(
          row.ownerDiscordUserId,
          (balances.get(row.ownerDiscordUserId) ?? 0) + row.balanceCents,
        );
      }
      res.json(
        ListCitizensResponse.parse(
          rows.map((row) => ({
            identityNumber: row.identityNumber,
            discordUserId: row.discordUserId,
            displayName: row.displayName,
            phone: row.phone,
            occupation: row.occupation,
            citizenStatus: row.citizenStatus,
            accountBalance: (balances.get(row.discordUserId) ?? 0) / 100,
            lastSeen: row.lastSeen?.toISOString() ?? null,
          })),
        ),
      );
    } catch (error) {
      next(error);
    }
  },
);

router.get(
  "/citizens/:discordUserId",
  requirePermission(PERMISSIONS.citizens),
  async (req, res, next): Promise<void> => {
    try {
      const params = GetCitizenParams.safeParse(req.params);
      if (!params.success) {
        res.status(400).json({ error: params.error.message });
        return;
      }
      const [citizen] = await db.select().from(citizensTable).where(
        eq(citizensTable.discordUserId, params.data.discordUserId),
      );
      if (!citizen) {
        res.status(404).json({ error: "Citizen not found" });
        return;
      }
      const accounts = await db.select({ balanceCents: bankAccountsTable.balanceCents })
        .from(bankAccountsTable)
        .where(eq(bankAccountsTable.ownerDiscordUserId, citizen.discordUserId));
      res.json(
        GetCitizenResponse.parse({
          identityNumber: citizen.identityNumber,
          discordUserId: citizen.discordUserId,
          displayName: citizen.displayName,
          phone: citizen.phone,
          occupation: citizen.occupation,
          citizenStatus: citizen.citizenStatus,
          accountBalance: accounts.reduce((sum, item) => sum + item.balanceCents, 0) / 100,
          lastSeen: citizen.lastSeen?.toISOString() ?? null,
        }),
      );
    } catch (error) {
      next(error);
    }
  },
);

router.get(
  "/bank/accounts",
  requirePermission(PERMISSIONS.banking),
  async (req, res, next): Promise<void> => {
    try {
      const accounts = req.apexPermissions?.has(PERMISSIONS.bankingManage)
        ? await db.select().from(bankAccountsTable).orderBy(desc(bankAccountsTable.createdAt))
        : await db.select().from(bankAccountsTable)
            .where(eq(bankAccountsTable.ownerDiscordUserId, actorId(req)))
            .orderBy(desc(bankAccountsTable.createdAt));
      res.json(ListBankAccountsResponse.parse(accounts.map(mapAccount)));
    } catch (error) {
      next(error);
    }
  },
);

router.post(
  "/bank/accounts",
  requirePermission(PERMISSIONS.banking),
  async (req, res, next): Promise<void> => {
    try {
      const body = CreateBankAccountBody.safeParse(req.body);
      if (!body.success) {
        res.status(400).json({ error: body.error.message });
        return;
      }
      if (
        body.data.accountType !== "personal" &&
        !req.apexIsOwner &&
        !req.apexPermissions?.has(PERMISSIONS.bankingManage)
      ) {
        res.status(403).json({ error: "Business and department accounts require banking management access" });
        return;
      }
      const [accountCount] = await db.select({ id: bankAccountsTable.id })
        .from(bankAccountsTable)
        .where(and(
          eq(bankAccountsTable.ownerDiscordUserId, actorId(req)),
          eq(bankAccountsTable.accountType, "personal"),
        ))
        .limit(1);
      if (body.data.accountType === "personal" && accountCount) {
        res.status(409).json({ error: "A personal account already exists for this citizen" });
        return;
      }
      const [account] = await db.insert(bankAccountsTable).values({
        ownerDiscordUserId: actorId(req),
        displayName: body.data.displayName,
        iban: `APEX${randomBytes(8).toString("hex").toUpperCase()}`,
        accountType: body.data.accountType,
      }).returning();
      await audit(actorId(req), "bank.account.create", "bank_account", account.id);
      res.status(201).json(CreateBankAccountResponse.parse(mapAccount(account)));
    } catch (error) {
      next(error);
    }
  },
);

router.get(
  "/bank/transactions",
  requirePermission(PERMISSIONS.banking),
  async (req, res, next): Promise<void> => {
    try {
      const query = ListTransactionsQueryParams.safeParse(req.query);
      if (!query.success) {
        res.status(400).json({ error: query.error.message });
        return;
      }
      const manageable = req.apexIsOwner || req.apexPermissions?.has(PERMISSIONS.bankingManage);
      const accountIds = manageable
        ? undefined
        : (await db.select({ id: bankAccountsTable.id }).from(bankAccountsTable)
            .where(eq(bankAccountsTable.ownerDiscordUserId, actorId(req))))
            .map((account) => account.id);
      if (query.data.accountId) {
        if (accountIds && !accountIds.includes(query.data.accountId)) {
          res.status(404).json({ error: "Bank account not found" });
          return;
        }
        const transactions = await db.select().from(bankTransactionsTable)
          .where(eq(bankTransactionsTable.accountId, query.data.accountId))
          .orderBy(desc(bankTransactionsTable.createdAt))
          .limit(100);
        res.json(ListTransactionsResponse.parse(transactions.map(mapTransaction)));
        return;
      }
      const transactions = accountIds
        ? accountIds.length
          ? await db.select().from(bankTransactionsTable)
              .where(inArray(bankTransactionsTable.accountId, accountIds))
              .orderBy(desc(bankTransactionsTable.createdAt))
              .limit(100)
          : []
        : await db.select().from(bankTransactionsTable)
            .orderBy(desc(bankTransactionsTable.createdAt))
            .limit(100);
      res.json(ListTransactionsResponse.parse(transactions.map(mapTransaction)));
    } catch (error) {
      next(error);
    }
  },
);

async function performCashMovement(
  req: Request,
  res: Response,
  kind: "deposit" | "withdrawal",
  data: { accountId: string; amount: number; description: string },
): Promise<void> {
  const cents = toCents(data.amount);
  if (cents === null) {
    res.status(400).json({ error: "Amount must be a positive amount below 10,000,000" });
    return;
  }
  const id = actorId(req);
  try {
    const transaction = await db.transaction(async (tx) => {
      const [account] = await tx.select().from(bankAccountsTable)
        .where(eq(bankAccountsTable.id, data.accountId))
        .for("update");
      if (!account || account.ownerDiscordUserId !== id) {
        return { error: "not_found" as const };
      }
      if (account.status !== "active") return { error: "blocked" as const };
      const [citizen] = await tx.select().from(citizensTable)
        .where(eq(citizensTable.discordUserId, id))
        .for("update");
      if (!citizen) return { error: "not_found" as const };

      if (kind === "deposit") {
        if (citizen.cashBalanceCents < cents) return { error: "funds" as const };
        await tx.update(citizensTable)
          .set({ cashBalanceCents: citizen.cashBalanceCents - cents })
          .where(eq(citizensTable.discordUserId, id));
        await tx.update(bankAccountsTable)
          .set({ balanceCents: account.balanceCents + cents })
          .where(eq(bankAccountsTable.id, account.id));
      } else {
        if (account.balanceCents < cents) return { error: "funds" as const };
        await tx.update(citizensTable)
          .set({ cashBalanceCents: citizen.cashBalanceCents + cents })
          .where(eq(citizensTable.discordUserId, id));
        await tx.update(bankAccountsTable)
          .set({ balanceCents: account.balanceCents - cents })
          .where(eq(bankAccountsTable.id, account.id));
      }
      const [entry] = await tx.insert(bankTransactionsTable).values({
        accountId: account.id,
        entryKind: kind,
        counterparty: kind === "deposit" ? "Apex Cash Desk" : "Apex ATM",
        amountCents: cents,
        description: data.description,
        receiptNumber: receiptNumber(),
        actorDiscordUserId: id,
      }).returning();
      return { entry };
    });
    if ("error" in transaction) {
      const status = transaction.error === "not_found" ? 404 : 409;
      res.status(status).json({
        error:
          transaction.error === "funds"
            ? "Insufficient cash or bank balance"
            : transaction.error === "blocked"
              ? "Account is frozen"
              : "Bank account not found",
      });
      return;
    }
    await audit(id, `bank.${kind}`, "bank_account", data.accountId, { amountCents: cents });
    const parsed =
      kind === "deposit"
        ? CreateDepositResponse.parse(mapTransaction(transaction.entry))
        : CreateWithdrawalResponse.parse(mapTransaction(transaction.entry));
    res.status(201).json(parsed);
  } catch (error) {
    req.log.error({ err: error }, "Bank cash movement failed");
    res.status(500).json({ error: "Bank movement could not be completed" });
  }
}

router.post(
  "/bank/deposits",
  requirePermission(PERMISSIONS.banking),
  async (req, res): Promise<void> => {
    const body = CreateDepositBody.safeParse(req.body);
    if (!body.success) {
      res.status(400).json({ error: body.error.message });
      return;
    }
    await performCashMovement(req, res, "deposit", body.data);
  },
);

router.post(
  "/bank/withdrawals",
  requirePermission(PERMISSIONS.banking),
  async (req, res): Promise<void> => {
    const body = CreateWithdrawalBody.safeParse(req.body);
    if (!body.success) {
      res.status(400).json({ error: body.error.message });
      return;
    }
    await performCashMovement(req, res, "withdrawal", body.data);
  },
);

router.post(
  "/bank/transfers",
  requirePermission(PERMISSIONS.banking),
  async (req, res, next): Promise<void> => {
    try {
      const body = CreateTransferBody.safeParse(req.body);
      if (!body.success) {
        res.status(400).json({ error: body.error.message });
        return;
      }
      const cents = toCents(body.data.amount);
      if (cents === null) {
        res.status(400).json({ error: "Amount must be a positive amount below 10,000,000" });
        return;
      }
      const id = actorId(req);
      const result = await db.transaction(async (tx) => {
        const [sourceCandidate] = await tx.select().from(bankAccountsTable)
          .where(eq(bankAccountsTable.id, body.data.sourceAccountId));
        if (
          !sourceCandidate ||
          (sourceCandidate.ownerDiscordUserId !== id &&
            !req.apexIsOwner &&
            !req.apexPermissions?.has(PERMISSIONS.bankingManage))
        ) {
          return { error: "not_found" as const };
        }
        const [targetCandidate] = await tx.select().from(bankAccountsTable)
          .where(eq(bankAccountsTable.iban, body.data.recipientIban.trim().toUpperCase()));
        if (!targetCandidate || targetCandidate.id === sourceCandidate.id) {
          return { error: "recipient" as const };
        }
        const ids = [sourceCandidate.id, targetCandidate.id].sort();
        const lockedAccounts = await tx.select().from(bankAccountsTable)
          .where(inArray(bankAccountsTable.id, ids))
          .orderBy(bankAccountsTable.id)
          .for("update");
        const source = lockedAccounts.find((account) => account.id === sourceCandidate.id);
        const target = lockedAccounts.find((account) => account.id === targetCandidate.id);
        if (!source || !target) return { error: "not_found" as const };
        if (source.status !== "active") return { error: "blocked" as const };
        if (target.status !== "active") return { error: "blocked" as const };
        if (source.balanceCents < cents) return { error: "funds" as const };
        await tx.update(bankAccountsTable)
          .set({ balanceCents: source.balanceCents - cents })
          .where(eq(bankAccountsTable.id, source.id));
        await tx.update(bankAccountsTable)
          .set({ balanceCents: target.balanceCents + cents })
          .where(eq(bankAccountsTable.id, target.id));
        const [outgoing] = await tx.insert(bankTransactionsTable).values({
          accountId: source.id,
          entryKind: "transfer_out",
          counterparty: target.displayName,
          amountCents: cents,
          description: body.data.description,
          receiptNumber: receiptNumber(),
          actorDiscordUserId: id,
        }).returning();
        await tx.insert(bankTransactionsTable).values({
          accountId: target.id,
          entryKind: "transfer_in",
          counterparty: source.displayName,
          amountCents: cents,
          description: body.data.description,
          receiptNumber: outgoing.receiptNumber,
          actorDiscordUserId: id,
        });
        return { outgoing };
      });
      if ("error" in result) {
        res.status(result.error === "recipient" || result.error === "not_found" ? 404 : 409).json({
          error:
            result.error === "recipient"
              ? "Recipient IBAN is invalid"
              : result.error === "funds"
                ? "Insufficient funds"
                : result.error === "blocked"
                  ? "Account is frozen"
                  : "Bank account not found",
        });
        return;
      }
      await audit(id, "bank.transfer", "bank_account", body.data.sourceAccountId, {
        amountCents: cents,
        receiptNumber: result.outgoing.receiptNumber,
      });
      res.status(201).json(CreateTransferResponse.parse(mapTransaction(result.outgoing)));
    } catch (error) {
      next(error);
    }
  },
);

router.get(
  "/dispatch/calls",
  requirePermission(PERMISSIONS.dispatch),
  async (_req, res, next): Promise<void> => {
    try {
      const calls = await db.select().from(dispatchCallsTable)
        .where(
          or(
            eq(dispatchCallsTable.status, "open"),
            eq(dispatchCallsTable.status, "assigned"),
            eq(dispatchCallsTable.status, "on_scene"),
          ),
        )
        .orderBy(desc(dispatchCallsTable.createdAt))
        .limit(100);
      res.json(ListDispatchCallsResponse.parse(calls.map(mapCall)));
    } catch (error) {
      next(error);
    }
  },
);

router.post(
  "/dispatch/calls",
  async (req, res, next): Promise<void> => {
    try {
      const body = CreateDispatchCallBody.safeParse(req.body);
      if (!body.success) {
        res.status(400).json({ error: body.error.message });
        return;
      }
      const submittingUser = actorId(req);
      const recentCalls = await db.select({ id: dispatchCallsTable.id })
        .from(dispatchCallsTable)
        .where(and(
          eq(dispatchCallsTable.createdByDiscordUserId, submittingUser),
          gte(dispatchCallsTable.createdAt, new Date(Date.now() - 60_000)),
        ))
        .limit(3);
      if (recentCalls.length >= 3) {
        res.status(429).json({ error: "Call limit reached; wait one minute before submitting another" });
        return;
      }
      const [call] = await db.insert(dispatchCallsTable).values({
        ...body.data,
        createdByDiscordUserId: submittingUser,
      }).returning();
      await audit(submittingUser, "dispatch.call.create", "dispatch_call", call.id);
      res.status(201).json(CreateDispatchCallResponse.parse(mapCall(call)));
    } catch (error) {
      next(error);
    }
  },
);

router.post(
  "/dispatch/calls/:callId/assign",
  requirePermission(PERMISSIONS.dispatchManage),
  async (req, res, next): Promise<void> => {
    try {
      const params = AssignDispatchUnitParams.safeParse(req.params);
      const body = AssignDispatchUnitBody.safeParse(req.body);
      if (!params.success) {
        res.status(400).json({ error: params.error.message });
        return;
      }
      if (!body.success) {
        res.status(400).json({ error: body.error.message });
        return;
      }
      const result = await db.transaction(async (tx) => {
        const [call] = await tx.select().from(dispatchCallsTable)
          .where(eq(dispatchCallsTable.id, params.data.callId))
          .for("update");
        const [unit] = await tx.select().from(dispatchUnitsTable)
          .where(eq(dispatchUnitsTable.id, body.data.unitId))
          .for("update");
        if (!call || !unit) return null;
        const assignedUnitIds = [...new Set([...call.assignedUnitIds, unit.id])];
        const [updatedCall] = await tx.update(dispatchCallsTable)
          .set({ assignedUnitIds, status: "assigned" })
          .where(eq(dispatchCallsTable.id, call.id))
          .returning();
        await tx.update(dispatchUnitsTable)
          .set({ status: "responding" })
          .where(eq(dispatchUnitsTable.id, unit.id));
        return updatedCall;
      });
      if (!result) {
        res.status(404).json({ error: "Call or unit not found" });
        return;
      }
      await audit(actorId(req), "dispatch.unit.assign", "dispatch_call", result.id, {
        unitId: body.data.unitId,
      });
      res.json(AssignDispatchUnitResponse.parse(mapCall(result)));
    } catch (error) {
      next(error);
    }
  },
);

router.get(
  "/dispatch/units",
  requirePermission(PERMISSIONS.dispatch),
  async (_req, res, next): Promise<void> => {
    try {
      const units = await db.select().from(dispatchUnitsTable)
        .orderBy(dispatchUnitsTable.callsign)
        .limit(100);
      res.json(ListDispatchUnitsResponse.parse(units.map(mapUnit)));
    } catch (error) {
      next(error);
    }
  },
);

router.post(
  "/dispatch/units",
  requirePermission(PERMISSIONS.dispatchManage),
  async (req, res, next): Promise<void> => {
    try {
      const body = CreateDispatchUnitBody.safeParse(req.body);
      if (!body.success) {
        res.status(400).json({ error: body.error.message });
        return;
      }
      const [unit] = await db.insert(dispatchUnitsTable).values({
        ...body.data,
        discordUserId: actorId(req),
        status: "off_duty",
      }).returning();
      await audit(actorId(req), "dispatch.unit.create", "dispatch_unit", unit.id);
      res.status(201).json(CreateDispatchUnitResponse.parse(mapUnit(unit)));
    } catch (error) {
      if ((error as { code?: string }).code === "23505") {
        res.status(409).json({ error: "Callsign is already in use" });
        return;
      }
      next(error);
    }
  },
);

router.patch(
  "/dispatch/units/:unitId",
  requirePermission(PERMISSIONS.dispatch),
  async (req, res, next): Promise<void> => {
    try {
      const params = UpdateDispatchUnitParams.safeParse(req.params);
      const body = UpdateDispatchUnitBody.safeParse(req.body);
      if (!params.success) {
        res.status(400).json({ error: params.error.message });
        return;
      }
      if (!body.success) {
        res.status(400).json({ error: body.error.message });
        return;
      }
      const [unit] = await db.select().from(dispatchUnitsTable)
        .where(eq(dispatchUnitsTable.id, params.data.unitId));
      const manager = req.apexIsOwner || req.apexPermissions?.has(PERMISSIONS.dispatchManage);
      if (!unit || (!manager && unit.discordUserId !== actorId(req))) {
        res.status(404).json({ error: "Unit not found" });
        return;
      }
      const [updated] = await db.update(dispatchUnitsTable)
        .set(body.data)
        .where(eq(dispatchUnitsTable.id, unit.id))
        .returning();
      await audit(actorId(req), "dispatch.unit.update", "dispatch_unit", updated.id, body.data);
      res.json(UpdateDispatchUnitResponse.parse(mapUnit(updated)));
    } catch (error) {
      next(error);
    }
  },
);

router.get(
  "/police/records",
  requirePermission(PERMISSIONS.police),
  async (req, res, next): Promise<void> => {
    try {
      const query = SearchPoliceRecordsQueryParams.safeParse(req.query);
      if (!query.success) {
        res.status(400).json({ error: query.error.message });
        return;
      }
      const search = query.data.search?.trim();
      const records = await db.select({
        record: policeRecordsTable,
        citizenName: citizensTable.displayName,
        citizenIdentityNumber: citizensTable.identityNumber,
      }).from(policeRecordsTable)
        .innerJoin(citizensTable, eq(policeRecordsTable.citizenDiscordUserId, citizensTable.discordUserId))
        .where(
          search
            ? or(
                ilike(citizensTable.displayName, `%${search}%`),
                ilike(citizensTable.identityNumber, `%${search}%`),
                ilike(citizensTable.discordUserId, `%${search}%`),
                ilike(policeRecordsTable.summary, `%${search}%`),
              )
            : undefined,
        )
        .orderBy(desc(policeRecordsTable.createdAt))
        .limit(100);
      res.json(
        SearchPoliceRecordsResponse.parse(
          records.map(({ record, citizenName, citizenIdentityNumber }) => ({
            id: record.id,
            citizenIdentityNumber,
            citizenDiscordUserId: record.citizenDiscordUserId,
            citizenName,
            recordType: record.recordType,
            summary: record.summary,
            amount: cashAmount(record.amountCents),
            status: record.status,
            createdAt: record.createdAt.toISOString(),
          })),
        ),
      );
    } catch (error) {
      next(error);
    }
  },
);

router.post(
  "/police/citations",
  requirePermission(PERMISSIONS.policeManage),
  async (req, res, next): Promise<void> => {
    try {
      const body = CreateCitationBody.safeParse(req.body);
      if (!body.success) {
        res.status(400).json({ error: body.error.message });
        return;
      }
      const cents = toCents(body.data.amount);
      if (cents === null) {
        res.status(400).json({ error: "Fine amount must be positive and below 10,000,000" });
        return;
      }
      const [citizen] = await db.select().from(citizensTable)
        .where(eq(citizensTable.identityNumber, body.data.citizenIdentityNumber.trim().toUpperCase()));
      if (!citizen) {
        res.status(404).json({ error: "Citizen not found" });
        return;
      }
      const record = await db.transaction(async (tx) => {
        const [account] = await tx.select().from(bankAccountsTable)
          .where(and(
            eq(bankAccountsTable.ownerDiscordUserId, citizen.discordUserId),
            eq(bankAccountsTable.accountType, "personal"),
            eq(bankAccountsTable.status, "active"),
          ))
          .for("update");
        const paid = Boolean(account && account.balanceCents >= cents);
        if (paid && account) {
          await tx.update(bankAccountsTable)
            .set({ balanceCents: account.balanceCents - cents })
            .where(eq(bankAccountsTable.id, account.id));
          await tx.insert(bankTransactionsTable).values({
            accountId: account.id,
            entryKind: "citation",
            counterparty: "Apex Police",
            amountCents: cents,
            description: body.data.reason,
            receiptNumber: receiptNumber(),
            actorDiscordUserId: actorId(req),
          });
        }
        const [created] = await tx.insert(policeRecordsTable).values({
          citizenDiscordUserId: citizen.discordUserId,
          recordType: "citation",
          summary: body.data.reason,
          amountCents: cents,
          status: paid ? "paid" : "unpaid",
          createdByDiscordUserId: actorId(req),
        }).returning();
        return created;
      });
      await audit(actorId(req), "police.citation.create", "police_record", record.id, {
        citizenDiscordUserId: citizen.discordUserId,
        amountCents: cents,
      });
      res.status(201).json(
        CreateCitationResponse.parse({
          id: record.id,
          citizenIdentityNumber: citizen.identityNumber,
          citizenDiscordUserId: citizen.discordUserId,
          citizenName: citizen.displayName,
          recordType: record.recordType,
          summary: record.summary,
          amount: record.amountCents! / 100,
          status: record.status,
          createdAt: record.createdAt.toISOString(),
        }),
      );
    } catch (error) {
      next(error);
    }
  },
);

router.get(
  "/medical/records",
  requirePermission(PERMISSIONS.medical),
  async (req, res, next): Promise<void> => {
    try {
      const query = SearchMedicalRecordsQueryParams.safeParse(req.query);
      if (!query.success) {
        res.status(400).json({ error: query.error.message });
        return;
      }
      const search = query.data.search?.trim();
      const records = await db.select({
        record: medicalRecordsTable,
        citizenName: citizensTable.displayName,
      }).from(medicalRecordsTable)
        .innerJoin(citizensTable, eq(medicalRecordsTable.citizenDiscordUserId, citizensTable.discordUserId))
        .where(
          search
            ? or(
                ilike(citizensTable.displayName, `%${search}%`),
                ilike(citizensTable.discordUserId, `%${search}%`),
                ilike(medicalRecordsTable.summary, `%${search}%`),
              )
            : undefined,
        )
        .orderBy(desc(medicalRecordsTable.createdAt))
        .limit(100);
      res.json(
        SearchMedicalRecordsResponse.parse(
          records.map(({ record, citizenName }) => ({
            id: record.id,
            citizenDiscordUserId: record.citizenDiscordUserId,
            citizenName,
            reportType: record.reportType,
            summary: record.summary,
            bloodType: record.bloodType,
            createdAt: record.createdAt.toISOString(),
          })),
        ),
      );
    } catch (error) {
      next(error);
    }
  },
);

router.post(
  "/medical/reports",
  requirePermission(PERMISSIONS.medicalManage),
  async (req, res, next): Promise<void> => {
    try {
      const body = CreateMedicalReportBody.safeParse(req.body);
      if (!body.success) {
        res.status(400).json({ error: body.error.message });
        return;
      }
      const [citizen] = await db.select().from(citizensTable)
        .where(eq(citizensTable.discordUserId, body.data.citizenDiscordUserId));
      if (!citizen) {
        res.status(404).json({ error: "Citizen not found" });
        return;
      }
      const [record] = await db.insert(medicalRecordsTable).values({
        ...body.data,
        createdByDiscordUserId: actorId(req),
      }).returning();
      await audit(actorId(req), "medical.report.create", "medical_record", record.id);
      res.status(201).json(
        CreateMedicalReportResponse.parse({
          id: record.id,
          citizenDiscordUserId: record.citizenDiscordUserId,
          citizenName: citizen.displayName,
          reportType: record.reportType,
          summary: record.summary,
          bloodType: record.bloodType,
          createdAt: record.createdAt.toISOString(),
        }),
      );
    } catch (error) {
      next(error);
    }
  },
);

router.get(
  "/community/properties",
  requirePermission(PERMISSIONS.community),
  async (req, res, next): Promise<void> => {
    try {
      const properties = await db.select().from(propertiesTable)
        .where(req.apexIsOwner ? undefined : eq(propertiesTable.ownerDiscordUserId, actorId(req)))
        .limit(100);
      res.json(
        ListPropertiesResponse.parse(
          properties.map((property) => ({
            id: property.id,
            ownerDiscordUserId: property.ownerDiscordUserId,
            address: property.address,
            propertyType: property.propertyType,
            keyholderCount: property.keyholderDiscordUserIds.length,
          })),
        ),
      );
    } catch (error) {
      next(error);
    }
  },
);

router.get(
  "/community/businesses",
  requirePermission(PERMISSIONS.community),
  async (req, res, next): Promise<void> => {
    try {
      const businesses = await db.select({
        business: businessesTable,
        iban: bankAccountsTable.iban,
      }).from(businessesTable)
        .leftJoin(bankAccountsTable, eq(businessesTable.bankAccountId, bankAccountsTable.id))
        .where(
          req.apexIsOwner || req.apexPermissions?.has(PERMISSIONS.bankingManage)
            ? undefined
            : eq(businessesTable.ownerDiscordUserId, actorId(req)),
        )
        .limit(100);
      res.json(
        ListBusinessesResponse.parse(
          businesses.map(({ business, iban }) => ({
            id: business.id,
            name: business.name,
            ownerDiscordUserId: business.ownerDiscordUserId,
            licenseStatus: business.licenseStatus,
            employeeCount: business.employeeDiscordUserIds.length,
            iban: iban ?? "",
          })),
        ),
      );
    } catch (error) {
      next(error);
    }
  },
);

router.get(
  "/admin/google-accounts",
  requireOwner,
  async (_req, res, next): Promise<void> => {
    try {
      const accounts = await db.select().from(googleStandaloneAccountsTable)
        .orderBy(desc(googleStandaloneAccountsTable.createdAt));
      res.json(accounts.map(({ googleSubject, email, username, avatarUrl, status, permissions, createdAt }) =>
        ({ googleSubject, email, username, avatarUrl, status, permissions, createdAt })));
    } catch (error) { next(error); }
  },
);

router.put(
  "/admin/google-accounts/:googleSubject",
  requireOwner,
  async (req, res, next): Promise<void> => {
    try {
      const subject = String(req.params.googleSubject || "");
      const { status, permissions } = req.body ?? {};
      if (!subject || !["pending", "approved", "revoked"].includes(status) ||
          !Array.isArray(permissions) ||
          (status === "approved" && permissions.length === 0) ||
          permissions.some((permission: unknown) => typeof permission !== "string" || !GOOGLE_READ_PERMISSIONS.has(permission))) {
        res.status(400).json({ error: "Invalid Google account access policy" });
        return;
      }
      const [account] = await db.update(googleStandaloneAccountsTable)
        .set({ status, permissions })
        .where(eq(googleStandaloneAccountsTable.googleSubject, subject))
        .returning();
      if (!account) { res.status(404).json({ error: "Google account not found" }); return; }
      res.json({ googleSubject: account.googleSubject, status: account.status, permissions: account.permissions });
    } catch (error) { next(error); }
  },
);

router.get(
  "/admin/access",
  requireOwner,
  async (_req, res, next): Promise<void> => {
    try {
      const policies = await db.select().from(accessPoliciesTable)
        .orderBy(accessPoliciesTable.roleName);
      res.json(ListAccessPoliciesResponse.parse(policies.map((policy) => ({
        roleId: policy.roleId,
        roleName: policy.roleName,
        permissions: policy.permissions,
      }))));
    } catch (error) {
      next(error);
    }
  },
);

router.put(
  "/admin/access/:roleId",
  requireOwner,
  async (req, res, next): Promise<void> => {
    try {
      const params = UpdateAccessPolicyParams.safeParse(req.params);
      const body = UpdateAccessPolicyBody.safeParse(req.body);
      if (!params.success) {
        res.status(400).json({ error: params.error.message });
        return;
      }
      if (!/^\d{17,22}$/.test(params.data.roleId)) {
        res.status(400).json({ error: "Role ID must be a Discord snowflake" });
        return;
      }
      if (!body.success) {
        res.status(400).json({ error: body.error.message });
        return;
      }
      const [policy] = await db.insert(accessPoliciesTable).values({
        roleId: params.data.roleId,
        roleName: body.data.roleName,
        permissions: body.data.permissions,
        updatedByDiscordUserId: actorId(req),
      }).onConflictDoUpdate({
        target: accessPoliciesTable.roleId,
        set: {
          roleName: body.data.roleName,
          permissions: body.data.permissions,
          updatedByDiscordUserId: actorId(req),
          updatedAt: new Date(),
        },
      }).returning();
      await audit(actorId(req), "admin.access.update", "discord_role", policy.roleId, {
        permissions: policy.permissions,
      });
      res.json(UpdateAccessPolicyResponse.parse({
        roleId: policy.roleId,
        roleName: policy.roleName,
        permissions: policy.permissions,
      }));
    } catch (error) {
      next(error);
    }
  },
);

router.get(
  "/admin/security-events",
  requireOwner,
  async (_req, res, next): Promise<void> => {
    try {
      const events = await db.select().from(securityEventsTable)
        .orderBy(desc(securityEventsTable.createdAt))
        .limit(100);
      res.json(
        ListSecurityEventsResponse.parse(
          events.map((event) => ({
            id: event.id,
            eventType: event.eventType,
            actorDiscordUserId: event.actorDiscordUserId,
            targetDiscordUserId: event.targetDiscordUserId,
            details: event.details,
            actionTaken: event.actionTaken,
            createdAt: event.createdAt.toISOString(),
          })),
        ),
      );
    } catch (error) {
      next(error);
    }
  },
);

export default router;
