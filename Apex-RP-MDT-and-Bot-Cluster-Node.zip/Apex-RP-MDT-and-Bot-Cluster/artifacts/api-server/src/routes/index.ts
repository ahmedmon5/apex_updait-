import { Router, type IRouter } from "express";
import healthRouter from "./health";
import apexRouter from "./apex";
import { createAuthRouter } from "../lib/apex-auth";

const router: IRouter = Router();

router.use(healthRouter);
router.use(createAuthRouter());
router.use(apexRouter);

export default router;
