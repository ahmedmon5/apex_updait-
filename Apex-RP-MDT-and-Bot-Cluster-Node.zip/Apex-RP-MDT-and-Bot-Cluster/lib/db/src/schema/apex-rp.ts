import {
  bigint,
  boolean,
  index,
  jsonb,
  pgTable,
  text,
  timestamp,
  uniqueIndex,
  uuid,
} from "drizzle-orm/pg-core";
import { sql } from "drizzle-orm";

export const citizensTable = pgTable(
  "apex_citizens",
  {
    discordUserId: text("discord_user_id").primaryKey(),
    identityNumber: text("identity_number").notNull().unique().default(
      sql`'APX-' || upper(substr(replace(gen_random_uuid()::text, '-', ''), 1, 12))`,
    ),
    displayName: text("display_name").notNull(),
    phone: text("phone"),
    occupation: text("occupation").notNull().default("مواطن"),
    citizenStatus: text("citizen_status").notNull().default("active"),
    cashBalanceCents: bigint("cash_balance_cents", { mode: "number" })
      .notNull()
      .default(0),
    lastSeen: timestamp("last_seen", { withTimezone: true }),
    createdAt: timestamp("created_at", { withTimezone: true })
      .notNull()
      .defaultNow(),
    updatedAt: timestamp("updated_at", { withTimezone: true })
      .notNull()
      .defaultNow()
      .$onUpdate(() => new Date()),
  },
  (table) => [index("apex_citizens_display_name_idx").on(table.displayName)],
);

export const googleOAuthLinksTable = pgTable(
  "apex_google_oauth_links",
  {
    googleSubject: text("google_subject").primaryKey(),
    discordUserId: text("discord_user_id")
      .notNull()
      .references(() => citizensTable.discordUserId, { onDelete: "cascade" }),
    googleEmail: text("google_email").notNull(),
    encryptedDiscordRefreshToken: text(
      "encrypted_discord_refresh_token",
    ).notNull(),
    linkedAt: timestamp("linked_at", { withTimezone: true })
      .notNull()
      .defaultNow(),
    updatedAt: timestamp("updated_at", { withTimezone: true })
      .notNull()
      .defaultNow()
      .$onUpdate(() => new Date()),
  },
  (table) => [
    uniqueIndex("apex_google_oauth_links_discord_user_id_uidx").on(
      table.discordUserId,
    ),
  ],
);

export const googleStandaloneAccountsTable = pgTable(
  "apex_google_accounts",
  {
    googleSubject: text("google_subject").primaryKey(),
    email: text("email").notNull(),
    username: text("username").notNull(),
    avatarUrl: text("avatar_url"),
    status: text("status").notNull().default("pending"),
    permissions: text("permissions").array().notNull().default([]),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
    updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow().$onUpdate(() => new Date()),
  },
  (table) => [index("apex_google_accounts_status_idx").on(table.status)],
);

export const robloxOAuthLinksTable = pgTable(
  "apex_roblox_oauth_links",
  {
    robloxSubject: text("roblox_subject").primaryKey(),
    discordUserId: text("discord_user_id")
      .notNull()
      .references(() => citizensTable.discordUserId, { onDelete: "cascade" }),
    robloxUsername: text("roblox_username").notNull(),
    encryptedDiscordRefreshToken: text(
      "encrypted_discord_refresh_token",
    ).notNull(),
    linkedAt: timestamp("linked_at", { withTimezone: true })
      .notNull()
      .defaultNow(),
    updatedAt: timestamp("updated_at", { withTimezone: true })
      .notNull()
      .defaultNow()
      .$onUpdate(() => new Date()),
  },
  (table) => [
    uniqueIndex("apex_roblox_oauth_links_discord_user_id_uidx").on(
      table.discordUserId,
    ),
  ],
);

export const bankAccountsTable = pgTable(
  "apex_bank_accounts",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    ownerDiscordUserId: text("owner_discord_user_id")
      .notNull()
      .references(() => citizensTable.discordUserId),
    displayName: text("display_name").notNull(),
    iban: text("iban").notNull(),
    accountType: text("account_type").notNull().default("personal"),
    balanceCents: bigint("balance_cents", { mode: "number" })
      .notNull()
      .default(0),
    currency: text("currency").notNull().default("USD"),
    status: text("status").notNull().default("active"),
    createdAt: timestamp("created_at", { withTimezone: true })
      .notNull()
      .defaultNow(),
  },
  (table) => [
    uniqueIndex("apex_bank_accounts_iban_unique").on(table.iban),
    index("apex_bank_accounts_owner_idx").on(table.ownerDiscordUserId),
  ],
);

export const bankTransactionsTable = pgTable(
  "apex_bank_transactions",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    accountId: uuid("account_id")
      .notNull()
      .references(() => bankAccountsTable.id),
    entryKind: text("entry_kind").notNull(),
    counterparty: text("counterparty").notNull().default("Apex RP"),
    amountCents: bigint("amount_cents", { mode: "number" }).notNull(),
    description: text("description").notNull(),
    receiptNumber: text("receipt_number").notNull(),
    actorDiscordUserId: text("actor_discord_user_id").notNull(),
    createdAt: timestamp("created_at", { withTimezone: true })
      .notNull()
      .defaultNow(),
  },
  (table) => [
    index("apex_bank_transactions_account_created_idx").on(
      table.accountId,
      table.createdAt,
    ),
    index("apex_bank_transactions_receipt_idx").on(table.receiptNumber),
  ],
);

export const dispatchCallsTable = pgTable(
  "apex_dispatch_calls",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    callType: text("call_type").notNull(),
    title: text("title").notNull(),
    location: text("location").notNull(),
    notes: text("notes").notNull().default(""),
    status: text("status").notNull().default("open"),
    callerName: text("caller_name").notNull(),
    priority: text("priority").notNull().default("normal"),
    assignedUnitIds: text("assigned_unit_ids").array().notNull().default([]),
    createdByDiscordUserId: text("created_by_discord_user_id").notNull(),
    createdAt: timestamp("created_at", { withTimezone: true })
      .notNull()
      .defaultNow(),
    updatedAt: timestamp("updated_at", { withTimezone: true })
      .notNull()
      .defaultNow()
      .$onUpdate(() => new Date()),
  },
  (table) => [
    index("apex_dispatch_calls_status_priority_idx").on(
      table.status,
      table.priority,
    ),
  ],
);

export const dispatchUnitsTable = pgTable(
  "apex_dispatch_units",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    callsign: text("callsign").notNull(),
    department: text("department").notNull(),
    displayName: text("display_name").notNull(),
    status: text("status").notNull().default("off_duty"),
    location: text("location").notNull().default("غير محدد"),
    discordUserId: text("discord_user_id").notNull(),
    updatedAt: timestamp("updated_at", { withTimezone: true })
      .notNull()
      .defaultNow()
      .$onUpdate(() => new Date()),
  },
  (table) => [
    uniqueIndex("apex_dispatch_units_callsign_unique").on(table.callsign),
    index("apex_dispatch_units_user_idx").on(table.discordUserId),
  ],
);

export const policeRecordsTable = pgTable(
  "apex_police_records",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    citizenDiscordUserId: text("citizen_discord_user_id")
      .notNull()
      .references(() => citizensTable.discordUserId),
    recordType: text("record_type").notNull(),
    summary: text("summary").notNull(),
    amountCents: bigint("amount_cents", { mode: "number" }),
    status: text("status").notNull().default("open"),
    createdByDiscordUserId: text("created_by_discord_user_id").notNull(),
    createdAt: timestamp("created_at", { withTimezone: true })
      .notNull()
      .defaultNow(),
  },
  (table) => [
    index("apex_police_records_citizen_idx").on(table.citizenDiscordUserId),
  ],
);

export const medicalRecordsTable = pgTable(
  "apex_medical_records",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    citizenDiscordUserId: text("citizen_discord_user_id")
      .notNull()
      .references(() => citizensTable.discordUserId),
    reportType: text("report_type").notNull(),
    summary: text("summary").notNull(),
    bloodType: text("blood_type"),
    createdByDiscordUserId: text("created_by_discord_user_id").notNull(),
    createdAt: timestamp("created_at", { withTimezone: true })
      .notNull()
      .defaultNow(),
  },
  (table) => [
    index("apex_medical_records_citizen_idx").on(
      table.citizenDiscordUserId,
      table.createdAt,
    ),
  ],
);

export const propertiesTable = pgTable(
  "apex_properties",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    ownerDiscordUserId: text("owner_discord_user_id")
      .notNull()
      .references(() => citizensTable.discordUserId),
    address: text("address").notNull(),
    propertyType: text("property_type").notNull(),
    keyholderDiscordUserIds: text("keyholder_discord_user_ids")
      .array()
      .notNull()
      .default([]),
  },
  (table) => [
    index("apex_properties_owner_idx").on(table.ownerDiscordUserId),
  ],
);

export const businessesTable = pgTable(
  "apex_businesses",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    name: text("name").notNull(),
    ownerDiscordUserId: text("owner_discord_user_id")
      .notNull()
      .references(() => citizensTable.discordUserId),
    licenseStatus: text("license_status").notNull().default("pending"),
    employeeDiscordUserIds: text("employee_discord_user_ids")
      .array()
      .notNull()
      .default([]),
    bankAccountId: uuid("bank_account_id").references(
      () => bankAccountsTable.id,
    ),
  },
  (table) => [
    index("apex_businesses_owner_idx").on(table.ownerDiscordUserId),
  ],
);

export const accessPoliciesTable = pgTable(
  "apex_access_policies",
  {
    roleId: text("role_id").primaryKey(),
    roleName: text("role_name").notNull(),
    permissions: text("permissions").array().notNull().default([]),
    updatedByDiscordUserId: text("updated_by_discord_user_id").notNull(),
    updatedAt: timestamp("updated_at", { withTimezone: true })
      .notNull()
      .defaultNow()
      .$onUpdate(() => new Date()),
  },
  (table) => [index("apex_access_policies_name_idx").on(table.roleName)],
);

export const securityEventsTable = pgTable(
  "apex_security_events",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    eventType: text("event_type").notNull(),
    actorDiscordUserId: text("actor_discord_user_id").notNull(),
    targetDiscordUserId: text("target_discord_user_id"),
    details: text("details").notNull(),
    actionTaken: text("action_taken").notNull(),
    metadata: jsonb("metadata").$type<Record<string, unknown>>().notNull().default({}),
    acknowledged: boolean("acknowledged").notNull().default(false),
    createdAt: timestamp("created_at", { withTimezone: true })
      .notNull()
      .defaultNow(),
  },
  (table) => [
    index("apex_security_events_created_idx").on(table.createdAt),
    index("apex_security_events_actor_idx").on(table.actorDiscordUserId),
  ],
);

export const auditEventsTable = pgTable(
  "apex_audit_events",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    actorDiscordUserId: text("actor_discord_user_id").notNull(),
    action: text("action").notNull(),
    entityType: text("entity_type").notNull(),
    entityId: text("entity_id"),
    metadata: jsonb("metadata").$type<Record<string, unknown>>().notNull().default({}),
    createdAt: timestamp("created_at", { withTimezone: true })
      .notNull()
      .defaultNow(),
  },
  (table) => [
    index("apex_audit_events_created_idx").on(table.createdAt),
    index("apex_audit_events_actor_idx").on(table.actorDiscordUserId),
  ],
);

export const botJobsTable = pgTable(
  "apex_bot_jobs",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    jobType: text("job_type").notNull(),
    payload: jsonb("payload").$type<Record<string, unknown>>().notNull().default({}),
    status: text("status").notNull().default("queued"),
    attempts: bigint("attempts", { mode: "number" }).notNull().default(0),
    maxAttempts: bigint("max_attempts", { mode: "number" }).notNull().default(8),
    availableAt: timestamp("available_at", { withTimezone: true })
      .notNull()
      .defaultNow(),
    claimedBy: text("claimed_by"),
    claimedAt: timestamp("claimed_at", { withTimezone: true }),
    lastError: text("last_error"),
    createdAt: timestamp("created_at", { withTimezone: true })
      .notNull()
      .defaultNow(),
    completedAt: timestamp("completed_at", { withTimezone: true }),
  },
  (table) => [
    index("apex_bot_jobs_claim_idx").on(
      table.status,
      table.availableAt,
      table.createdAt,
    ),
  ],
);
