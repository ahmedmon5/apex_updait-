import {
  boolean,
  index,
  integer,
  jsonb,
  pgTable,
  text,
  timestamp,
  uniqueIndex,
  uuid,
} from "drizzle-orm/pg-core";
import { sql } from "drizzle-orm";

export const localAuthAccountsTable = pgTable(
  "apex_local_auth_accounts",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    username: text("username").notNull(),
    email: text("email"),
    emailVerifiedAt: timestamp("email_verified_at", { withTimezone: true }),
    passwordHash: text("password_hash").notNull(),
    status: text("status").notNull().default("pending"),
    isOwner: boolean("is_owner").notNull().default(false),
    permissions: text("permissions").array().notNull().default([]),
    totpSecretEncrypted: text("totp_secret_encrypted"),
    totpEnabled: boolean("totp_enabled").notNull().default(false),
    totpLastStep: integer("totp_last_step").notNull().default(-1),
    recoveryCodeHashes: text("recovery_code_hashes").array().notNull().default([]),
    sessionVersion: integer("session_version").notNull().default(0),
    failedLoginCount: integer("failed_login_count").notNull().default(0),
    lockedUntil: timestamp("locked_until", { withTimezone: true }),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
    updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow().$onUpdate(() => new Date()),
  },
  (table) => [
    uniqueIndex("apex_local_auth_username_uidx").on(sql`lower(${table.username})`),
    uniqueIndex("apex_local_auth_email_uidx").on(sql`lower(${table.email})`).where(sql`${table.email} IS NOT NULL`),
    uniqueIndex("apex_local_auth_single_owner_uidx").on(table.isOwner).where(sql`${table.isOwner} = true`),
    index("apex_local_auth_status_idx").on(table.status),
  ],
);

export const localEmailVerificationsTable = pgTable(
  "apex_local_email_verifications",
  {
    email: text("email").primaryKey(),
    username: text("username").notNull(),
    passwordHash: text("password_hash").notNull(),
    codeHash: text("code_hash").notNull(),
    expiresAt: timestamp("expires_at", { withTimezone: true }).notNull(),
    attempts: integer("attempts").notNull().default(0),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (table) => [index("apex_local_email_verifications_expires_idx").on(table.expiresAt)],
);

export const localAuthBootstrapTable = pgTable("apex_local_auth_bootstrap", {
  id: text("id").primaryKey().default("singleton"),
  consumedAt: timestamp("consumed_at", { withTimezone: true }),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

