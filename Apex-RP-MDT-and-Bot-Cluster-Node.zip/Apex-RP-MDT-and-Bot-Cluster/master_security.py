"""APEX RP Discord gateway bot: slash commands and configurable audit defense.

Only this process owns a Discord Gateway connection.  Worker processes claim
database jobs and use normal Discord REST rate limits; adding accounts does not
bypass Discord's application-wide limits.
"""

from __future__ import annotations

import asyncio
import json
import logging
import os
import time
from collections import defaultdict, deque
from datetime import timedelta
from decimal import Decimal, ROUND_HALF_UP

import asyncpg
import discord
from discord import app_commands
from discord.ext import commands
from dotenv import load_dotenv

load_dotenv()
logging.basicConfig(
    level=os.getenv("LOG_LEVEL", "INFO"),
    format="%(asctime)s %(levelname)s %(name)s %(message)s",
)
logger = logging.getLogger("apex.master")


def required_env(name: str) -> str:
    value = os.getenv(name)
    if not value:
        raise RuntimeError(f"{name} is required")
    return value


def id_set(name: str) -> set[int]:
    return {int(value.strip()) for value in os.getenv(name, "").split(",") if value.strip().isdigit()}


def cents_from_amount(amount: float) -> int | None:
    if amount <= 0 or amount > 10_000_000:
        return None
    cents = int((Decimal(str(amount)) * 100).quantize(Decimal("1"), rounding=ROUND_HALF_UP))
    return cents if cents > 0 else None


OWNER_ID = int(required_env("OWNER_DISCORD_ID"))
GUILD_ID = int(required_env("DISCORD_GUILD_ID"))
BOT_TOKEN = required_env("BOT_TOKEN")
PROTECTED_ROLE_IDS = id_set("PROTECTED_ROLE_IDS")
SENSITIVE_ROLE_IDS = id_set("SENSITIVE_ROLE_IDS")
TRUSTED_ADMIN_IDS = id_set("TRUSTED_ADMIN_IDS") | {OWNER_ID}
MODE = os.getenv("ANTI_NUKE_MODE", "alert").lower()
if MODE not in {"alert", "quarantine"}:
    raise RuntimeError("ANTI_NUKE_MODE must be 'alert' or 'quarantine'")
ACTOR_THRESHOLD = max(2, int(os.getenv("ANTI_NUKE_ACTOR_THRESHOLD", "3")))
JOIN_THRESHOLD = max(3, int(os.getenv("ANTI_RAID_JOIN_THRESHOLD", "8")))
JOIN_WINDOW_SECONDS = max(15, int(os.getenv("ANTI_RAID_JOIN_WINDOW_SECONDS", "45")))

dangerous_actions = {
    discord.AuditLogAction.channel_delete,
    discord.AuditLogAction.role_delete,
    discord.AuditLogAction.role_update,
    discord.AuditLogAction.role_create,
    discord.AuditLogAction.member_ban,
    discord.AuditLogAction.member_kick,
    discord.AuditLogAction.member_prune,
    discord.AuditLogAction.member_role_update,
    discord.AuditLogAction.webhook_create,
    discord.AuditLogAction.webhook_delete,
}

intents = discord.Intents.none()
intents.guilds = True
intents.members = True
intents.moderation = True


class ApexBot(commands.Bot):
    def __init__(self) -> None:
        super().__init__(command_prefix=commands.when_mentioned, intents=intents)
        self.pool: asyncpg.Pool | None = None
        self.actor_events: dict[int, deque[float]] = defaultdict(deque)
        self.join_events: deque[float] = deque()

    async def setup_hook(self) -> None:
        self.pool = await asyncpg.create_pool(
            dsn=required_env("DATABASE_URL"),
            min_size=1,
            max_size=int(os.getenv("BOT_DB_POOL_SIZE", "5")),
            command_timeout=12,
        )
        guild = discord.Object(id=GUILD_ID)
        self.tree.add_command(bank_group, guild=guild)
        self.tree.add_command(ems_group, guild=guild)
        self.tree.add_command(police_group, guild=guild)
        await self.tree.sync(guild=guild)
        logger.info("Slash commands synchronized for guild %s", GUILD_ID)

    async def close(self) -> None:
        if self.pool is not None:
            await self.pool.close()
        await super().close()

    async def enqueue_owner_notice(self, content: str) -> None:
        if self.pool is None:
            return
        async with self.pool.acquire() as connection:
            await connection.execute(
                """
                INSERT INTO apex_bot_jobs (job_type, payload, status)
                VALUES ('send_owner_dm', $1::jsonb, 'queued')
                """,
                json.dumps({"user_id": str(OWNER_ID), "content": content[:1800]}),
            )

    async def record_security_event(
        self,
        *,
        event_type: str,
        actor_id: int,
        target_id: int | None,
        details: str,
        action_taken: str,
        metadata: dict[str, object],
    ) -> None:
        if self.pool is None:
            return
        async with self.pool.acquire() as connection:
            async with connection.transaction():
                await connection.execute(
                    """
                    INSERT INTO apex_security_events
                      (event_type, actor_discord_user_id, target_discord_user_id,
                       details, action_taken, metadata)
                    VALUES ($1, $2, $3, $4, $5, $6::jsonb)
                    """,
                    event_type,
                    str(actor_id),
                    str(target_id) if target_id is not None else None,
                    details[:2000],
                    action_taken[:500],
                    json.dumps(metadata),
                )
                await connection.execute(
                    """
                    INSERT INTO apex_bot_jobs (job_type, payload, status)
                    VALUES ('send_owner_dm', $1::jsonb, 'queued')
                    """,
                    json.dumps(
                        {
                            "user_id": str(OWNER_ID),
                            "content": (
                                f"تنبيه أمني — {event_type}\n"
                                f"المنفذ: {actor_id}\n"
                                f"الهدف: {target_id or 'غير محدد'}\n"
                                f"التفاصيل: {details[:900]}\n"
                                f"الإجراء: {action_taken}"
                            )[:1800],
                        }
                    ),
                )

    async def apply_guarded_action(
        self,
        entry: discord.AuditLogEntry,
        actor: discord.Member | None,
        event_count: int,
    ) -> str:
        if MODE != "quarantine" or actor is None or actor.id == OWNER_ID:
            return "تم تسجيل الحادثة وإشعار المالك؛ الوضع الحالي لا ينفذ إجراءً تلقائياً"

        actions: list[str] = []
        if entry.action == discord.AuditLogAction.member_role_update:
            target = entry.target
            before_roles = {
                role.id for role in getattr(getattr(entry, "before", None), "roles", [])
            }
            after_roles = {
                role.id for role in getattr(getattr(entry, "after", None), "roles", [])
            }
            added_protected = [
                role
                for role in getattr(target, "roles", [])
                if role.id in PROTECTED_ROLE_IDS and role.id not in before_roles
            ]
            if isinstance(target, discord.Member) and added_protected:
                await target.remove_roles(
                    *added_protected,
                    reason="APEX RP anti-nuke: unauthorized protected role grant",
                )
                actions.append("أزيلت رتبة محمية محددة مسبقاً من المستلم")

        if event_count >= ACTOR_THRESHOLD:
            try:
                await actor.timeout(
                    timedelta(minutes=30),
                    reason="APEX RP anti-nuke: repeated sensitive audit events",
                )
                actions.append("تقييد قابل للإلغاء لمدة 30 دقيقة بعد تجاوز العتبة")
            except (discord.Forbidden, discord.HTTPException):
                logger.warning("Could not apply configured timeout to actor %s", actor.id)

            if SENSITIVE_ROLE_IDS:
                removable = [
                    role for role in actor.roles
                    if role.id in SENSITIVE_ROLE_IDS and role < actor.guild.me.top_role
                ]
                if removable:
                    try:
                        await actor.remove_roles(
                            *removable,
                            reason="APEX RP anti-nuke: configured sensitive roles",
                        )
                        actions.append("أزيلت الرتب الحساسة المحددة من المنفذ")
                    except (discord.Forbidden, discord.HTTPException):
                        logger.warning("Could not remove configured roles from actor %s", actor.id)

        if not actions:
            return "تم تسجيل الحادثة وإشعار المالك؛ لم يتحقق شرط الإجراء الاختياري"
        return "؛ ".join(actions)

    async def on_audit_log_entry_create(self, entry: discord.AuditLogEntry) -> None:
        if entry.guild.id != GUILD_ID or entry.action not in dangerous_actions:
            return
        actor = entry.user if isinstance(entry.user, discord.Member) else None
        actor_id = getattr(entry.user, "id", 0) or 0
        if not actor_id:
            return

        target_id = getattr(entry.target, "id", None)
        if actor_id in TRUSTED_ADMIN_IDS:
            return

        now = time.monotonic()
        actor_events = self.actor_events[actor_id]
        actor_events.append(now)
        while actor_events and now - actor_events[0] > 60:
            actor_events.popleft()
        action = str(entry.action).rsplit(".", maxsplit=1)[-1]
        details = f"{action}; audit entry {entry.id}; reason={entry.reason or 'غير مذكور'}"
        try:
            action_taken = await self.apply_guarded_action(entry, actor, len(actor_events))
            await self.record_security_event(
                event_type=action,
                actor_id=actor_id,
                target_id=target_id,
                details=details,
                action_taken=action_taken,
                metadata={"audit_entry_id": str(entry.id), "mode": MODE},
            )
        except Exception:
            logger.exception("Failed to handle audit event %s", entry.id)

    async def on_member_join(self, member: discord.Member) -> None:
        if member.guild.id != GUILD_ID:
            return
        now = time.monotonic()
        self.join_events.append(now)
        while self.join_events and now - self.join_events[0] > JOIN_WINDOW_SECONDS:
            self.join_events.popleft()
        if len(self.join_events) == JOIN_THRESHOLD:
            await self.record_security_event(
                event_type="join_burst",
                actor_id=0,
                target_id=member.id,
                details=(
                    f"{len(self.join_events)} joins in {JOIN_WINDOW_SECONDS} seconds"
                ),
                action_taken="تم إرسال تنبيه للمالك فقط؛ لا توجد عقوبة تلقائية للمنضمين",
                metadata={
                    "window_seconds": JOIN_WINDOW_SECONDS,
                    "threshold": JOIN_THRESHOLD,
                },
            )


bot = ApexBot()


def has_configured_role(interaction: discord.Interaction, env_name: str) -> bool:
    if interaction.user.id == OWNER_ID:
        return True
    allowed = id_set(env_name)
    member = interaction.user
    return isinstance(member, discord.Member) and any(role.id in allowed for role in member.roles)


bank_group = app_commands.Group(name="bank", description="خدمات بنك أبيكس")


@bank_group.command(name="balance", description="عرض أرصدة حساباتك")
async def bank_balance(interaction: discord.Interaction) -> None:
    if bot.pool is None:
        await interaction.response.send_message("الخدمة غير متاحة حالياً.", ephemeral=True)
        return
    rows = await bot.pool.fetch(
        """
        SELECT display_name, iban, balance_cents, currency
        FROM apex_bank_accounts
        WHERE owner_discord_user_id = $1 AND status = 'active'
        ORDER BY created_at
        """,
        str(interaction.user.id),
    )
    if not rows:
        await interaction.response.send_message(
            "لا يوجد لديك حساب مصرفي نشط في بنك أبيكس.", ephemeral=True
        )
        return
    lines = [
        f"**{row['display_name']}** · `{row['iban']}` · "
        f"{Decimal(row['balance_cents']) / 100:.2f} {row['currency']}"
        for row in rows
    ]
    await interaction.response.send_message("\n".join(lines), ephemeral=True)


@bot.tree.command(name="pay", description="تحويل رصيد إلى مواطن آخر")
@app_commands.describe(recipient="المستلم", amount="المبلغ بالدولار", note="وصف التحويل")
async def pay(
    interaction: discord.Interaction,
    recipient: discord.Member,
    amount: app_commands.Range[float, 0.01, 10_000_000],
    note: app_commands.Range[str, 1, 160] = "تحويل مواطن",
) -> None:
    if bot.pool is None:
        await interaction.response.send_message("الخدمة غير متاحة حالياً.", ephemeral=True)
        return
    cents = cents_from_amount(amount)
    if cents is None or recipient.id == interaction.user.id or recipient.bot:
        await interaction.response.send_message("بيانات التحويل غير صالحة.", ephemeral=True)
        return
    receipt = f"APX-{int(time.time())}-{os.urandom(3).hex().upper()}"
    try:
        async with bot.pool.acquire() as connection:
            async with connection.transaction():
                rows = await connection.fetch(
                    """
                    SELECT id, owner_discord_user_id, display_name, balance_cents
                    FROM apex_bank_accounts
                    WHERE owner_discord_user_id = ANY($1::text[])
                      AND account_type = 'personal' AND status = 'active'
                    ORDER BY id
                    FOR UPDATE
                    """,
                    [str(interaction.user.id), str(recipient.id)],
                )
                source = next((row for row in rows if row["owner_discord_user_id"] == str(interaction.user.id)), None)
                target = next((row for row in rows if row["owner_discord_user_id"] == str(recipient.id)), None)
                if not source or not target:
                    raise ValueError("missing account")
                if source["balance_cents"] < cents:
                    raise ValueError("funds")
                await connection.execute(
                    "UPDATE apex_bank_accounts SET balance_cents = balance_cents - $1 WHERE id = $2",
                    cents, source["id"],
                )
                await connection.execute(
                    "UPDATE apex_bank_accounts SET balance_cents = balance_cents + $1 WHERE id = $2",
                    cents, target["id"],
                )
                for account, kind, counterparty in (
                    (source, "transfer_out", target["display_name"]),
                    (target, "transfer_in", source["display_name"]),
                ):
                    await connection.execute(
                        """
                        INSERT INTO apex_bank_transactions
                          (account_id, entry_kind, counterparty, amount_cents,
                           description, receipt_number, actor_discord_user_id)
                        VALUES ($1, $2, $3, $4, $5, $6, $7)
                        """,
                        account["id"], kind, counterparty, cents, note, receipt,
                        str(interaction.user.id),
                    )
    except ValueError as error:
        message = (
            "الرصيد غير كافٍ."
            if str(error) == "funds"
            else "يجب أن يمتلك الطرفان حساباً شخصياً نشطاً."
        )
        await interaction.response.send_message(message, ephemeral=True)
        return
    await interaction.response.send_message(
        f"تم التحويل بنجاح. الإيصال: `{receipt}`", ephemeral=True
    )


ems_group = app_commands.Group(name="ems", description="خدمات الإسعاف")


@ems_group.command(name="report", description="تسجيل تقرير رعاية لمريض")
@app_commands.describe(
    citizen_id="معرّف Discord للمواطن",
    summary="ملخص الحالة والإجراء",
    blood_type="فصيلة الدم إن كانت معروفة",
)
async def ems_report(
    interaction: discord.Interaction,
    citizen_id: app_commands.Range[str, 17, 22],
    summary: app_commands.Range[str, 5, 1500],
    blood_type: str = "غير معروف",
) -> None:
    if not has_configured_role(interaction, "EMS_ROLE_IDS"):
        await interaction.response.send_message("ليس لديك صلاحية الإسعاف.", ephemeral=True)
        return
    if bot.pool is None:
        await interaction.response.send_message("الخدمة غير متاحة حالياً.", ephemeral=True)
        return
    exists = await bot.pool.fetchval(
        "SELECT 1 FROM apex_citizens WHERE discord_user_id = $1",
        citizen_id,
    )
    if not exists:
        await interaction.response.send_message("لم يتم العثور على سجل المواطن.", ephemeral=True)
        return
    await bot.pool.execute(
        """
        INSERT INTO apex_medical_records
          (citizen_discord_user_id, report_type, summary, blood_type, created_by_discord_user_id)
        VALUES ($1, 'pcr', $2, $3, $4)
        """,
        citizen_id,
        summary,
        blood_type[:20],
        str(interaction.user.id),
    )
    await interaction.response.send_message("تم حفظ تقرير الرعاية الطبية.", ephemeral=True)


police_group = app_commands.Group(name="police", description="خدمات الشرطة")


@police_group.command(name="citation", description="إصدار مخالفة لمواطن")
@app_commands.describe(citizen_id="معرّف Discord للمواطن", amount="قيمة المخالفة", reason="سبب المخالفة")
async def police_citation(
    interaction: discord.Interaction,
    citizen_id: app_commands.Range[str, 17, 22],
    amount: app_commands.Range[float, 0.01, 10_000_000],
    reason: app_commands.Range[str, 4, 500],
) -> None:
    if not has_configured_role(interaction, "POLICE_ROLE_IDS"):
        await interaction.response.send_message("ليس لديك صلاحية الشرطة.", ephemeral=True)
        return
    if bot.pool is None:
        await interaction.response.send_message("الخدمة غير متاحة حالياً.", ephemeral=True)
        return
    cents = cents_from_amount(amount)
    if cents is None:
        await interaction.response.send_message("قيمة المخالفة غير صالحة.", ephemeral=True)
        return
    receipt = f"APX-{int(time.time())}-{os.urandom(3).hex().upper()}"
    try:
        async with bot.pool.acquire() as connection:
            async with connection.transaction():
                citizen = await connection.fetchrow(
                    "SELECT display_name FROM apex_citizens WHERE discord_user_id = $1",
                    citizen_id,
                )
                if not citizen:
                    raise ValueError("citizen")
                account = await connection.fetchrow(
                    """
                    SELECT id, balance_cents FROM apex_bank_accounts
                    WHERE owner_discord_user_id = $1 AND account_type = 'personal'
                      AND status = 'active'
                    ORDER BY created_at LIMIT 1 FOR UPDATE
                    """,
                    citizen_id,
                )
                paid = bool(account and account["balance_cents"] >= cents)
                if paid and account:
                    await connection.execute(
                        "UPDATE apex_bank_accounts SET balance_cents = balance_cents - $1 WHERE id = $2",
                        cents, account["id"],
                    )
                    await connection.execute(
                        """
                        INSERT INTO apex_bank_transactions
                          (account_id, entry_kind, counterparty, amount_cents,
                           description, receipt_number, actor_discord_user_id)
                        VALUES ($1, 'citation', 'Apex Police', $2, $3, $4, $5)
                        """,
                        account["id"], cents, reason, receipt, str(interaction.user.id),
                    )
                await connection.execute(
                    """
                    INSERT INTO apex_police_records
                      (citizen_discord_user_id, record_type, summary, amount_cents,
                       status, created_by_discord_user_id)
                    VALUES ($1, 'citation', $2, $3, $4, $5)
                    """,
                    citizen_id, reason, cents, "paid" if paid else "unpaid",
                    str(interaction.user.id),
                )
    except ValueError:
        await interaction.response.send_message("لم يتم العثور على سجل المواطن.", ephemeral=True)
        return
    state = "خُصمت مباشرة من الحساب" if paid else "سُجلت كمخالفة غير مدفوعة"
    await interaction.response.send_message(
        f"تم إصدار المخالفة؛ {state}. الإيصال: `{receipt}`", ephemeral=True
    )


async def main() -> None:
    async with bot:
        await bot.start(BOT_TOKEN)


if __name__ == "__main__":
    asyncio.run(main())
