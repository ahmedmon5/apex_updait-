# APEX RP deployment checklist

## Render services

`render.yaml` defines three independently managed services:

1. **`apex-rp-web`** — Node web service serving the React app and Express API.
2. **`apex-rp-security-bot`** — one always-on Discord Gateway bot for slash commands and security events.
3. **`apex-rp-notification-worker`** — one or more queue consumers; database row locks prevent two workers from claiming the same job.

The web service runs on Node. The two separate bot workers run on Python. The blueprint does not create production credentials, a PostgreSQL database, the first administrator, or bot authorization by itself.

## Before the first Render deploy

1. Connect the GitHub repository containing this project and create the Render services from `render.yaml`.
2. Choose a persistent PostgreSQL database for production. Set the same production `DATABASE_URL` on the web service and both workers. Do not point production at the Replit development database.
3. Apply the Drizzle schema to the selected Render database using a reviewed production migration procedure after backing it up. Do not point a deploy build or app startup at a schema-push command.
4. Enter the required environment variables in Render's service settings. Secret values belong in Render's secret fields, not in this repository:
   - Web: `DATABASE_URL`, `SESSION_SECRET`, `INITIAL_ADMIN_SETUP_TOKEN`, `DISCORD_GUILD_ID`, `OWNER_DISCORD_ID`. `INITIAL_ADMIN_SETUP_TOKEN` is only for first-admin setup and must be removed from Render after use.
   - Both workers: `DATABASE_URL`, `BOT_TOKEN`, `DISCORD_GUILD_ID`, `OWNER_DISCORD_ID`.
   - Security bot optional configuration: `TRUSTED_ADMIN_IDS`, `PROTECTED_ROLE_IDS`, `SENSITIVE_ROLE_IDS`, `EMS_ROLE_IDS`, `POLICE_ROLE_IDS`, `ANTI_NUKE_ACTOR_THRESHOLD`, `ANTI_RAID_JOIN_THRESHOLD`, and `ANTI_RAID_JOIN_WINDOW_SECONDS`.
5. Point `mlok.org` to the Render web service and confirm HTTPS is active. Website sign-in uses local username/password accounts; Google, Discord, and Roblox OAuth sign-in are disabled. The Discord bot remains a separate service.
6. Open the website and use **إعداد حساب المالك الأول** with the one-time setup token (at least 32 characters). Choose the owner email and a password of at least 12 characters. No email verification or authenticator setup is used. After the owner account is created, remove `INITIAL_ADMIN_SETUP_TOKEN` from the Render web service environment and redeploy.
7. Test owner sign-in, ordinary account registration with no operational permissions, owner permission assignment, disabled-account rejection, logout, and the `/api/healthz` health check before inviting the community.
8. Invite the bot to the guild with the required command, moderation, and audit-log permissions. Configure Discord role IDs in the owner policy screen.
9. Keep `ANTI_NUKE_MODE=alert` for the initial launch. Enable `quarantine` only after reviewing the allowlists and testing against a private test guild.

## Current limits

This repository contains deployment configuration but has not been pushed to GitHub or deployed to Render. Production database setup, service creation, first-admin bootstrap, and end-to-end tests against the Render database and a real Discord guild remain pending. The MVP also does not yet include full property/electronic-access management, payroll, payment card controls, or the remaining warrant/evidence and medical workflows from the initial brief.
